# Section 9: Limitations, Ethics, and Conclusion

## 9.1 Limitations

**OOF prediction requirement.** The R/S/N decomposition requires out-of-fold predictions — the model must produce per-sample outputs on held-out data. This excludes black-box APIs that do not expose per-sample probabilities, unless an external evaluation harness wraps them. We view this as a feature rather than a limitation: any evaluation protocol that does not require per-sample predictions cannot decompose error at the structural level we claim.

**Single benchmark per domain.** The text retrieval findings are based on MIRACL English. The certification gap may be larger or smaller on BEIR, MS MARCO, or multilingual benchmarks. Similarly, the CONUS-27 geospatial findings use ACS census features only; a richer feature set (satellite imagery, health claims data) would change the N-ceiling spectrum. We release all code and OOF predictions so that researchers can extend to additional benchmarks.

**Spatial autocorrelation and block structure.** The block-bootstrap N-ceiling estimator uses states as blocks. Tasks with strong cross-state spatial gradients (e.g., climate-driven health outcomes) may violate the between-block independence assumption, producing CIs that are too narrow. Larger blocks (Census divisions) would address this at the cost of fewer resamples.

**Three model families.** The geospatial N-ceiling is estimated from three architecturally distinct families. Additional families (random forests, attention-based models, Gaussian processes) could tighten or loosen the bound. With only three families, the estimates are conservative — the true noise floor may be lower if a fourth family captures structure the existing three miss.

**Calibration of thresholds.** The gatekeeper's thresholds (kappa_base = 0.5, lambda = 0.4, epsilon_L = 0.05) were calibrated on prior RSCT deployment studies, not on the benchmarks reported here. The universal Gate 3 failure of all 16 text models reflects a genuinely hard task, but also a threshold that may be too conservative for retrieval evaluation. We report the thresholds transparently and note that the certification gap finding (rho = 0.31) does not depend on any threshold — it is a rank-order property.

## 9.2 Ethics Statement

The CONUS-27 benchmark uses publicly available CDC PLACES and ACS data at the ZCTA level. No individual-level data is used. ZCTA-level health prevalence rates are aggregated estimates, not individual records. The benchmark does not enable individual identification or health status inference.

The R/S/N certification protocol produces deployment decisions (EXECUTE, RE_ENCODE, etc.) that could influence which models are deployed in practice. We emphasize that the protocol is diagnostic — it surfaces structural properties of the decomposition — and should inform, not replace, human judgment about deployment suitability.

This work includes technology covered by pending patent application 19/575,615 (filed March 23, 2026). The certificate library is released under an open-source license for research use.

## 9.3 Conclusion

We introduced the R/S/N decomposition and certification protocol for evaluating representation quality beyond scalar metrics. Applied to 16 text embedding models, the protocol reveals a certification gap: accuracy and certificate quality are nearly uncorrelated (rho = 0.31), with 56% of models inverting by three or more rank positions. Applied to 27 geospatial regression tasks, the same protocol reveals architecture-invariance: model family choice matters less (spread ~0.02 R-squared) than task intrinsic noise (N-ceiling range 0.156-0.593) by a factor of 20.

These two findings are not contradictory — they are two regimes that a single evaluation protocol should be able to identify. The R/S/N decomposition does both: it discriminates models when they diverge structurally, and it characterizes tasks when models converge. A leaderboard cannot tell you which regime you are in. A certificate can.
