"""Convert markdown section drafts to LaTeX body files."""

import re
import sys

sections = {
    "section1_introduction.md": "section1_body.tex",
    "section2_related_work.md": "section2_body.tex",
    "section3_rsn_decomposition.md": "section3_body.tex",
    "section4_certification_audit.md": "section4_body.tex",
    "section5_nceiling_estimation.md": "section5_body.tex",
    "section6_certification_gap.md": "section6_body.tex",
    "section7_nceling_dominance.md": "section7_body.tex",
    "section8_synthesis.md": "section8_body.tex",
    "section9_limitations_conclusion.md": "section9_body.tex",
}

for md_file, tex_file in sections.items():
    with open(md_file) as f:
        text = f.read()

    # Strip top-level markdown header
    text = re.sub(r"^# .*\n+", "", text)

    # Convert ## X.Y Title to \subsection{Title}
    def sub_header(m):
        title = m.group(1).strip()
        title = re.sub(r"^\d+\.\d+\s+", "", title)
        return "\\subsection{" + title + "}"

    text = re.sub(r"^## (.*)$", sub_header, text, flags=re.MULTILINE)

    # Bold
    text = re.sub(r"\*\*([^*]+)\*\*", lambda m: "\\textbf{" + m.group(1) + "}", text)

    # Italic
    text = re.sub(
        r"(?<!\*)\*([^*]+)\*(?!\*)",
        lambda m: "\\emph{" + m.group(1) + "}",
        text,
    )

    # Indented code -> centered texttt
    lines = text.split("\n")
    out = []
    for line in lines:
        stripped = line.strip()
        if line.startswith("    ") and not stripped.startswith("|") and not stripped.startswith("\\"):
            out.append("\\begin{center}")
            out.append("  \\texttt{" + stripped + "}")
            out.append("\\end{center}")
        else:
            out.append(line)
    text = "\n".join(out)

    with open(tex_file, "w") as f:
        f.write("% Auto-generated from " + md_file + "\n")
        f.write("% Manual LaTeX cleanup needed for tables, special chars, cross-refs.\n\n")
        f.write(text)

    print(f"{md_file} -> {tex_file}")

print(f"\nDone. {len(sections)} body .tex files generated.")
