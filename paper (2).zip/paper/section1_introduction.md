# Section 1: Introduction

A model that tops a leaderboard is not always the model we should trust. Across 16 open text embedding families evaluated on MIRACL retrieval, the rank-order correlation between scalar accuracy and a structural certificate of the same models is only 0.31 — statistically distinguishable from random, but far from the implicit promise of a leaderboard that a higher number means a better model. Fifty-six percent of evaluated models invert by three or more positions when re-ranked by the certificate. One model, nova_embed, ranks first by accuracy and fifteenth by certificate. Another, titan_v2, ranks fifteenth by accuracy and fourth by certificate. The certificate and the leaderboard are measuring different things.

In a different domain, the same protocol surfaces a different but complementary finding. Across 27 ZCTA-level geospatial regression tasks covering health, socioeconomic, and environmental outcomes, three architecturally distinct model families — PCA-projected GBDT, spatial-lag regression, and GraphSAGE with dual-graph morphing — produce task-level R-squared values whose cross-family spread averages 0.02. The same tasks exhibit an irreducible noise ceiling ranging from 0.156 to 0.593, a four-fold variation. For geospatial regression on these tasks, the architectural choice is nearly invisible against the axis of task intrinsic noise. The ceiling, not the model, is the constraint.

These two findings define two regimes in which evaluation has different jobs. In the text regime, models reach comparable scalar scores by structurally distinct paths, and the evaluation's job is to discriminate among them. In the geospatial regime, models converge, and the evaluation's job is to characterize the task. A single scalar metric cannot do either job on its own.

We contribute a certification protocol that does both. The R/S/N decomposition splits predictive error into representation adequacy (R), recoverable shortfall (S), and irreducible noise (N) on the probability simplex R+S+N=1. A four-property audit certifies that the decomposition is well-formed. A block-bootstrap N-ceiling estimator provides the irreducible-noise component with calibrated confidence intervals. The protocol issues PASS, CAUTION, or REFUSE certificates — not a ranking, but a deployment decision.

Our contributions are:

1. **The R/S/N decomposition and certification protocol.** We formalize a simplex decomposition of predictive error into three structurally distinct sources (Section 3), define a four-property audit that certifies the decomposition's validity (Section 4), and implement the protocol in an open-source certificate library.

2. **A practical block-bootstrap N-ceiling estimator.** We introduce a principled estimator of irreducible noise with seed-collapse diagnostics and residual-correlation correction, validated on synthetic data with known ground-truth noise levels (Section 5).

3. **The certification gap in text retrieval.** We evaluate 16 embedding families on MIRACL and show that accuracy and certificate quality are nearly uncorrelated (rho = 0.31), with 56% of models inverting by three or more rank positions (Section 6).

4. **Architecture-invariance under N-ceiling in geospatial regression.** We evaluate three model families on 27 CONUS tasks and show that cross-family performance spread (~0.02 R-squared) is 20 times smaller than the N-ceiling range (0.156-0.593), demonstrating a regime where task characterization matters more than model selection (Section 7).

We release the certificate library, out-of-fold predictions for all 16 text models and 27 geospatial tasks, and the audit test suite, so that the findings above can be reproduced and extended.
