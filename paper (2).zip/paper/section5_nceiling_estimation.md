# Section 5: N-Ceiling Estimation

## 5.1 Definition

The N-ceiling for a task is the fraction of target variance that no model family can explain:

    N_ceiling = 1 - max_k(R-squared_k)

where k indexes architecturally diverse model families evaluated on the same task with the same features. The maximum is taken over families, not over random seeds within a family: for stochastic models (GNN, MLP), we use the seed-averaged R-squared E[R-squared_k] rather than the best-seed R-squared, which would inflate the bound and understate irreducible noise.

N_ceiling is a task property, not a model property. It answers: "given these features, how much of the target is fundamentally unpredictable?" This is the N component of the R/S/N decomposition applied at the benchmark level rather than the sample level.

## 5.2 Block Bootstrap Confidence Intervals

Naive bootstrap confidence intervals for R-squared are invalid when observations exhibit spatial autocorrelation, as ZCTA-level health outcomes do (neighboring ZIP codes share demographics, health infrastructure, and environmental exposures). We use state-level block bootstrap: each resample draws states with replacement (approximately 50 blocks for the contiguous US), then includes all ZCTAs from each drawn state.

The algorithm:

1. For each task and model family, compute the point R-squared on the full out-of-fold predictions.
2. Draw B = 1000 bootstrap resamples. Each resample draws n_states states with replacement from the set of unique states, then concatenates all ZCTAs belonging to the drawn states.
3. For each resample, compute R-squared. If the resample contains fewer than 10 observations (possible when a small state is never drawn), record NaN.
4. The 95% confidence interval is the [2.5th, 97.5th] percentile of the non-NaN bootstrap distribution.

The block structure respects within-state autocorrelation while allowing between-state variation to drive the interval width. In practice, the CIs are wider than naive bootstrap CIs by 15-40%, reflecting the effective sample size reduction from spatial dependence.

## 5.3 Seed Collapse Diagnostic

Stochastic models (GNN, MLP) produce different predictions across random seeds. The N-ceiling estimator collapses seed variants before computing the task-level estimate:

1. Group model versions by base family (e.g., "gnn_v1_seed0", "gnn_v1_seed1", "gnn_v1_seed2" collapse to "gnn_v1").
2. For each base family, compute E[R-squared] across seeds and average the bootstrap distributions element-wise.
3. Average residual vectors per-ZCTA across seeds before computing cross-family residual correlations.

Using E[R-squared] rather than max-seed R-squared is important: the best seed's R-squared overstates achievable performance because it includes favorable noise realization. The mean is an honest estimate of the family's expected performance, which is what the N-ceiling should bound.

The diagnostic also reports per-seed R-squared spread within each family. Large spread (e.g., std > 0.02 across seeds) flags models whose training is inadequately converged, which would inflate the N-ceiling estimate.

## 5.4 Residual Correlation Diagnostic

If two model families produce highly correlated residuals, they are not providing independent estimates of the noise floor — they are failing on the same samples. The N-ceiling estimator computes the pairwise residual correlation matrix across families for each task:

    rho_ij = corr(residual_i, residual_j)

where residuals are computed per-ZCTA from seed-averaged predictions. Tasks where the mean absolute pairwise correlation exceeds a threshold (default: 0.7) are flagged. High residual correlation suggests insufficient architectural diversity: the families share enough inductive bias that their "irreducible" failures overlap, potentially understating the true noise floor.

The estimator also computes the Spearman rank correlation between per-task best R-squared and mean residual correlation. A strong positive correlation would indicate that easier tasks (high R-squared) also have more correlated residuals — a pattern that could bias the N-ceiling spectrum.

## 5.5 Validation on Synthetic Data

To validate the estimator, we construct a synthetic dataset with known ground-truth noise:

1. Generate n = 25,000 observations with d = 32 features drawn from a multivariate normal distribution with planted correlations.
2. Define the target as y = f(X) + epsilon, where f is a nonlinear function of a subset of features and epsilon is i.i.d. Gaussian noise with known variance.
3. The ground-truth N-ceiling is Var(epsilon) / Var(y), which is known by construction.
4. Train three model families (linear, GBDT, MLP) on the synthetic data and compute the estimated N-ceiling.

The validation checks:
- The block-bootstrap CI contains the true N-ceiling.
- Naive (non-block) bootstrap underestimates interval width.
- Seed collapse produces a tighter interval than single-seed estimation.
- The residual correlation diagnostic correctly identifies when two families are architecturally similar (e.g., two GBDT variants with different hyperparameters).

This synthetic validation provides the ground-truth anchor that real-world experiments cannot: we know the true noise level and can verify that the estimator recovers it.

## 5.6 Limitations

The N-ceiling is an upper bound on irreducible noise, not an exact estimate. It understates the true noise floor if the model families are insufficiently diverse (all fail on the same hard cases) and overstates it if the best family overfits (high R-squared on training distribution, lower on out-of-distribution). The OOF evaluation protocol mitigates overfitting bias, and the residual correlation diagnostic flags insufficient diversity. With three architecturally distinct families (linear, spatial, graph), the CONUS-27 estimates are conservative but informative.

The block bootstrap assumes that states are approximately independent blocks. For tasks with strong cross-state spatial patterns (e.g., a north-south gradient in a health outcome), this assumption is violated, and the CIs may be too narrow. A geographic blocking strategy (e.g., BEA regions or Census divisions) could address this at the cost of fewer, larger blocks.
