# Section 3: The R/S/N Decomposition

## 3.1 Error Decomposition on the Simplex

Given a prediction task with out-of-fold predictions, we decompose each sample's predictive behavior into three categories:

- **R (Representation adequacy):** The model's representation captures task-relevant structure. The prediction succeeds because the embedding geometry encodes the right distinctions.
- **S (Recoverable shortfall):** The model's representation contains partial task structure that better training or calibration could exploit. The prediction fails, but the failure is recoverable.
- **N (Irreducible noise):** The prediction fails for reasons no model can recover from this representation — the signal is not in the features.

For classification tasks, R/S/N labels are assigned per-sample by a trained classifier operating on geometric features of the embedding space (cosine similarity, norm ratios, projection distances). For regression tasks, the decomposition operates on residual structure across model families. In both cases, the output is a probability vector (R, S, N) per sample, and the task-level summary is the mean simplex coordinate:

    (R_mean, S_mean, N_mean) where R_mean + S_mean + N_mean = 1

This simplex constraint is enforced by construction. If the raw values deviate by more than 0.01 from unity but remain within (0.9, 1.1), they are normalized by their sum. Larger violations are flagged as integrity failures.

## 3.2 The Certificate Triple: (alpha, kappa, sigma)

From the mean simplex coordinates, three derived quantities form the certificate:

**Alpha (signal quality):**

    alpha = R / (R + N)

Alpha measures the fraction of the non-shortfall signal that is genuine representation adequacy. It ignores S entirely — a model with high alpha captures what it captures cleanly, regardless of how much it leaves on the table. Range: [0, 1]. Higher is better.

**Kappa (compatibility):**

    kappa = R * (1 - N)

Kappa measures geometric compatibility: high R and low N together. A model can have high alpha (clean signal) but low kappa (not enough of it). Kappa is the deployment-relevant metric — it captures both signal quality and signal quantity. Range: [0, 1]. Higher is better.

**Sigma (representational turbulence):**

    sigma = 0.4 * sigma_var + 0.3 * sigma_growth + 0.3 * sigma_entropy

where:
- sigma_var = Var(R, S, N), measuring how unevenly the model distributes probability mass across the three channels
- sigma_growth = S (as a proxy for improvement potential when no temporal history is available; with history, it measures the L2 drift in simplex coordinates between evaluations)
- sigma_entropy = H(R, S, N) / log(3), the normalized Shannon entropy of the simplex coordinates

Sigma is clipped to [0, 1]. Lower sigma indicates a stable, well-separated decomposition. Higher sigma indicates a turbulent representation where the R/S/N boundaries are not cleanly resolved.

**Auxiliary quantities:**

    collapse_risk = N + 0.5 * S
    omega = 1 - S

Collapse risk measures how close the model is to a noise-dominated regime. Omega measures operational capacity — the fraction of signal not lost to recoverable shortfall.

## 3.3 Phase Assignment

The mean simplex coordinates determine the model's phase:

- **NOISE**: N > 0.5 — the model is dominated by irreducible noise
- **QUADRATIC**: S > 0.4 — the model has large recoverable shortfall
- **FULL_SIGNAL**: R > 0.6 — the model captures strong task structure
- **HIGHER_ORDER**: otherwise — the model occupies the interior of the simplex

All 16 text models and all 3 geospatial families in this study fall in the HIGHER_ORDER phase, reflecting balanced but imperfect decomposition.

## 3.4 The Oobleck Threshold

The gatekeeper's central mechanism is a dynamic admissibility threshold that adapts to representational turbulence:

    kappa_req(sigma) = kappa_base + lambda * sigma

where kappa_base = 0.5 and lambda = 0.4. A stable representation (low sigma) faces a lower bar; a turbulent representation (high sigma) must demonstrate higher compatibility to pass.

This is the "oobleck" property: under pressure (turbulence), the threshold stiffens. A model that is both turbulent and low-kappa is definitively rejected. A model that is stable and moderate-kappa may pass. The threshold is not fixed — it responds to the model's own stability profile.

A Landauer tolerance buffer epsilon_L = 0.05 defines a gray zone: if kappa falls within epsilon_L of kappa_req, the decision depends on sigma. For sigma > 0.4 the conservative action (RE_ENCODE) applies; for sigma <= 0.4 a qualified EXECUTE is permitted.
