# Section 7: Finding 2 — Architecture-Invariance Under N-Ceiling in Geospatial Regression

## 7.1 Experimental Setup

We apply the same R/S/N certification protocol to a structurally different domain: geospatial regression over US Census geographies. The CONUS-27 benchmark comprises 27 ZCTA-level prediction tasks drawn from three categories:

- **Health outcomes** (19 tasks): CDC PLACES prevalence rates for chronic conditions (diabetes, COPD, obesity, smoking, etc.), health behaviors (binge drinking, physical inactivity, sleep duration), and preventive care utilization (dental visits, cholesterol screening, annual checkups).
- **Socioeconomic indicators** (5 tasks): median household income, median home value, and related ACS variables.
- **Environmental/physical** (3 tasks): nighttime light intensity, tree canopy cover, and elevation.

All tasks share a common feature set: 32 American Community Survey (ACS) variables covering demographics, economics, housing, education, and commuting patterns, measured at the ZCTA level across approximately 25,000 ZIP Code Tabulation Areas in the contiguous United States.

Three architecturally distinct model families predict each task:

1. **PCA32-GBDT**: Principal component analysis reduces the 32 ACS features to 32 orthogonal components (retaining all variance), followed by a gradient-boosted decision tree (200 trees, learning rate 0.05).
2. **Spatial Lag-GBDT**: A spatial-lag model incorporates neighborhood-averaged features via a contiguity weight matrix, then feeds the augmented feature set to the same GBDT architecture.
3. **GNN (GraphSAGE)**: A graph neural network with dual-graph morphing operates on ZCTA adjacency, learning node-level representations that are decoded to task predictions.

Each family is trained independently per task. The three families share no weights, no feature engineering, and no hyperparameter selection — they are architecturally independent.

## 7.2 The N-Ceiling Spectrum

For each task, we compute the N-ceiling as N_ceiling = 1 - max_k(R-squared_k), where the maximum is taken over the three model families. The N-ceiling estimates the fraction of target variance that no model family can explain — the irreducible noise floor for that task given these representations.

Figure 4 presents the full heatmap: 27 tasks (rows, sorted by N-ceiling) by three model families (columns), with a fourth column showing N-ceiling. The spectrum is wide:

- **Easiest tasks** (N-ceiling < 0.20): night_lights (0.156), smoking (0.192), physical_health (0.195), physical_inactivity (0.196). These tasks are well-predicted by ACS demographics — over 80% of their variance is capturable.
- **Moderate tasks** (N-ceiling 0.20-0.40): the bulk of health outcomes fall here, including diabetes (0.261), obesity (0.246), stroke (0.303), income (0.323). The noise floor is real but does not dominate.
- **Hard tasks** (N-ceiling > 0.40): elevation (0.484), high_cholesterol (0.486), binge_drinking (0.537), cholesterol_screening (0.593). For cholesterol_screening, no model family explains more than 41% of the variance. The remaining 59% is irreducible given ACS features alone.

The 4x variation (0.156 to 0.593) is the dominant axis of the dataset. It tells a practitioner more about where to invest than any model comparison could.

## 7.3 Architecture Is Nearly Invisible

Figure 5 plots cross-family R-squared spread (max - min across three families) against N-ceiling for all 27 tasks. The mean spread is 0.025. No task exceeds 0.062 (bp_medicated). The spread shows no systematic relationship with N-ceiling — hard tasks and easy tasks have comparable cross-family variation.

This means: for every task in CONUS-27, switching from a linear PCA-based model to a graph neural network changes the explained variance by about 2 percentage points. The architectural choice — linear vs spatial vs graph — is nearly invisible against the 44-percentage-point range of task intrinsic noise.

To put this in perspective: the difference between the best and worst model family on any given task (spread ~0.02) is smaller than the difference between the easiest and hardest tasks (N-ceiling range ~0.44) by a factor of 20. If a practitioner has budget for one intervention — a better model or a richer feature set — the N-ceiling analysis says the feature set wins overwhelmingly.

## 7.4 Task-Level Patterns

The heatmap reveals several task-level patterns that accuracy alone would not surface:

**Consistently well-predicted tasks** cluster in health behaviors that are strongly correlated with socioeconomic demographics: smoking prevalence, physical inactivity, and COPD are predicted at R-squared > 0.76 by all three families. These are tasks where ACS features are near-sufficient — the geographic distribution of these outcomes is largely explained by income, education, and age structure.

**Consistently hard tasks** tend to involve behaviors or outcomes with strong individual-level variation that demographic aggregates cannot capture: binge_drinking (R-squared ~0.45), cholesterol_screening (R-squared ~0.39). These are not model failures — they are data limitations. No amount of architectural sophistication will recover individual behavioral variation from ZIP-code-level census summaries.

**The environmental outlier**: elevation has moderate N-ceiling (0.484) but the highest cross-family spread (0.056). The GNN family (R-squared = 0.517) outperforms PCA (0.461) by 5.6 percentage points — the largest family gap in the dataset. This makes sense: elevation has strong spatial autocorrelation that a graph network can exploit but a linear projection cannot. This is the one task where architectural choice genuinely matters.

## 7.5 Policy Implications

The N-ceiling has a direct policy interpretation: it tells a decision-maker where model improvement is a plausible intervention and where it is not.

For cholesterol_screening (N_ceiling = 0.593), no model improvement from these features will recover more than 41% of target variance. The productive response is not a better model — it is richer input data: perhaps adding health insurance claims, pharmacy utilization, or individual screening records.

For night_lights (N_ceiling = 0.156), ACS features explain 84% of variance. Here, model improvement could matter at the margin, but the returns are small. The productive response might be to deploy the simplest adequate model (PCA32-GBDT, which matches the GNN within 1 percentage point) and allocate resources elsewhere.

The certification protocol's value in this regime is not ranking models — any of the three families would serve — but characterizing tasks. It shifts the evaluation question from "which model is best?" to "is the ceiling the constraint, or is the model the constraint?" For 26 of 27 CONUS tasks, the answer is: the ceiling.

## 7.6 Cross-Domain Validation

The same R/S/N decomposition code, the same certificate issuer, and the same audit protocol that produced the text retrieval results in Section 6 produced these geospatial results. No domain-specific adaptation was required. The certificate library treats the text pairwise classification task and the geospatial regression task identically: both produce OOF predictions, both feed the decomposition, both receive certificates.

This is the cross-domain validation claim: the protocol is not a text-retrieval-specific diagnostic. It identifies the certification gap in text (where models diverge structurally despite similar accuracy) and the architecture-invariance regime in geo (where models converge and task noise dominates) using the same machinery. The two findings are complementary because the protocol surfaces whatever structure the data contains, rather than imposing a fixed evaluation lens.
