# Section 6: Finding 1 — The Certification Gap in Text Retrieval

## 6.1 Experimental Setup

We evaluate 16 open text embedding model families on the MIRACL English retrieval benchmark. The models span eight providers and four architectural families: encoder-only transformers (Jina v3, BGE-M3, Cohere Embed v4, OpenAI text-embedding-3-small, Gemini Embedding, Amazon Nova Embed, Amazon Titan Text Embeddings v2, MiniLM), decoder-only transformers with last-token pooling (NVIDIA NeMo Retriever Nemotron-4 1B, Qwen3-8B), and variants that differ only in dimensionality reduction (Jina v3 PCA-384, Jina v3 MRL-384, Nemotron PCA-1024, Nemotron MRL-1024, Voyage AI v4 Nano). Native embedding dimensions range from 384 to 2048; all are projected to a common 64-dimensional space via a trained pairwise projection layer before R/S/N classification.

Each model's embeddings are generated on the MIRACL 30K balanced pair set (10K R, 10K S, 10K N), then passed through a two-stage pipeline: (1) a pairwise projection layer trained per-model to compress to 64 dimensions, and (2) a shared R/S/N classification head that outputs per-sample softmax probabilities over {R, S, N}. The mean softmax vector (R_mean, S_mean, N_mean) feeds the yrsn `DecompositionScore` function to produce the certificate triple (alpha, kappa, sigma), and the `SequentialGatekeeper` to produce the gate decision.

No model is fine-tuned on the retrieval task. The projection layer adapts the geometric structure; the classification head and certificate computation are identical across all 16 models.

## 6.2 The Leaderboard vs the Certificate

Table 1 reports the full results. By balanced accuracy, the top five models are nova_embed (77.1%), voyage4_large (76.8%), gemini (76.6%), bge_m3 (76.2%), and qwen3_8b (74.9%). By alpha — the certificate's primary quality signal — the top five are openai_3_small (0.514), bge_m3 (0.509), voyage4_large (0.509), titan_v2 (0.508), and qwen3_8b (0.507).

The rank-order correlation between accuracy rank and alpha rank is rho = 0.31. Nine of sixteen models (56%) invert by three or more positions. Figure 1 plots accuracy rank against alpha rank with a diagonal reference line; deviations from the diagonal are rank inversions. The scatter shows no systematic relationship between the two rankings.

Three inversions deserve attention:

**nova_embed: accuracy #1, alpha #15.** The highest-accuracy model receives the second-worst certificate. This is the paper's most extreme result and demands a mechanistic explanation (Section 6.3).

**titan_v2: accuracy #15, alpha #4.** The second-lowest accuracy model receives the fourth-best certificate — an 11-position positive inversion. titan_v2 has the lowest native dimensionality (512) and the lowest balanced accuracy (67.5%), yet its simplex coordinates place it among the structurally strongest models.

**openai_3_small: accuracy #6, alpha #1.** A model that a leaderboard would rank as middling receives the best structural certificate across all 16 families.

These are not outliers in an otherwise well-correlated ranking. The median absolute rank inversion across all 16 models is 3.0 positions. Only two models — qwen3_8b and nemotron — have zero inversion.

## 6.3 Why the #1 Accuracy Model Has the Worst Certificate

Figure 3 presents the normalized 3x3 confusion matrices for nova_embed and openai_3_small side by side.

nova_embed achieves its high accuracy primarily through noise-channel dominance: N recall = 0.956, with S recall = 0.741 and R recall = 0.661. It correctly classifies noise nearly perfectly, and this large correct-N mass inflates its balanced accuracy. But its R precision is only 0.650 — a third of what the model calls "relevant" is actually superfluous. This R/S confusion is exactly what the certificate penalizes.

openai_3_small has slightly lower N recall (0.940) and notably lower S recall (0.692), giving it lower balanced accuracy. But its R precision is 0.732 — it is more selective about what it calls relevant. The certificate rewards this: the mean simplex coordinates for openai_3_small are (R=0.349, S=0.321, N=0.330), placing it closest to the R vertex among all 16 models. nova_embed's coordinates are (R=0.313, S=0.353, N=0.334), shifted toward S — it allocates more probability mass to the recoverable-shortfall channel.

The mechanistic explanation is straightforward: accuracy treats all three classes symmetrically, so a model that excels at the easy class (N) gets rewarded. The certificate weights structural discrimination — can the model tell R from S? — which is the harder and more deployment-relevant distinction.

## 6.4 Simplex Geometry

Figure 2 plots all 16 models in the R/S/N ternary simplex, colored by accuracy rank. All models cluster near the centroid (R=S=N=1/3), reflecting the balanced class distribution. But within this cluster, the spread is real: R_mean ranges from 0.309 (nemotron, nemotron_mrl1024) to 0.349 (openai_3_small), a 4-percentage-point gap. S_mean ranges from 0.320 (voyage4_nano) to 0.362 (nemotron), and N_mean ranges from 0.319 (gemini) to 0.336 (voyage4_nano).

The color map reveals no spatial structure: high-accuracy models (dark colors) and low-accuracy models (light colors) are interspersed throughout the cluster. This is the visual confirmation that accuracy rank does not predict simplex position.

## 6.5 The Gate Audit

All 16 models pass Gate 1 (simplex integrity: R+S+N=1 within tolerance) and Gate 2 (cross-seed consensus). All 16 fail Gate 3 (admissibility: kappa >= kappa_req). The oobleck threshold kappa_req ranges from 0.658 to 0.663 across models, while measured kappa ranges from 0.207 to 0.234. The gap between the best kappa (openai_3_small, 0.234) and the lowest threshold (0.658) is 0.424 — no model is close to passing.

The universal Gate 3 failure is not a flaw in the protocol. It is a property of the task: MIRACL retrieval with R/S/N class balance is structurally harder than the gate was calibrated for. The certificate correctly identifies that all 16 representations would need re-encoding before deployment in a simplex-rotor pipeline. The gate's job is not to create a leaderboard — it is to issue a deployment decision. The decision is RE_ENCODE for all models, and that is the honest answer.

Within the RE_ENCODE regime, the certificate still discriminates: alpha ranges from 0.482 to 0.514 (spread = 0.032), and kappa ranges from 0.207 to 0.234. These are small absolute differences, but they produce the 56% inversion rate because accuracy compresses a different axis of variation. The certification gap exists precisely because the two metrics respond to different features of the confusion matrix.

## 6.6 Compression and Architecture Effects

The 16 models include three dimensionality-reduction comparisons that serve as natural controls:

**Jina v3 family** (native 1024 vs PCA-384 vs MRL-384): The native model ranks 7th by accuracy and 9th by alpha. PCA-384 ranks 10th by accuracy but 8th by alpha — a positive inversion. MRL-384 ranks 8th by accuracy but 13th by alpha — a negative inversion. The same base model, subjected to two different reduction methods, produces a 5-position alpha spread. This suggests that dimensionality reduction interacts with the R/S/N decomposition in non-trivial ways.

**Nemotron family** (native 2048 vs PCA-1024 vs MRL-1024): All three cluster in the 12th-14th accuracy range. By alpha, native ranks 10th, PCA ranks 14th, and MRL ranks 16th (last). MRL reduction degrades the certificate more than it degrades accuracy.

**Voyage AI family** (large vs nano): voyage4_large ranks 2nd by accuracy and 3rd by alpha — near-agreement. voyage4_nano ranks 11th by accuracy and 6th by alpha — a 5-position positive inversion. The smaller model has worse accuracy but a structurally stronger decomposition.

These within-family comparisons confirm that the certification gap is not an artifact of cross-provider variation. The same provider's models can invert relative to each other.
