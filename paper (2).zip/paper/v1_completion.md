# GeoCert v1 Completion Checklist

**Scope**: Freeze v1 and ship the paper. No new experiments.

## Must fix
- [x] Propagate EVIDENCE_AUDIT corrections: (DONE 2026-05-01)
  - spread 0.02 -> spread 0.037 (section1, section2, section9)
  - factor 20 -> factor ~12 (section1, section9)
  - section7 already correct (0.037, ~12)
- [x] Resolve Section 7.7 routing: (DONE 2026-05-01 -- CUT from v1)
  - Section 7.7 replaced with comment pointing to v2_followups.md
  - Section 8 synthesis rewritten: "discriminate / characterize" (removed "route")
  - Section 9 conclusion rewritten: "does both" (removed "routes predictions")
  - No dangling \ref{tab:routing} or \ref{eq:routing}
  - Zero [X]/[Y]/[Z] placeholders remain
- [x] Cut paper from ~7300 to ~5900 words (DONE 2026-05-01, -20%):
  - Section 5: N-ceiling methodology moved to Appendix C (app:nceiling_method)
  - Section 6: simplex geometry and compression effects trimmed
  - Section 7: task-level patterns compressed, cross-domain scope compressed, routing cut
- [x] Add HF dataset citation/reference (DONE -- \citep{geocert2026} in Data Availability)
- [x] Add code/data availability statement (DONE -- Section 9, "Data and Code Availability")

## Should add
- [ ] S018D metric-compression result as Finding 3 or sidebar:
  - 9/12 solvers hit GCF-1.1 (Metric Compression)
  - gate entropy = 0.0 (all EXECUTE)
  - noisy solver nearest neighbor = linear_ridge (3.34), not mean_baseline (10.01)
- [ ] Injection-detection top-1=9/9 as one-line claim (validated 2026-05-01)
- [ ] Short limitations note: S018Y/Z are follow-up work

## Findings to keep in v1
1. **Text certification gap**: representation quality is task-dependent, not model-dependent
2. **CONUS-27 architecture-invariance**: cross-family spread ~0.037, factor ~12x smaller than N-ceiling range
3. **S018D metric compression**: aggregate certificate metrics fail to discriminate degenerate solvers

## Section 7.7 routing decision
**Cut from v1.** Rationale: 8 unfilled placeholders, missing table definition, no ready numbers. Rewrite Section 8 synthesis from "discriminate / characterize / route" to "discriminate / characterize". Move routing to v2.

## Stale numbers (exact locations)
| File | Line | Stale | Correct |
|------|------|-------|---------|
| section1_body.tex | 5 | 0.02 | 0.037 |
| section1_body.tex | 19 | ~0.02, 20x | ~0.037, ~12x |
| section2_body.tex | 11 | ~0.02 | ~0.037 |
| section9_body.tex | 29 | ~0.02, factor 20 | ~0.037, factor ~12 |
