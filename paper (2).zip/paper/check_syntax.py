"""Check LaTeX syntax in all body files."""
import re

files = [f"section{i}_body.tex" for i in range(1, 10)]
files += ["table1_leaderboard.tex", "table2_conus27.tex"]
errors = []

for fname in files:
    try:
        with open(fname) as f:
            text = f.read()
    except FileNotFoundError:
        errors.append(f"{fname}: FILE NOT FOUND")
        continue

    # Check brace balance (skip escaped braces)
    depth = 0
    for i, ch in enumerate(text):
        if ch == "{" and (i == 0 or text[i - 1] != "\\"):
            depth += 1
        elif ch == "}" and (i == 0 or text[i - 1] != "\\"):
            depth -= 1
        if depth < 0:
            line_num = text[:i].count("\n") + 1
            errors.append(f"{fname}:{line_num}: unmatched closing brace")
            break
    if depth > 0:
        errors.append(f"{fname}: {depth} unclosed brace(s)")

    # Check begin/end balance
    begins = re.findall(r"\\begin\{(\w+)\}", text)
    ends = re.findall(r"\\end\{(\w+)\}", text)
    for env in set(begins + ends):
        bc = begins.count(env)
        ec = ends.count(env)
        if bc != ec:
            errors.append(f"{fname}: \\begin{{{env}}} x{bc} vs \\end{{{env}}} x{ec}")

if errors:
    print("ERRORS:")
    for e in errors:
        print(f"  {e}")
else:
    print("All files pass basic syntax checks")
