# GeoCert v2 Follow-ups

Work deferred from v1 to keep the paper at 9 pages and submission-ready.

## Experiments
- **S018Y**: Counterfactual labels (label-free Y-U arm)
- **S018Z**: Unsupervised reconstruction audit (Z on text models)
- **Routing experiments**: Certificate-routed prediction (Section 7.7 cut from v1)

## Paper sections
- **Section 7.7 routing**: Fill placeholders with real numbers, create tab:routing table
- **Full 9-mode taxonomy validation**: Expand injection-detection beyond sidebar mention
- **Expanded GeoCert benchmark**: Dataset track version with full benchmark protocol

## Injection-detection validation (done, not yet in paper)
- v2 harness: top-1 = 9/9, top-3 = 9/9 across 8 seeds
- Robustness: holds through noise SD=0.15, GCF-2.3 fragile at SD=0.20
- Location: rsct-geocert/exp/s035_mast_reconcile/outputs/INJECTION_VALIDATION_REPORT.md

## Taxonomy refinement candidates
- GCF-2.3 (Range Compression): 0 unique signals, merge candidate with GCF-2.2
- GCF-3.1 (Target-Solver Conflation): 1 unique signal, second most fragile
- GCF-3.3 (Fine-Routing Failure): 0 unique signals, depends on routing being in scope
