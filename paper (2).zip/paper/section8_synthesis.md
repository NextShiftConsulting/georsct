# Section 8: When Evaluation Should Rank Models vs Characterize Tasks

The two findings in Sections 6 and 7 are not competing results — they are two manifestations of a single evaluation problem.

In text retrieval, 16 models score between 65.8% and 77.1% balanced accuracy — a 11-percentage-point spread. Behind this spread, the R/S/N decomposition reveals structurally distinct paths to similar scores. The certification gap (rho = 0.31 between accuracy and alpha rank) means the leaderboard's ordering is nearly uninformative about structural quality. In this regime, the evaluation's job is to **discriminate**: tell the practitioner which models succeed for the right reasons.

In geospatial regression, three architecturally distinct model families produce R-squared values within 0.02 of each other on every task. The certification protocol has nothing to discriminate — the models have converged. But the N-ceiling varies from 0.156 to 0.593 across 27 tasks. In this regime, the evaluation's job is to **characterize**: tell the practitioner how much improvement is possible, and whether the bottleneck is the model or the data.

A scalar metric cannot distinguish these two regimes. It reports a number; the practitioner interprets it as a ranking. The R/S/N decomposition adds a second dimension: the decomposition tells you not just how well a model performed, but whether the performance is constrained by representation adequacy (improve the model), recoverable shortfall (improve the training), or irreducible noise (improve the data).

The protocol's practical output is a decision, not a number:
- In the text regime: RE_ENCODE (all 16 models need a different representation for this task), but within that class, alpha and kappa provide a structural ranking that accuracy does not.
- In the geo regime: the N-ceiling tells you whether to invest in better models (low N-ceiling tasks where returns exist) or better features (high N-ceiling tasks where model improvement is capped).

This two-regime framing is, we believe, the protocol's most useful property. It shifts the evaluation question from "which model is best?" to "what kind of evaluation does this situation need?" The answer depends on the data, not the evaluator's preference.
