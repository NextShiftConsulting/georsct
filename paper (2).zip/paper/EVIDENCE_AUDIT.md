# Evidence Quality Audit — Table 2 Rebuild

**Date:** 2026-04-29
**Auditor context:** Pre-submission evidence reconciliation

## Finding: Table 2 PCA Column Was From Different Training Run

Table 2 mixed sources:
- **GNN column**: Matches canonical OOF test fold (0/27 discrepancies > 0.001)
- **SLag column**: Matches canonical OOF test fold (0/27 discrepancies)
- **PCA column**: 21/27 tasks diverge from canonical OOF test fold. Values came from an earlier, separate PCA training run.

### Source of Truth

Canonical OOF artifacts:
- S3: `s3://yrsn-datasets/rsct_curriculum/series_018/oof_artifacts/`
- Local cache: `C:/tmp/oof_artifacts/`
- Provenance: `provenance.json` (gnn_v2 sha c2c2edc5, pca_v1 sha 1b1dc370, spatial_lag_v1 sha 6d958e9c)
- All dated 2026-04-23

### Corrected Values (PCA column, major changes)

| Task | Old (Table 2) | New (OOF test) | Delta |
|------|---------------|----------------|-------|
| elevation | .461 | .350 | -0.111 |
| tree_cover | .540 | .474 | -0.066 |
| cholesterol_screening | .407 | .349 | -0.058 |
| night_lights | .845 | .799 | -0.046 |
| population_density | .800 | .754 | -0.046 |
| home_value | .709 | .676 | -0.033 |
| sleep_less_7hr | .684 | .662 | -0.022 |

### Impact on Claims

| Metric | Old | Corrected |
|--------|-----|-----------|
| PCA mean R2 | .672 | .655 |
| GNN mean R2 | .655 | .651 |
| SLag mean R2 | .669 | .666 |
| Mean spread | .025 | .037 |
| Max spread | .061 (BP med) | .166 (elevation) |
| N-ceiling range | .156-.593 | .155-.593 |
| Factor (range/spread) | ~20x | ~12x |

### Narrative Impact

Architecture-invariance claim weakens quantitatively but becomes more honest:
- For 23/27 tasks, spread < 0.05 (architecture nearly invisible)
- For 4 tasks (elevation, tree_cover, cholesterol_screening, bp_medicated), spread > 0.05
- Elevation is an outlier: PCA32 collapses (R2=0.350 vs GNN=0.517), likely because PCA cannot capture spatial structure in terrain data
- The "architecture is invisible" claim should be qualified: holds for health/socioeconomic tasks, breaks for physical/environmental tasks with spatial structure

### Temporal Consistency

- s018h ran 2026-04-23 13:00 -- BEFORE gatekeeper deletion (2026-04-24 12:52)
- s018h results are temporally valid
- Post-deletion jobs (s018n, s018p) are self-contained, no yrsn gatekeeper imports

### Action Taken

- `table2_conus27.tex` updated with all 27 canonical OOF test-fold R2 values
- Caption updated to specify "holdout R2" and "out-of-fold test predictions"
- Prose updates in section7_body.tex pending (spread 0.025->0.037, factor 20->12)
