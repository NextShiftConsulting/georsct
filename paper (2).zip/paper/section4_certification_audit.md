# Section 4: Certification and Audit

## 4.1 The Certificate Pipeline

The certification protocol is implemented as a three-stage pipeline:

**Issuer.** The certificate issuer is a pure function: it takes out-of-fold predictions and ground truth, computes the R/S/N decomposition, derives the certificate triple (alpha, kappa, sigma), and returns a certificate object. It performs no I/O and has no side effects. The same inputs always produce the same certificate.

**Mixer.** When multiple model families are evaluated on the same task, the certificate mixer computes a blended certificate. Family weights are proportional to R_k * (1 - S_proxy_k) * calibration_k, subject to a floor weight of 0.05 (no family is entirely ignored) and a maximum weight share of 0.60 (no single family dominates). The blended certificate represents the best-available decomposition for the task, not any individual model's view.

**Auditor.** The certificate auditor checks four structural properties of the certificate (Section 4.2) and issues a pass/fail determination. A certificate that fails any audit property is flagged but not suppressed — the audit is diagnostic, not censoring.

## 4.2 Four Audit Properties

A well-formed R/S/N certificate satisfies four properties:

**Property 1: Simplex integrity.** R + S + N = 1 within numerical tolerance (epsilon = 1e-6). This is enforced by construction but verified as a tamper-detection check. Violations exceeding 1e-3 are flagged as potential data corruption.

**Property 2: S-monotonicity.** Within a model family, a representation with strictly more capacity (e.g., higher dimensionality, more training data) should not exhibit higher S than a weaker variant of the same model. S measures what the representation *could* recover but does not — a stronger representation should leave less on the table. Violations suggest overfitting or miscalibration in the decomposition.

**Property 3: N-invariance.** The irreducible noise component N should be approximately invariant across model families evaluated on the same task. N measures what no model can recover from the available features — it is a property of the task, not the model. Cross-family N variance exceeding a threshold indicates that the decomposition is conflating model-specific shortfall with genuine noise.

**Property 4: Alpha-consistency.** The certificate's alpha (signal quality) should be consistent with the per-class confusion matrix analysis. Specifically, a model with high alpha should exhibit high R-class precision, not merely high R-class recall. This property catches cases where the decomposition nominally assigns high R but the model's R predictions are contaminated by S-class confusion.

## 4.3 Gate Logic

The SequentialGatekeeper evaluates certificates through five gates in fixed order. A failure at any gate terminates evaluation and issues a decision:

| Gate | Test | Failure Decision |
|------|------|-----------------|
| Gate 1 — Integrity | N < 0.5 or alpha >= 0.3 | REJECT |
| Gate 2 — Consensus | Coherence >= 0.4 | BLOCK |
| Gate 3 — Admissibility | sigma <= 0.5 and kappa >= kappa_req(sigma) | RE_ENCODE |
| Gate 3B — Trajectory | r_bar >= 0.65 (optional, requires history) | RE_ENCODE |
| Gate 4 — Grounding | kappa_L >= 0.3 (requires hierarchical kappa) | REPAIR |

The decisions are ordered by severity: REJECT (fundamental failure, do not use) > BLOCK (structural problem, investigate) > RE_ENCODE (representation inadequate, try a different embedding) > REPAIR (minor issue, calibrate) > EXECUTE (deploy).

A certificate that passes all gates receives EXECUTE — a positive deployment recommendation. In the studies reported here, all 16 text models receive RE_ENCODE (failing Gate 3) and all geospatial families receive certificates appropriate to their N-ceiling regime.

## 4.4 What the Gate Produces

The gate does not produce a ranking. It produces a decision: EXECUTE, RE_ENCODE, REPAIR, BLOCK, or REJECT. Two models that both receive RE_ENCODE are both inadequate for deployment — the fact that one has higher kappa than the other is informative but secondary. This is a deliberate design choice: the certification protocol is an audit, not a leaderboard. Its job is to answer "should I deploy this?" not "which model wins?"

Within a single decision class (e.g., all RE_ENCODE), the certificate triple provides ordering. This is how Section 6 identifies the certification gap: all 16 text models receive RE_ENCODE, but their alpha and kappa values produce a ranking that disagrees with accuracy.
