#!/usr/bin/env python3
"""F001-KAPPA-VS-SIMPLEX: Scalar kappa vs R/S/N Simplex evaluation.

Self-contained SageMaker processing job script.
Reads leaderboard.json from S3, runs 4 hypothesis tests.

Hypotheses:
  H1: Rank correlation - alpha_rank != kappa_rank (simplex reorders models)
  H2: Calibration bins - simplex bins have tighter accuracy spread than kappa quartiles
  H3: Error separation - kappa-matched pairs show different confusion patterns
  H4: Inversion detection - simplex detects quality inversions kappa misses

Input: s3://yrsn-checkpoints/model_master_metrics/leaderboard.json
  Schema: {models: {model_name: {alpha, kappa, R_mean, S_mean, N_mean,
           balanced_accuracy, alpha_rank, kappa_rank, balanced_acc_rank,
           confusion_matrix: {R_R, R_S, ..., N_N}, ...}}}

Instance: ml.m5.xlarge (CPU)
Expected wall-clock: ~2 min
"""

import json
import os
import sys
import time
from datetime import datetime, timezone

import boto3
import numpy as np
from scipy import stats

# -- config --
LEADERBOARD_BUCKET = "yrsn-checkpoints"
LEADERBOARD_KEY = "model_master_metrics/leaderboard.json"
OUTPUT_BUCKET = "swarm-yrsn-datasets"
OUTPUT_PREFIX = "rsct_curriculum/series_018/f001_kappa_vs_simplex/"

INSTANCE_TYPE = os.environ.get("INSTANCE_TYPE", "ml.m5.xlarge")
START_TIME = time.time()
START_ISO = datetime.now(timezone.utc).isoformat()


def log(msg):
    print(f"[F001] {msg}", flush=True)


def upload_json(s3, bucket, key, data):
    body = json.dumps(data, indent=2, default=str)
    s3.put_object(Bucket=bucket, Key=key, Body=body.encode("utf-8"))
    log(f"Uploaded s3://{bucket}/{key}")


def load_leaderboard(s3):
    """Load and validate leaderboard.json."""
    obj = s3.get_object(Bucket=LEADERBOARD_BUCKET, Key=LEADERBOARD_KEY)
    lb = json.loads(obj["Body"].read())
    models = lb.get("models", {})
    log(f"Loaded leaderboard: {len(models)} models")

    # Validate required fields
    required = ["alpha", "kappa", "R_mean", "S_mean", "N_mean",
                 "balanced_accuracy", "alpha_rank", "kappa_rank"]
    valid_models = {}
    for name, data in models.items():
        missing = [f for f in required if data.get(f) is None]
        if missing:
            log(f"  SKIP {name}: missing {missing}")
            continue
        valid_models[name] = data
    log(f"Valid models: {len(valid_models)}/{len(models)}")
    return valid_models


def h1_rank_correlation(models):
    """H1: Do alpha_rank and kappa_rank diverge from balanced_acc_rank?

    Pass condition: rho(alpha_rank, acc_rank) != rho(kappa_rank, acc_rank)
    at p < 0.05, OR the absolute difference in rho > 0.05.
    """
    log("--- H1: Rank Correlation ---")
    names = sorted(models.keys())

    alpha_ranks = [models[n]["alpha_rank"] for n in names]
    kappa_ranks = [models[n]["kappa_rank"] for n in names]
    acc_ranks = [models[n]["balanced_acc_rank"] for n in names]

    rho_alpha, p_alpha = stats.spearmanr(alpha_ranks, acc_ranks)
    rho_kappa, p_kappa = stats.spearmanr(kappa_ranks, acc_ranks)

    # Also check alpha vs kappa rank agreement
    rho_ak, p_ak = stats.spearmanr(alpha_ranks, kappa_ranks)

    delta_rho = abs(rho_alpha - rho_kappa)
    # Pass if the two metrics rank models differently
    passed = delta_rho > 0.05 or rho_ak < 0.95

    result = {
        "hypothesis": "H1",
        "description": "Alpha-rank and kappa-rank diverge in model ordering",
        "rho_alpha_vs_acc": round(float(rho_alpha), 4),
        "p_alpha_vs_acc": round(float(p_alpha), 6),
        "rho_kappa_vs_acc": round(float(rho_kappa), 4),
        "p_kappa_vs_acc": round(float(p_kappa), 6),
        "rho_alpha_vs_kappa": round(float(rho_ak), 4),
        "p_alpha_vs_kappa": round(float(p_ak), 6),
        "delta_rho": round(float(delta_rho), 4),
        "pass": bool(passed),
        "detail": {n: {"alpha_rank": models[n]["alpha_rank"],
                        "kappa_rank": models[n]["kappa_rank"],
                        "acc_rank": models[n]["balanced_acc_rank"]}
                   for n in names}
    }
    log(f"  rho(alpha,acc)={rho_alpha:.4f}, rho(kappa,acc)={rho_kappa:.4f}, delta={delta_rho:.4f}")
    log(f"  rho(alpha,kappa)={rho_ak:.4f}")
    log(f"  H1: {'PASS' if passed else 'FAIL'}")
    return result


def h2_calibration_bins(models):
    """H2: Simplex bins have tighter accuracy spread than kappa quartiles.

    Bin models by simplex region (R-dom, S-dom, N-dom, balanced) vs kappa quartiles.
    Compare within-bin accuracy variance.
    """
    log("--- H2: Calibration Bins ---")
    names = sorted(models.keys())

    # Simplex region assignment
    def simplex_region(m):
        r, s, n = m["R_mean"], m["S_mean"], m["N_mean"]
        if r > s and r > n and r > 0.36:
            return "R-dominant"
        elif s > r and s > n and s > 0.36:
            return "S-dominant"
        elif n > r and n > s and n > 0.36:
            return "N-dominant"
        else:
            return "balanced"

    # Kappa quartiles
    kappas = sorted([models[n]["kappa"] for n in names])
    q25, q50, q75 = np.percentile(kappas, [25, 50, 75])

    def kappa_bin(m):
        k = m["kappa"]
        if k <= q25:
            return "Q1"
        elif k <= q50:
            return "Q2"
        elif k <= q75:
            return "Q3"
        else:
            return "Q4"

    # Compute within-bin accuracy variance
    simplex_bins = {}
    kappa_bins = {}
    for n in names:
        m = models[n]
        sr = simplex_region(m)
        kb = kappa_bin(m)
        simplex_bins.setdefault(sr, []).append(m["balanced_accuracy"])
        kappa_bins.setdefault(kb, []).append(m["balanced_accuracy"])

    def bin_stats(bins):
        stats_out = {}
        total_var = 0
        total_n = 0
        for label, accs in bins.items():
            v = float(np.var(accs)) if len(accs) > 1 else 0.0
            stats_out[label] = {
                "n": len(accs),
                "mean_acc": round(float(np.mean(accs)), 4),
                "var_acc": round(v, 6),
                "accs": [round(a, 4) for a in accs],
            }
            total_var += v * len(accs)
            total_n += len(accs)
        avg_var = total_var / total_n if total_n > 0 else 0.0
        return stats_out, avg_var

    simplex_stats, simplex_avg_var = bin_stats(simplex_bins)
    kappa_stats, kappa_avg_var = bin_stats(kappa_bins)

    # Pass: simplex bins have lower average within-bin variance
    passed = simplex_avg_var < kappa_avg_var

    result = {
        "hypothesis": "H2",
        "description": "Simplex-region bins have tighter accuracy spread than kappa quartiles",
        "simplex_bins": simplex_stats,
        "kappa_bins": kappa_stats,
        "simplex_avg_within_var": round(float(simplex_avg_var), 6),
        "kappa_avg_within_var": round(float(kappa_avg_var), 6),
        "variance_ratio": round(float(simplex_avg_var / kappa_avg_var), 4) if kappa_avg_var > 0 else None,
        "pass": bool(passed),
    }
    log(f"  Simplex avg var: {simplex_avg_var:.6f}")
    log(f"  Kappa avg var:   {kappa_avg_var:.6f}")
    log(f"  H2: {'PASS' if passed else 'FAIL'}")
    return result


def h3_error_separation(models):
    """H3: Kappa-matched pairs show different confusion patterns.

    Find pairs of models with similar kappa but different simplex coordinates.
    Check if their confusion matrices differ significantly.
    """
    log("--- H3: Error Separation ---")
    names = sorted(models.keys())
    cm_keys = ["R_R", "R_S", "R_N", "S_R", "S_S", "S_N", "N_R", "N_S", "N_N"]

    def get_cm_vector(m):
        cm = m.get("confusion_matrix", {})
        return np.array([cm.get(k, 0.0) or 0.0 for k in cm_keys])

    def simplex_distance(m1, m2):
        return np.sqrt((m1["R_mean"] - m2["R_mean"])**2 +
                       (m1["S_mean"] - m2["S_mean"])**2 +
                       (m1["N_mean"] - m2["N_mean"])**2)

    # Find kappa-matched pairs (|delta_kappa| < 0.01)
    pairs = []
    for i, n1 in enumerate(names):
        for n2 in names[i+1:]:
            dk = abs(models[n1]["kappa"] - models[n2]["kappa"])
            if dk < 0.01:
                sd = simplex_distance(models[n1], models[n2])
                cm1 = get_cm_vector(models[n1])
                cm2 = get_cm_vector(models[n2])
                cm_dist = float(np.linalg.norm(cm1 - cm2))
                pairs.append({
                    "model_a": n1,
                    "model_b": n2,
                    "delta_kappa": round(float(dk), 4),
                    "simplex_distance": round(float(sd), 4),
                    "confusion_distance": round(cm_dist, 4),
                    "acc_delta": round(abs(models[n1]["balanced_accuracy"] -
                                          models[n2]["balanced_accuracy"]), 4),
                })

    # Pass: at least one pair shows confusion_distance > 0.05 despite kappa match
    pairs_with_diff = [p for p in pairs if p["confusion_distance"] > 0.05]
    passed = len(pairs_with_diff) > 0

    result = {
        "hypothesis": "H3",
        "description": "Kappa-matched model pairs have distinguishable confusion patterns",
        "n_kappa_matched_pairs": len(pairs),
        "n_pairs_with_confusion_diff": len(pairs_with_diff),
        "kappa_match_threshold": 0.01,
        "confusion_diff_threshold": 0.05,
        "pairs": sorted(pairs, key=lambda p: -p["confusion_distance"]),
        "pass": bool(passed),
    }
    log(f"  {len(pairs)} kappa-matched pairs, {len(pairs_with_diff)} show confusion divergence")
    log(f"  H3: {'PASS' if passed else 'FAIL'}")
    return result


def h4_inversion_detection(models):
    """H4: Simplex detects quality inversions kappa misses.

    An "inversion" = model A has higher kappa but lower accuracy than model B.
    Check if simplex coordinates predict these inversions better.
    """
    log("--- H4: Inversion Detection ---")
    names = sorted(models.keys())

    inversions = []
    simplex_catches = 0
    total_inversions = 0

    for i, n1 in enumerate(names):
        for n2 in names[i+1:]:
            m1, m2 = models[n1], models[n2]
            # Inversion: higher kappa but lower accuracy
            kappa_higher = m1["kappa"] > m2["kappa"]
            acc_higher = m1["balanced_accuracy"] > m2["balanced_accuracy"]

            if kappa_higher != acc_higher and abs(m1["kappa"] - m2["kappa"]) > 0.005:
                total_inversions += 1
                # Does simplex predict the correct ordering?
                # Use alpha (derived from R,S,N) as simplex proxy
                alpha_agrees_with_acc = (
                    (m1["alpha"] > m2["alpha"]) == acc_higher
                )
                if alpha_agrees_with_acc:
                    simplex_catches += 1

                inversions.append({
                    "model_high_kappa": n1 if kappa_higher else n2,
                    "model_high_acc": n1 if acc_higher else n2,
                    "kappa_pair": [round(m1["kappa"], 4), round(m2["kappa"], 4)],
                    "acc_pair": [round(m1["balanced_accuracy"], 4),
                                 round(m2["balanced_accuracy"], 4)],
                    "alpha_pair": [round(m1["alpha"], 4), round(m2["alpha"], 4)],
                    "simplex_catches": alpha_agrees_with_acc,
                })

    catch_rate = simplex_catches / total_inversions if total_inversions > 0 else 0.0
    passed = catch_rate > 0.5 and total_inversions >= 3

    result = {
        "hypothesis": "H4",
        "description": "Simplex (alpha) detects kappa-accuracy inversions",
        "total_inversions": total_inversions,
        "simplex_catches": simplex_catches,
        "catch_rate": round(float(catch_rate), 4),
        "pass_threshold": 0.5,
        "inversions": inversions[:20],  # cap detail
        "pass": bool(passed),
    }
    log(f"  {total_inversions} inversions, simplex catches {simplex_catches} ({catch_rate:.2%})")
    log(f"  H4: {'PASS' if passed else 'FAIL'}")
    return result


def main():
    log("=" * 60)
    log("F001-KAPPA-VS-SIMPLEX")
    log(f"Instance: {INSTANCE_TYPE}")
    log(f"Start: {START_ISO}")
    log("=" * 60)

    s3 = boto3.client("s3", region_name="us-east-1")

    # Load data
    models = load_leaderboard(s3)
    if len(models) < 5:
        log(f"FATAL: Only {len(models)} valid models. Need >= 5.")
        sys.exit(1)

    # Run hypotheses
    h1 = h1_rank_correlation(models)
    h2 = h2_calibration_bins(models)
    h3 = h3_error_separation(models)
    h4 = h4_inversion_detection(models)

    # Upload individual evidence
    upload_json(s3, OUTPUT_BUCKET, f"{OUTPUT_PREFIX}evidence/h1_rank_correlation.json", h1)
    upload_json(s3, OUTPUT_BUCKET, f"{OUTPUT_PREFIX}evidence/h2_calibration_bins.json", h2)
    upload_json(s3, OUTPUT_BUCKET, f"{OUTPUT_PREFIX}evidence/h3_error_separation.json", h3)
    upload_json(s3, OUTPUT_BUCKET, f"{OUTPUT_PREFIX}evidence/h4_inversion_detection.json", h4)

    # Decision tree
    results = [h1, h2, h3, h4]
    n_pass = sum(1 for r in results if r["pass"])
    overall = "PASS" if n_pass >= 3 else "FAIL"

    elapsed = time.time() - START_TIME
    report = {
        "experiment": "F001-KAPPA-VS-SIMPLEX",
        "claims": ["C1", "C2"],
        "status": overall,
        "n_pass": n_pass,
        "n_total": 4,
        "pass_threshold": 3,
        "hypotheses": {
            "H1_rank_correlation": h1["pass"],
            "H2_calibration_bins": h2["pass"],
            "H3_error_separation": h3["pass"],
            "H4_inversion_detection": h4["pass"],
        },
        "circuit_breaker": {
            "triggered": overall == "FAIL",
            "action": "soften C1 title" if n_pass < 3 else None,
        },
        "instance_type": INSTANCE_TYPE,
        "start_time": START_ISO,
        "end_time": datetime.now(timezone.utc).isoformat(),
        "wall_clock_seconds": round(elapsed, 1),
        "n_models": len(models),
    }
    upload_json(s3, OUTPUT_BUCKET, f"{OUTPUT_PREFIX}report.json", report)

    log("=" * 60)
    log(f"F001 {overall}: {n_pass}/4 hypotheses pass (need 3)")
    for r in results:
        log(f"  {r['hypothesis']}: {'PASS' if r['pass'] else 'FAIL'}")
    log(f"Wall-clock: {elapsed:.1f}s on {INSTANCE_TYPE}")
    log("=" * 60)


if __name__ == "__main__":
    main()
