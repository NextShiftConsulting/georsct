# DOE: F001-KAPPA-VS-SIMPLEX — Scalar kappa vs R/S/N Simplex Comparison

**Experiment ID:** F001-KAPPA-VS-SIMPLEX
**Namespace:** RSCT-Framework
**Claims:** C1 (Representation adequacy is not scalar), C2 (R/S/N exposes failure modes hidden by scalar kappa)
**Status:** DRAFT
**Created:** 2026-05-02
**Registry ref:** EXPERIMENT_REGISTRY.md, Day 3

---

## Abstract

Compare scalar kappa (kappa = R*(1-N)) against the full R/S/N simplex triple on the text
retrieval evaluation task (16 embedding families on MIRACL). The experiment tests whether
the simplex decomposition provides evaluation information that scalar kappa alone cannot.
This is the title-level claim of the paper: if kappa is sufficient, the R/S/N decomposition
is a complexity overhead with no benefit.

---

## Hypotheses

### H1: Rank Correlation

**Statement:** The rank-order correlation between simplex-derived quality (alpha = R/(R+N))
and downstream task performance differs from the rank-order correlation between scalar kappa
and the same task performance.

| Variable Type | Description |
|---------------|-------------|
| Independent | Evaluation method: scalar kappa vs simplex alpha |
| Dependent | Spearman rho(evaluation rank, task performance rank) |
| Control | Same 16 models, same MIRACL task, same OOF predictions |

**Metrics:**
- `rho_kappa`: Spearman correlation between kappa rank and accuracy rank
- `rho_alpha`: Spearman correlation between alpha rank and accuracy rank (known: 0.31)
- `delta_rho`: rho_alpha - rho_kappa

**Pass condition:** rho_alpha != rho_kappa (different information content, regardless of direction).
Stronger pass: |rho_alpha| > |rho_kappa| (simplex is more informative).

**Evidence required:** `evidence/h1_rank_correlation.json`

### H2: Calibration Bins

**Statement:** When models are binned by simplex region (R-dominant, S-dominant, N-dominant,
balanced), the within-bin performance variance is lower than when binned by scalar kappa
quantiles of equal count.

| Variable Type | Description |
|---------------|-------------|
| Independent | Binning method: simplex region vs kappa quartile |
| Dependent | Within-bin variance of task performance |
| Control | Same 16 models |

**Metrics:**
- `var_simplex_bins`: mean within-bin variance using simplex regions
- `var_kappa_bins`: mean within-bin variance using kappa quartiles
- `variance_ratio`: var_kappa_bins / var_simplex_bins

**Pass condition:** variance_ratio > 1.0 (simplex bins are tighter).

**Evidence required:** `evidence/h2_calibration_bins.json`

### H3: Error Separation

**Statement:** The R/S/N decomposition separates models into structurally distinct error
profiles that scalar kappa collapses. Specifically, models with similar kappa but different
R/S/N triples exhibit different confusion matrix patterns.

| Variable Type | Description |
|---------------|-------------|
| Independent | Evaluation representation: scalar kappa vs (R, S, N) triple |
| Dependent | Pairwise confusion matrix distance (Jensen-Shannon or Frobenius) |
| Control | Model pairs matched on kappa (+/- 0.01) |

**Metrics:**
- `n_kappa_matched_pairs`: count of model pairs within kappa tolerance
- `mean_confusion_distance`: mean pairwise confusion distance within matched pairs
- `distance_vs_simplex_distance`: correlation between confusion distance and simplex distance

**Pass condition:** Kappa-matched pairs have non-trivial confusion distance (> random baseline),
AND confusion distance correlates with simplex distance (rho > 0.3).

**Evidence required:** `evidence/h3_error_separation.json`

### H4: Inversion Detection

**Statement:** The simplex representation detects rank inversions (model A ranks higher than
model B by accuracy but lower by structural quality) that scalar kappa misses.

| Variable Type | Description |
|---------------|-------------|
| Independent | Evaluation method: scalar kappa rank vs simplex alpha rank |
| Dependent | Number of detected rank inversions (>= 3 positions) |
| Control | Same 16 models, same accuracy ranking |

**Metrics:**
- `inversions_kappa`: count of 3+ position inversions between accuracy and kappa ranking
- `inversions_alpha`: count of 3+ position inversions between accuracy and alpha ranking (known: 9/16 = 56%)
- `unique_inversions`: inversions detected by alpha but not by kappa

**Pass condition:** unique_inversions > 0 (simplex detects inversions kappa misses).

**Evidence required:** `evidence/h4_inversion_detection.json`

---

## Data Sources

| Source | Type | Size | Location |
|--------|------|------|----------|
| Text leaderboard | Existing | 16 models | rsct-geocert or yrsn-train paper_data/leaderboard.json |
| Per-model certificates | Existing | 16 x (R, S, N, alpha, kappa) | Same |
| Per-model confusion matrices | Existing | 16 x 3x3 | Same |
| Per-model OOF predictions | Existing | 16 x ~30K pairs | S3 or local |

---

## Experimental Protocol

This experiment is analytical — no model training, no SageMaker. All data already exists
from the text leaderboard evaluation.

1. Load leaderboard.json with all 16 models' certificates and accuracy
2. Extract scalar kappa and simplex (R, S, N, alpha) per model
3. Compute H1: rank correlations for kappa vs alpha against accuracy
4. Compute H2: bin models by simplex region and kappa quartile; compare within-bin variance
5. Compute H3: find kappa-matched pairs; compute confusion distances; test simplex correlation
6. Compute H4: enumerate inversions under kappa ranking vs alpha ranking
7. Write evidence JSONs per hypothesis
8. Produce summary table

---

## Success Criteria

| Hypothesis | Criterion | Status |
|------------|-----------|--------|
| H1 | rho_alpha != rho_kappa | PENDING |
| H2 | variance_ratio > 1.0 | PENDING |
| H3 | confusion distance corr with simplex distance rho > 0.3 | PENDING |
| H4 | unique_inversions > 0 | PENDING |

**Overall pass:** At least 3 of 4 hypotheses pass. If all 4 fail, invoke C1 circuit breaker.

---

## Kill Condition

Scalar kappa >= simplex on ALL four metrics. Response per CLAIMS.md:
- C1 (weak): Soften title to "Toward Non-Scalar Adequacy"
- C1 (null): Slip deadline; submit to workshop or ICLR
- C1 (reverse): Publish negative result with different title

---

## Decision Tree

```
All 4 pass ──────────────── C1 + C2 fully supported. Title stands.
3 of 4 pass ─────────────── C1 + C2 supported with qualification. Note the exception.
2 of 4 pass ─────────────── Weak support. Soften title per circuit breaker.
1 of 4 pass ─────────────── C1 (null). Slip or reframe.
0 of 4 pass ─────────────── C1 (reverse). Negative result paper.
```

---

## Change Control

| Date | Change | Reason |
|------|--------|--------|
| 2026-05-02 | Initial draft | Day 1 scaffold |
