"""CLI entry point for floodcaster."""

import argparse
import logging
import sys

from floodcaster.analysis import run_flood_analysis
from floodcaster.sources import BBox, fetch_overture_count


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="floodcaster",
        description="End-to-end flood loss estimation from Overture Maps + HAZUS.",
    )
    parser.add_argument(
        "--bbox",
        nargs=4,
        type=float,
        required=True,
        metavar=("WEST", "SOUTH", "EAST", "NORTH"),
        help="Bounding box: west south east north (EPSG:4326)",
    )
    parser.add_argument(
        "--raster",
        required=True,
        help="Path to flood depth raster (GeoTIFF)",
    )
    parser.add_argument(
        "--flood-type",
        choices=["R", "C"],
        default="R",
        help="Flood type: R=Riverine, C=Coastal (default: R)",
    )
    parser.add_argument(
        "--output",
        default="floodcaster_results.parquet",
        help="Output path (.parquet or .csv, default: floodcaster_results.parquet)",
    )
    parser.add_argument(
        "--release",
        default=None,
        help="Overture Maps release version (default: latest)",
    )
    parser.add_argument(
        "--s3-raster",
        default=None,
        help="S3 key for raster (downloads to /tmp, e.g. 'rasters/Oahu.tif')",
    )
    parser.add_argument(
        "--s3-output",
        default=None,
        help="S3 key to upload results (e.g. 'results/oahu_2026-06-01.parquet')",
    )
    parser.add_argument(
        "--count-only",
        action="store_true",
        help="Only count buildings in bbox, don't run analysis",
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable verbose logging",
    )

    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )

    bbox = BBox(*args.bbox)

    if args.count_only:
        count = fetch_overture_count(bbox, release=args.release or "2026-05-20.0")
        print(f"Buildings in bbox: {count:,}")
        return 0

    # S3 raster download
    raster_path = args.raster
    if args.s3_raster:
        from floodcaster.s3 import download_file
        raster_path = f"/tmp/{args.s3_raster.split('/')[-1]}"
        download_file(args.s3_raster, raster_path)

    result = run_flood_analysis(
        bbox=bbox,
        raster_path=raster_path,
        flood_type=args.flood_type,
        output_path=args.output,
        overture_release=args.release,
    )

    # S3 output upload
    if args.s3_output and args.output:
        from floodcaster.s3 import upload_file
        uri = upload_file(args.output, args.s3_output)
        print(f"Results uploaded: {uri}")

    # Print summary
    if not result.empty:
        # Find actual column names (FastBuildings may remap them)
        def _find_col(result, *keywords):
            for c in result.columns:
                cl = c.lower()
                if all(k in cl for k in keywords):
                    return c
            return None

        bl = _find_col(result, "loss", "bldg") or _find_col(result, "building_loss")
        cl = _find_col(result, "loss", "cont") or _find_col(result, "content_loss")
        dp = _find_col(result, "dmg", "pct", "bldg") or _find_col(result, "building_damage")

        print(f"\n{'='*60}")
        print(f"Floodcaster Results Summary")
        print(f"{'='*60}")
        print(f"Buildings analyzed:    {len(result):,}")
        print(f"Flood type:            {args.flood_type}")
        total_bldg = result[bl].sum(skipna=True) if bl else 0
        total_cont = result[cl].sum(skipna=True) if cl else 0
        print(f"Total building loss:   ${total_bldg:,.0f}")
        print(f"Total content loss:    ${total_cont:,.0f}")
        print(f"Total combined loss:   ${total_bldg + total_cont:,.0f}")
        if dp:
            avg_pct = result[dp].mean(skipna=True)
            print(f"Avg damage %:          {avg_pct:.1f}%")
        print(f"Output:                {args.output}")
        print(f"{'='*60}")
    else:
        print("No buildings found in the specified bounding box.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
