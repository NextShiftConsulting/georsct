"""Floodcaster: end-to-end flood loss estimation pipeline.

Public API
----------
Analysis (primary entry points):
    run_flood_analysis      -- Overture buildings + HAZUS depth-damage
    run_nsi_flood_analysis  -- NSI 2.0 buildings + HAZUS depth-damage
    compute_ead             -- Expected Annual Damage across return periods

Data sources:
    fetch_overture_buildings -- query Overture Maps building footprints
    fetch_nsi_by_fips       -- query NSI 2.0 by county FIPS codes
    fetch_nsi_by_bbox       -- query NSI 2.0 by bounding box
    BBox                    -- bounding box dataclass

Aggregation:
    aggregate_by_zcta           -- spatial join buildings to ZCTA polygons (6 stats)
    aggregate_by_zcta_extended  -- extended aggregation with depth percentiles (11 stats)

Hydrology (DEM-derived features):
    compute_hand            -- Height Above Nearest Drainage
    compute_spi             -- Stream Power Index
    compute_twi             -- Topographic Wetness Index
    compute_gfi             -- Geomorphic Flood Index
    compute_flow_accumulation -- D8 flow accumulation
    zonal_hydro_stats       -- zonal stats of hydro rasters over polygons

Engine (sphere re-exports for direct access):
    from floodcaster.engine import FastBuildings, HazusFloodAnalysis, ...
"""

__version__ = "0.3.0"

from floodcaster.aggregation import aggregate_by_zcta, aggregate_by_zcta_extended
from floodcaster.analysis import compute_ead, run_flood_analysis, run_nsi_flood_analysis
from floodcaster.hydrology import (
    compute_flow_accumulation,
    compute_gfi,
    compute_hand,
    compute_spi,
    compute_twi,
    zonal_hydro_stats,
)
from floodcaster.nsi_sources import fetch_nsi_by_bbox, fetch_nsi_by_fips
from floodcaster.sources import BBox, fetch_overture_buildings

__all__ = [
    # Analysis
    "run_flood_analysis",
    "run_nsi_flood_analysis",
    "compute_ead",
    # Sources
    "BBox",
    "fetch_overture_buildings",
    "fetch_nsi_by_fips",
    "fetch_nsi_by_bbox",
    # Aggregation
    "aggregate_by_zcta",
    "aggregate_by_zcta_extended",
    # Hydrology
    "compute_hand",
    "compute_spi",
    "compute_twi",
    "compute_gfi",
    "compute_flow_accumulation",
    "zonal_hydro_stats",
]
