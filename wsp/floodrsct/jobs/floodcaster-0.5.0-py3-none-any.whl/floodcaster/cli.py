"""CLI entry point for floodcaster.

Two operating modes:
    floodcaster --mode default --bbox W S E N [--return-period 100]
    floodcaster --mode raster  --bbox W S E N --raster depth.tif

Legacy form (without --mode) defaults to raster mode:
    floodcaster --bbox W S E N --raster depth.tif
"""

import argparse
import json
import logging
import sys

from floodcaster.sources import BBox, fetch_overture_count


def _build_parser() -> argparse.ArgumentParser:
    """Build the argument parser (extracted for testability)."""
    parser = argparse.ArgumentParser(
        prog="floodcaster",
        description="Flood loss estimation with evidence certificates.",
    )
    parser.add_argument(
        "--bbox",
        nargs=4,
        type=float,
        required=True,
        metavar=("WEST", "SOUTH", "EAST", "NORTH"),
        help="Bounding box: west south east north (EPSG:4326)",
    )
    parser.add_argument(
        "--mode",
        choices=["default", "raster"],
        default=None,
        help="Operating mode: default (Deltares depth) or raster (user-supplied GeoTIFF)",
    )
    parser.add_argument(
        "--raster",
        default=None,
        help="Path to flood depth raster (GeoTIFF). Required for raster mode.",
    )
    parser.add_argument(
        "--flood-type",
        choices=["R", "C"],
        default="C",
        help="Flood type: R=Riverine, C=Coastal (default: C)",
    )
    parser.add_argument(
        "--return-period",
        type=int,
        choices=[2, 5, 10, 25, 50, 100, 250],
        default=100,
        help="Return period in years (default mode only, default: 100)",
    )
    parser.add_argument(
        "--scenario",
        choices=["current", "2050_rcp85"],
        default="current",
        help="Sea level scenario (default mode only, default: current)",
    )
    parser.add_argument(
        "--dem",
        choices=["NASADEM", "MERITDEM", "LIDAR"],
        default="NASADEM",
        help="Deltares DEM source (default mode only, default: NASADEM)",
    )
    parser.add_argument(
        "--resolution",
        choices=["90m", "1km", "5km"],
        default="90m",
        help="Deltares resolution (default mode only, default: 90m)",
    )
    parser.add_argument(
        "--output",
        default="floodcaster_results.parquet",
        help="Output path (.parquet or .csv, default: floodcaster_results.parquet)",
    )
    parser.add_argument(
        "--release",
        default=None,
        help="Overture Maps release version (default: latest)",
    )
    parser.add_argument(
        "--s3-raster",
        default=None,
        help="S3 key for raster (downloads to /tmp)",
    )
    parser.add_argument(
        "--s3-output",
        default=None,
        help="S3 key to upload results",
    )
    parser.add_argument(
        "--count-only",
        action="store_true",
        help="Only count buildings in bbox, don't run analysis",
    )
    parser.add_argument(
        "--certificate-json",
        default=None,
        help="Path to write evidence certificate JSON (default mode only)",
    )
    parser.add_argument(
        "--live",
        action="store_true",
        help="Include live layers (Sentinel-1 SAR, HRRR precipitation) in default mode",
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable verbose logging",
    )
    return parser


def _find_col(result, *keywords):
    """Find a column whose lowercase name contains all keywords."""
    for c in result.columns:
        cl = c.lower()
        if all(k in cl for k in keywords):
            return c
    return None


def _print_summary(result, flood_type, output_path):
    """Print the standard results summary table."""
    bl = _find_col(result, "loss", "bldg") or _find_col(result, "building_loss")
    cl = _find_col(result, "loss", "cont") or _find_col(result, "content_loss")
    dp = _find_col(result, "dmg", "pct", "bldg") or _find_col(result, "building_damage")

    print(f"\n{'=' * 60}")
    print("Floodcaster Results Summary")
    print(f"{'=' * 60}")
    print(f"Buildings analyzed:    {len(result):,}")
    print(f"Flood type:            {flood_type}")
    total_bldg = result[bl].sum(skipna=True) if bl else 0
    total_cont = result[cl].sum(skipna=True) if cl else 0
    print(f"Total building loss:   ${total_bldg:,.0f}")
    print(f"Total content loss:    ${total_cont:,.0f}")
    print(f"Total combined loss:   ${total_bldg + total_cont:,.0f}")
    if dp:
        avg_pct = result[dp].mean(skipna=True)
        print(f"Avg damage %:          {avg_pct:.1f}%")
    print(f"Output:                {output_path}")
    print(f"{'=' * 60}")


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
    )

    bbox = BBox(*args.bbox)

    if args.count_only:
        count = fetch_overture_count(bbox, release=args.release or "2026-05-20.0")
        print(f"Buildings in bbox: {count:,}")
        return 0

    # Resolve mode: if --raster is given without --mode, default to raster mode
    mode = args.mode
    if mode is None:
        mode = "raster" if args.raster else "default"

    if mode == "raster":
        if not args.raster and not args.s3_raster:
            parser.error("Raster mode requires --raster or --s3-raster")

        from floodcaster.analysis import run_flood_analysis

        raster_path = args.raster
        if args.s3_raster:
            from floodcaster.s3 import download_file
            raster_path = f"/tmp/{args.s3_raster.split('/')[-1]}"
            download_file(args.s3_raster, raster_path)

        result = run_flood_analysis(
            bbox=bbox,
            raster_path=raster_path,
            flood_type=args.flood_type,
            output_path=args.output,
            overture_release=args.release,
        )

        if not result.empty:
            _print_summary(result, args.flood_type, args.output)
        else:
            print("No buildings found in the specified bounding box.")

    elif mode == "default":
        from floodcaster.analysis import run_default_analysis

        analysis_result = run_default_analysis(
            bbox=bbox,
            return_period=args.return_period,
            dem=args.dem,
            resolution=args.resolution,
            scenario=args.scenario,
            flood_type=args.flood_type,
            overture_release=args.release,
            output_path=args.output,
            include_live=args.live,
        )

        result = analysis_result.buildings
        cert = analysis_result.certificate

        if not result.empty:
            _print_summary(result, args.flood_type, args.output)

        # Print certificate
        print(f"\n{'=' * 60}")
        print("Evidence Certificate")
        print(f"{'=' * 60}")
        print(f"Verdict:   {cert.verdict.value.upper()}")
        print(f"Reason:    {cert.reason}")
        print(f"Mode:      {cert.mode}")
        for layer in cert.layers:
            print(f"  [{layer.status.value:12s}] {layer.role.value}: {layer.source}")
            if layer.detail:
                print(f"               {layer.detail}")
        print(f"\nPublic message:")
        print(f"  {cert.public_summary()}")
        print(f"{'=' * 60}")

        # Write certificate JSON
        if args.certificate_json:
            with open(args.certificate_json, "w") as f:
                json.dump(cert.to_dict(), f, indent=2)
            print(f"Certificate saved to {args.certificate_json}")

    # S3 output upload
    if args.s3_output and args.output:
        from floodcaster.s3 import upload_file
        uri = upload_file(args.output, args.s3_output)
        print(f"Results uploaded: {uri}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
