"""Planetary Computer STAC client: search, sign, read COG windows.

All Planetary Computer access is funneled through this module. No other
floodcaster module should import pystac_client or planetary_computer directly.

Usage:
    from floodcaster.stac import get_deltares_depth
    from floodcaster.sources import BBox

    bbox = BBox(-90.1, 29.9, -89.9, 30.1)
    depth_arr, transform = get_deltares_depth(bbox, return_period=100)
"""

import logging
from dataclasses import dataclass, field

import numpy as np
import planetary_computer
import pystac_client
import rasterio
from floodcaster.sources import BBox

logger = logging.getLogger(__name__)

STAC_API_URL = "https://planetarycomputer.microsoft.com/api/stac/v1"

# Deltares valid parameter spaces
DELTARES_RETURN_PERIODS = [2, 5, 10, 25, 50, 100, 250]
DELTARES_DEMS = ["NASADEM", "MERITDEM", "LIDAR"]
DELTARES_RESOLUTIONS = ["90m", "1km", "5km"]
DELTARES_SCENARIOS = ["current", "2050_rcp85"]

# JRC Global Surface Water collection
JRC_COLLECTION = "jrc-gsw"


@dataclass(frozen=True)
class DeltaresQuery:
    """Parameters for querying Deltares Global Flood Maps.

    Args:
        return_period: Flood return period in years.
        dem: Digital elevation model source.
        resolution: Spatial resolution.
        scenario: Sea level scenario.
    """

    return_period: int = 100
    dem: str = "NASADEM"
    resolution: str = "90m"
    scenario: str = "current"

    def __post_init__(self):
        if self.return_period not in DELTARES_RETURN_PERIODS:
            raise ValueError(
                f"return_period must be one of {DELTARES_RETURN_PERIODS}, "
                f"got {self.return_period}"
            )
        if self.dem not in DELTARES_DEMS:
            raise ValueError(
                f"dem must be one of {DELTARES_DEMS}, got {self.dem}"
            )
        if self.resolution not in DELTARES_RESOLUTIONS:
            raise ValueError(
                f"resolution must be one of {DELTARES_RESOLUTIONS}, "
                f"got {self.resolution}"
            )


def _get_client() -> pystac_client.Client:
    """Open a STAC client with Planetary Computer token signing."""
    return pystac_client.Client.open(
        STAC_API_URL,
        modifier=planetary_computer.sign_inplace,
    )


def search_collection(
    collection: str,
    bbox: BBox,
    query: dict | None = None,
    max_items: int = 50,
) -> list:
    """Search a Planetary Computer STAC collection by bbox.

    Args:
        collection: STAC collection ID (e.g. "deltares-floods").
        bbox: Geographic bounding box.
        query: Additional STAC query filters.
        max_items: Maximum items to return.

    Returns:
        List of pystac Items matching the query.
    """
    client = _get_client()
    search = client.search(
        collections=[collection],
        bbox=bbox.to_tuple(),
        query=query or {},
        max_items=max_items,
    )
    items = list(search.items())
    logger.info(
        "STAC search: collection=%s, bbox=%s, found %d items",
        collection, bbox.to_tuple(), len(items),
    )
    return items


def read_cog_window(
    href: str,
    bbox: BBox,
) -> tuple[np.ndarray, "rasterio.Affine"]:
    """Read a windowed region from a Cloud-Optimized GeoTIFF.

    Only downloads the tiles covering the bbox -- no full-file download.

    Args:
        href: Signed URL or path to a COG asset.
        bbox: Geographic bounding box to extract.

    Returns:
        Tuple of (2D numpy array, rasterio Affine transform for the window).
    """
    with rasterio.open(href) as src:
        window = src.window(*bbox.to_tuple())
        arr = np.squeeze(src.read(1, window=window)).astype(np.float64)
        transform = src.window_transform(window)
        nodata = src.nodata
        if nodata is not None:
            arr[arr == nodata] = np.nan
    logger.info(
        "COG window read: %d x %d pixels from %s",
        arr.shape[0], arr.shape[1], href[:80],
    )
    return arr, transform


def get_deltares_depth(
    bbox: BBox,
    query: DeltaresQuery | None = None,
) -> tuple[np.ndarray, "rasterio.Affine"]:
    """Fetch Deltares flood depth raster for a bounding box.

    This is the primary entry point for Mode A -- Authoritative Scenario Depth.
    Searches the Deltares Global Flood Maps collection on Planetary Computer,
    selects the best-matching item, and reads the depth COG for the bbox.

    Deltares depth values are in meters. This function converts to feet
    (HAZUS convention) before returning.

    Args:
        bbox: Geographic bounding box.
        query: Deltares query parameters (return period, DEM, resolution, scenario).

    Returns:
        Tuple of (depth array in feet, rasterio Affine transform).

    Raises:
        RuntimeError: If no matching Deltares data found for the bbox/query.
    """
    if query is None:
        query = DeltaresQuery()

    items = search_collection(
        "deltares-floods",
        bbox,
        query={
            "deltares:dem_name": {"eq": query.dem},
            "deltares:resolution": {"eq": query.resolution},
            "deltares:return_period": {"eq": query.return_period},
            "deltares:sea_level_year": {
                "eq": 2018 if query.scenario == "current" else 2050,
            },
        },
    )

    if not items:
        raise RuntimeError(
            f"No Deltares flood data found for bbox={bbox.to_tuple()}, "
            f"return_period={query.return_period}, dem={query.dem}, "
            f"resolution={query.resolution}, scenario={query.scenario}"
        )

    # Use the first matching item (Deltares tiles are global mosaics)
    item = items[0]
    # Deltares items have a "data" asset key for the flood depth COG
    asset_key = "data"
    if asset_key not in item.assets:
        # Fall back to first available asset
        asset_key = next(iter(item.assets))
        logger.warning(
            "Deltares item %s missing 'data' asset, using '%s'",
            item.id, asset_key,
        )

    href = item.assets[asset_key].href
    logger.info(
        "Deltares depth: item=%s, RP=%d yr, DEM=%s, res=%s",
        item.id, query.return_period, query.dem, query.resolution,
    )

    depth_m, transform = read_cog_window(href, bbox)

    # Convert meters to feet (HAZUS convention)
    meters_to_feet = 3.28084
    depth_ft = depth_m * meters_to_feet

    logger.info(
        "Deltares depth converted: median=%.2f ft, max=%.2f ft, "
        "%.1f%% inundated",
        float(np.nanmedian(depth_ft[depth_ft > 0])) if np.any(depth_ft > 0) else 0.0,
        float(np.nanmax(depth_ft)) if np.any(np.isfinite(depth_ft)) else 0.0,
        float(np.sum(depth_ft > 0) / max(np.sum(np.isfinite(depth_ft)), 1) * 100),
    )
    return depth_ft, transform


def get_jrc_water_occurrence(
    bbox: BBox,
) -> tuple[np.ndarray, "rasterio.Affine"]:
    """Fetch JRC Global Surface Water occurrence for a bounding box.

    Returns percentage of time each pixel was observed as water (0-100)
    over the 1984-2020 Landsat record.

    Args:
        bbox: Geographic bounding box.

    Returns:
        Tuple of (occurrence percentage array 0-100, rasterio Affine transform).

    Raises:
        RuntimeError: If no JRC data found for the bbox.
    """
    items = search_collection(JRC_COLLECTION, bbox, max_items=10)

    if not items:
        raise RuntimeError(
            f"No JRC Surface Water data found for bbox={bbox.to_tuple()}"
        )

    item = items[0]
    # JRC items have an "occurrence" asset
    asset_key = "occurrence"
    if asset_key not in item.assets:
        asset_key = next(iter(item.assets))
        logger.warning(
            "JRC item %s missing 'occurrence' asset, using '%s'",
            item.id, asset_key,
        )

    href = item.assets[asset_key].href
    occurrence, transform = read_cog_window(href, bbox)

    logger.info(
        "JRC water occurrence: median=%.1f%%, max=%.1f%%, "
        "%.1f%% of pixels ever wet",
        float(np.nanmedian(occurrence)) if np.any(np.isfinite(occurrence)) else 0.0,
        float(np.nanmax(occurrence)) if np.any(np.isfinite(occurrence)) else 0.0,
        float(np.sum(occurrence > 0) / max(np.sum(np.isfinite(occurrence)), 1) * 100),
    )
    return occurrence, transform


# Sentinel-1 SAR flood detection constants
S1_COLLECTION = "sentinel-1-rtc"
S1_VV_THRESHOLD_DB = -15.0
S1_VV_THRESHOLD_LINEAR = 10 ** (S1_VV_THRESHOLD_DB / 10)


def get_sentinel1_flood_mask(
    bbox: BBox,
    vv_threshold_linear: float = S1_VV_THRESHOLD_LINEAR,
) -> tuple[np.ndarray, "datetime", str]:
    """Derive a binary flood mask from Sentinel-1 SAR VV backscatter.

    Water appears dark in SAR VV (specular reflection away from sensor).
    Pixels with VV below the threshold are classified as water.

    Args:
        bbox: Geographic bounding box.
        vv_threshold_linear: VV threshold in linear scale. Pixels below
            this value are classified as water. Default ~0.0316 (-15 dB).

    Returns:
        Tuple of (binary mask uint8, acquisition datetime, detail string).

    Raises:
        RuntimeError: If no Sentinel-1 items found or no VV asset.
    """
    from datetime import datetime

    items = search_collection(S1_COLLECTION, bbox)

    if not items:
        raise RuntimeError(
            f"No Sentinel-1 RTC data found for bbox={bbox.to_tuple()}"
        )

    # Select most recent item by datetime
    item = max(items, key=lambda it: it.datetime)

    if "vv" not in item.assets:
        raise RuntimeError(
            f"Sentinel-1 item {item.id} has no VV asset. "
            f"Available: {list(item.assets.keys())}"
        )

    href = item.assets["vv"].href
    vv_arr, _ = read_cog_window(href, bbox)

    # Threshold: VV < threshold -> water (1), else dry (0)
    mask = (vv_arr < vv_threshold_linear).astype(np.uint8)

    total_pixels = mask.size
    water_pixels = int(np.sum(mask))
    pct = water_pixels / max(total_pixels, 1) * 100

    acq_dt: datetime = item.datetime
    detail = (
        f"SAR VV < {S1_VV_THRESHOLD_DB:.0f} dB, "
        f"{pct:.1f}% of pixels classified as water, "
        f"acquired {acq_dt}"
    )

    logger.info(
        "Sentinel-1 flood mask: item=%s, %d/%d water pixels (%.1f%%)",
        item.id, water_pixels, total_pixels, pct,
    )
    return mask, acq_dt, detail


def jrc_centroid_occurrence(
    centroids: "pd.DataFrame",
    id_col: str = "zcta_id",
    lat_col: str = "lat",
    lon_col: str = "lon",
    buffer_deg: float = 0.01,
) -> "pd.DataFrame":
    """Extract JRC water occurrence stats per centroid point.

    Fetches JRC Global Surface Water from Planetary Computer for the
    bounding box of all centroids, then samples a buffer around each
    point to compute mean occurrence, max occurrence, and fraction of
    pixels that have ever been wet.

    Designed to integrate with the s035 ZCTA-centroid pipeline: pass a
    DataFrame of (zcta_id, lat, lon) and get back a merge-ready DataFrame.

    Args:
        centroids: DataFrame with at least id, lat, lon columns.
        id_col: Column name for the point identifier.
        lat_col: Column name for latitude (WGS84).
        lon_col: Column name for longitude (WGS84).
        buffer_deg: Buffer radius in degrees (~0.01 deg ~ 1 km at mid-latitudes).

    Returns:
        DataFrame with columns: [id_col, jrc_occurrence_mean,
        jrc_occurrence_max, jrc_pct_ever_wet].
    """
    import pandas as pd
    from rasterio.transform import rowcol

    if centroids.empty:
        return pd.DataFrame({
            id_col: [],
            "jrc_occurrence_mean": [],
            "jrc_occurrence_max": [],
            "jrc_pct_ever_wet": [],
        })

    # Compute overall bbox with buffer
    west = centroids[lon_col].min() - buffer_deg
    south = centroids[lat_col].min() - buffer_deg
    east = centroids[lon_col].max() + buffer_deg
    north = centroids[lat_col].max() + buffer_deg
    bbox = BBox(west, south, east, north)

    # Fetch JRC occurrence for full extent (one STAC call)
    try:
        occurrence, transform = get_jrc_water_occurrence(bbox)
    except RuntimeError:
        logger.warning("No JRC data for centroid extent, returning NaN")
        return pd.DataFrame({
            id_col: centroids[id_col].values,
            "jrc_occurrence_mean": np.nan,
            "jrc_occurrence_max": np.nan,
            "jrc_pct_ever_wet": np.nan,
        })

    rows = occurrence.shape[0]
    cols = occurrence.shape[1]

    records = []
    for _, pt in centroids.iterrows():
        lat, lon = pt[lat_col], pt[lon_col]

        # Buffer corners in pixel space
        r_min, c_min = rowcol(transform, lon - buffer_deg, lat + buffer_deg)
        r_max, c_max = rowcol(transform, lon + buffer_deg, lat - buffer_deg)

        # Clamp to array bounds
        r_min = max(0, min(int(r_min), rows - 1))
        r_max = max(0, min(int(r_max), rows - 1))
        c_min = max(0, min(int(c_min), cols - 1))
        c_max = max(0, min(int(c_max), cols - 1))

        if r_min > r_max or c_min > c_max:
            records.append({
                id_col: pt[id_col],
                "jrc_occurrence_mean": np.nan,
                "jrc_occurrence_max": np.nan,
                "jrc_pct_ever_wet": np.nan,
            })
            continue

        patch = occurrence[r_min:r_max + 1, c_min:c_max + 1]
        valid = patch[np.isfinite(patch)]

        if len(valid) == 0:
            records.append({
                id_col: pt[id_col],
                "jrc_occurrence_mean": np.nan,
                "jrc_occurrence_max": np.nan,
                "jrc_pct_ever_wet": np.nan,
            })
            continue

        records.append({
            id_col: pt[id_col],
            "jrc_occurrence_mean": float(np.mean(valid)),
            "jrc_occurrence_max": float(np.max(valid)),
            "jrc_pct_ever_wet": float(np.sum(valid > 0) / len(valid) * 100),
        })

    result = pd.DataFrame(records)
    logger.info(
        "JRC centroid occurrence: %d points, %.1f%% with data",
        len(result),
        float(result["jrc_occurrence_mean"].notna().mean() * 100),
    )
    return result


def get_dem_elevation(
    bbox: BBox,
    collection: str = "cop-dem-glo-30",
) -> tuple[np.ndarray, "rasterio.Affine"]:
    """Fetch DEM elevation for a bounding box.

    Supports Copernicus DEM (global, 30m) and 3DEP (US, 10m).

    Args:
        bbox: Geographic bounding box.
        collection: STAC collection ID. Options:
            - "cop-dem-glo-30": Copernicus GLO-30 (global, ~30m)
            - "3dep-seamless": USGS 3DEP (US only, 10m)

    Returns:
        Tuple of (elevation array in meters, rasterio Affine transform).

    Raises:
        RuntimeError: If no DEM data found for the bbox.
    """
    items = search_collection(collection, bbox, max_items=10)

    if not items:
        raise RuntimeError(
            f"No DEM data found for bbox={bbox.to_tuple()}, "
            f"collection={collection}"
        )

    item = items[0]
    # Copernicus DEM uses "data" asset; 3DEP uses "data" or "elevation"
    asset_key = "data"
    if asset_key not in item.assets:
        for candidate in ["elevation", "image"]:
            if candidate in item.assets:
                asset_key = candidate
                break
        else:
            asset_key = next(iter(item.assets))

    href = item.assets[asset_key].href
    elevation, transform = read_cog_window(href, bbox)

    logger.info(
        "DEM elevation: collection=%s, median=%.1f m, range=[%.1f, %.1f] m",
        collection,
        float(np.nanmedian(elevation)),
        float(np.nanmin(elevation)) if np.any(np.isfinite(elevation)) else 0.0,
        float(np.nanmax(elevation)) if np.any(np.isfinite(elevation)) else 0.0,
    )
    return elevation, transform
