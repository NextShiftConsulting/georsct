"""S3 utilities for floodcaster: upload/download rasters, results, and DuckDB caches."""

import logging
from pathlib import Path

import os

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)

BUCKET = os.environ.get("BUCKET", "swarm-floodcaster")
PREFIX = "runs"


def get_s3_client():
    """Get S3 client using default credential chain (IAM role on ECS, profile locally)."""
    return boto3.client("s3")


def download_file(s3_key: str, local_path: str) -> str:
    """Download a file from S3.

    Args:
        s3_key: S3 object key (e.g. 'rasters/Oahu_10_withReef.tif').
        local_path: Local path to save the file.

    Returns:
        The local path.
    """
    s3 = get_s3_client()
    logger.info("Downloading s3://%s/%s -> %s", BUCKET, s3_key, local_path)
    Path(local_path).parent.mkdir(parents=True, exist_ok=True)
    s3.download_file(BUCKET, s3_key, local_path)
    return local_path


def upload_file(local_path: str, s3_key: str) -> str:
    """Upload a file to S3.

    Args:
        local_path: Local file path.
        s3_key: S3 object key.

    Returns:
        The S3 URI.
    """
    s3 = get_s3_client()
    logger.info("Uploading %s -> s3://%s/%s", local_path, BUCKET, s3_key)
    s3.upload_file(local_path, BUCKET, s3_key)
    return f"s3://{BUCKET}/{s3_key}"


def cache_exists(s3_key: str) -> bool:
    """Check if an S3 key exists."""
    s3 = get_s3_client()
    try:
        s3.head_object(Bucket=BUCKET, Key=s3_key)
        return True
    except ClientError:
        return False
