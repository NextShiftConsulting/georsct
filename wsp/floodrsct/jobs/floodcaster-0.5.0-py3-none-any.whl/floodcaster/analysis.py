"""Analysis layer: wire building inventories into sphere HAZUS engine.

Core functions:
    run_flood_analysis      -- Overture buildings + single-event loss
    run_nsi_flood_analysis  -- NSI 2.0 buildings + single-event loss
    compute_ead             -- Expected Annual Damage across return periods
"""

import logging
from pathlib import Path

import geopandas as gpd
import numpy as np
import pandas as pd

from sphere.core.schemas.fast_buildings import FastBuildings
from sphere.flood.analysis.hazus_flood import HazusFloodAnalysis
from sphere.flood.default_vulnerability import DefaultFloodVulnerability
from sphere.flood.single_value_reader import SingleValueRaster

from floodcaster.sources import BBox, fetch_overture_buildings

logger = logging.getLogger(__name__)

# Column overrides: map sphere field aliases to Overture/NSI column names.
# Both Overture and NSI use the same sphere-compatible names after mapping
# in their respective sources modules.
_SPHERE_OVERRIDES = {
    "id": "id",
    "occupancy_type": "occupancy_type",
    "first_floor_height": "first_floor_height",
    "foundation_type": "foundation_type",
    "number_stories": "number_stories",
    "area": "area",
    "building_cost": "building_cost",
    "content_cost": "content_cost",
}


def run_flood_analysis(
    bbox: BBox,
    raster_path: str,
    flood_type: str = "R",
    output_path: str | None = None,
    overture_release: str | None = None,
) -> gpd.GeoDataFrame:
    """Run end-to-end flood loss estimation.

    Args:
        bbox: Geographic bounding box for building query.
        raster_path: Path to flood depth raster (GeoTIFF).
        flood_type: "R" (Riverine) or "C" (Coastal).
        output_path: Optional path to save results (.parquet or .csv).
        overture_release: Overture Maps release version override.

    Returns:
        GeoDataFrame with loss estimates per building.
    """
    # 1. Fetch buildings
    kwargs = {}
    if overture_release:
        kwargs["release"] = overture_release
    gdf = fetch_overture_buildings(bbox, **kwargs)

    if gdf.empty:
        logger.warning("No buildings found in bounding box")
        return gdf

    # 2. Save to temp CSV for sphere's FastBuildings loader
    tmp_csv = Path(raster_path).parent / "_floodcaster_tmp_buildings.csv"
    gdf.to_csv(tmp_csv, index=False)

    try:
        buildings = FastBuildings(str(tmp_csv), overrides=_SPHERE_OVERRIDES)

        # 3. Run HAZUS vulnerability + loss calculation
        #    HazusFloodAnalysis handles depth sampling internally
        raster = SingleValueRaster(raster_path)
        vulnerability = DefaultFloodVulnerability(buildings, flood_type)
        analysis = HazusFloodAnalysis(buildings, vulnerability, raster)
        analysis.calculate_losses()

        result_gdf = buildings.gdf
        loss_col = buildings.fields.get_field_name("building_loss")
        logger.info(
            "Analysis complete: %d buildings, total loss $%.2f",
            len(result_gdf),
            result_gdf[loss_col].sum(skipna=True) if loss_col in result_gdf.columns else 0,
        )

        if output_path:
            output = Path(output_path)
            if output.suffix == ".parquet":
                result_gdf.to_parquet(output, compression="zstd")
            else:
                result_gdf.to_csv(output, index=False)
            logger.info("Results saved to %s", output_path)

        return result_gdf

    finally:
        if tmp_csv.exists():
            tmp_csv.unlink()


def run_nsi_flood_analysis(
    raster_path: str,
    fips_codes: list[str] | None = None,
    bbox: BBox | None = None,
    flood_type: str = "R",
    output_path: str | None = None,
) -> gpd.GeoDataFrame:
    """Run end-to-end flood loss estimation using NSI 2.0 buildings.

    Mirrors run_flood_analysis() but sources buildings from the USACE
    National Structure Inventory instead of Overture Maps. NSI provides
    surveyed building attributes (occupancy, stories, first-floor height,
    replacement value) so HAZUS results are higher fidelity.

    Args:
        raster_path: Path to flood depth raster (GeoTIFF, depth in feet).
        fips_codes: County FIPS codes to fetch buildings for.
        bbox: Bounding box alternative to FIPS (one of fips_codes or bbox required).
        flood_type: "R" (Riverine) or "C" (Coastal).
        output_path: Optional path to save results (.parquet or .csv).

    Returns:
        GeoDataFrame with per-building loss estimates.
    """
    from floodcaster.nsi_sources import fetch_nsi_by_bbox, fetch_nsi_by_fips

    if fips_codes is None and bbox is None:
        raise ValueError("Provide either fips_codes or bbox")

    # 1. Fetch NSI buildings
    if fips_codes:
        gdf = fetch_nsi_by_fips(fips_codes)
    else:
        gdf = fetch_nsi_by_bbox(bbox)

    if gdf.empty:
        logger.warning("No NSI buildings found")
        return gdf

    logger.info("NSI buildings fetched: %d structures", len(gdf))

    # 2. Write to temp CSV for sphere's FastBuildings loader
    tmp_csv = Path(raster_path).parent / "_floodcaster_tmp_nsi.csv"
    gdf.to_csv(tmp_csv, index=False)

    try:
        buildings = FastBuildings(str(tmp_csv), overrides=_SPHERE_OVERRIDES)

        # 3. Run HAZUS depth-damage
        raster = SingleValueRaster(raster_path)
        vulnerability = DefaultFloodVulnerability(buildings, flood_type)
        analysis = HazusFloodAnalysis(buildings, vulnerability, raster)
        analysis.calculate_losses()

        result_gdf = buildings.gdf
        loss_col = buildings.fields.get_field_name("building_loss")
        logger.info(
            "NSI analysis complete: %d buildings, total loss $%.2f",
            len(result_gdf),
            result_gdf[loss_col].sum(skipna=True) if loss_col in result_gdf.columns else 0,
        )

        if output_path:
            output = Path(output_path)
            if output.suffix == ".parquet":
                result_gdf.to_parquet(output, compression="zstd")
            else:
                result_gdf.to_csv(output, index=False)
            logger.info("NSI results saved to %s", output_path)

        return result_gdf

    finally:
        if tmp_csv.exists():
            tmp_csv.unlink()


# ---------------------------------------------------------------------------
# Expected Annual Damage (EAD)
# ---------------------------------------------------------------------------

def compute_ead(
    losses_by_return_period: dict[float, float | pd.Series],
) -> float | pd.Series:
    """Compute Expected Annual Damage via trapezoidal integration.

    EAD integrates the damage-exceedance curve:
        EAD = integral of L(p) dp
    where p = annual exceedance probability (1/return_period) and
    L(p) = loss at that probability level.

    Inspired by CanFlood and FloodRiskSwatPlus EAD methodology.

    Args:
        losses_by_return_period: Mapping of return period (years) to total
            loss value(s). Can be scalar (single zone) or pd.Series
            (vectorized over zones). Example:
                {10: 50_000, 50: 200_000, 100: 500_000, 500: 1_200_000}

    Returns:
        EAD value (scalar or Series matching input shape).

    Example:
        >>> losses = {10: 50_000, 50: 200_000, 100: 500_000, 500: 1_200_000}
        >>> ead = compute_ead(losses)
        >>> print(f"EAD = ${ead:,.0f}")
    """
    if len(losses_by_return_period) < 2:
        raise ValueError("EAD requires at least 2 return periods")

    # Sort by return period (ascending RP = descending probability)
    sorted_rp = sorted(losses_by_return_period.keys())
    probs = [1.0 / rp for rp in sorted_rp]
    losses = [losses_by_return_period[rp] for rp in sorted_rp]

    # probs is in descending order (10yr=0.1, 50yr=0.02, 100yr=0.01, 500yr=0.002)
    # Trapezoidal integration over exceedance probability
    ead = 0.0 if isinstance(losses[0], (int, float)) else pd.Series(0.0, index=losses[0].index)

    for i in range(len(probs) - 1):
        dp = probs[i] - probs[i + 1]  # positive (decreasing probability)
        avg_loss = (losses[i] + losses[i + 1]) / 2.0
        ead += dp * avg_loss

    # Tail: extrapolate from smallest prob to p=0 (assume loss at rarest event)
    ead += probs[-1] * losses[-1] / 2.0

    # Head: extrapolate from largest prob to p=1 (assume zero loss at 1yr event
    # unless provided -- conservative lower bound)
    if probs[0] < 1.0:
        ead += (1.0 - probs[0]) * losses[0] / 2.0

    if isinstance(ead, (int, float)):
        logger.info(
            "EAD computed: $%.0f from %d return periods [%s yr]",
            ead, len(sorted_rp), ", ".join(str(int(rp)) for rp in sorted_rp),
        )
    else:
        logger.info(
            "EAD computed for %d zones from %d return periods [%s yr]",
            len(ead), len(sorted_rp),
            ", ".join(str(int(rp)) for rp in sorted_rp),
        )
    return ead


# ---------------------------------------------------------------------------
# Default Analysis (Mode 1 -- Scenario Loss)
# ---------------------------------------------------------------------------

from dataclasses import dataclass

from floodcaster.certificate import (
    EvidenceCertificate,
    LayerRole,
)
from floodcaster.layers import LayerResult, resolve_layers
from floodcaster.stac import DeltaresQuery


@dataclass
class DefaultAnalysisResult:
    """Result of a default (Mode 1) flood analysis.

    Attributes:
        buildings: GeoDataFrame with per-building loss estimates.
        certificate: Evidence certificate with verdict and layer status.
    """

    buildings: gpd.GeoDataFrame
    certificate: EvidenceCertificate

    def to_dict(self) -> dict:
        """Serialize to JSON-compatible dict (excludes buildings GeoDataFrame)."""
        return {
            "n_buildings": len(self.buildings),
            "certificate": self.certificate.to_dict(),
            "technical_summary": self.certificate.technical_summary(),
            "public_summary": self.certificate.public_summary(),
        }


def _run_sphere_on_depth_array(
    buildings_gdf: gpd.GeoDataFrame,
    depth_array: np.ndarray,
    transform: "rasterio.Affine",
    flood_type: str = "C",
) -> gpd.GeoDataFrame:
    """Run sphere HAZUS analysis using an in-memory depth array.

    Writes depth array to a temporary GeoTIFF, then runs the standard
    sphere pipeline. This bridges the gap between STAC-fetched rasters
    (numpy arrays) and sphere's SingleValueRaster (expects file path).

    Args:
        buildings_gdf: Buildings with sphere-compatible columns.
        depth_array: 2D flood depth array in feet.
        transform: Rasterio Affine transform for the depth array.
        flood_type: "R" (Riverine) or "C" (Coastal).

    Returns:
        GeoDataFrame with loss columns added by sphere.
    """
    import tempfile
    import rasterio
    from rasterio.crs import CRS

    # Write depth array to temp GeoTIFF
    with tempfile.NamedTemporaryFile(suffix=".tif", delete=False) as tmp:
        tmp_path = tmp.name

    profile = {
        "driver": "GTiff",
        "dtype": "float64",
        "width": depth_array.shape[1],
        "height": depth_array.shape[0],
        "count": 1,
        "crs": CRS.from_epsg(4326),
        "transform": transform,
        "nodata": np.nan,
    }
    with rasterio.open(tmp_path, "w", **profile) as dst:
        dst.write(depth_array, 1)

    try:
        # Write buildings to temp CSV for sphere
        tmp_csv = Path(tmp_path).with_suffix(".csv")
        buildings_gdf.to_csv(tmp_csv, index=False)

        try:
            buildings = FastBuildings(str(tmp_csv), overrides=_SPHERE_OVERRIDES)
            raster = SingleValueRaster(tmp_path)
            vulnerability = DefaultFloodVulnerability(buildings, flood_type)
            analysis = HazusFloodAnalysis(buildings, vulnerability, raster)
            analysis.calculate_losses()
            return buildings.gdf
        finally:
            if tmp_csv.exists():
                tmp_csv.unlink()
    finally:
        Path(tmp_path).unlink(missing_ok=True)


def run_default_analysis(
    bbox: BBox,
    return_period: int = 100,
    dem: str = "NASADEM",
    resolution: str = "90m",
    scenario: str = "current",
    flood_type: str = "C",
    overture_release: str | None = None,
    include_jrc: bool = True,
    include_dem: bool = True,
    include_live: bool = False,
    dem_collection: str = "cop-dem-glo-30",
    output_path: str | None = None,
) -> DefaultAnalysisResult:
    """Run Mode 1 -- Scenario Loss using Deltares default depth.

    This is the primary entry point for certificate-backed flood analysis.
    No user-supplied raster needed: depth comes from Planetary Computer.

    Args:
        bbox: Geographic bounding box.
        return_period: Deltares return period in years (2, 5, 10, 25, 50, 100, 250).
        dem: Deltares DEM source (NASADEM, MERITDEM, LIDAR).
        resolution: Deltares resolution (90m, 1km, 5km).
        scenario: Sea level scenario (current, 2050_rcp85).
        flood_type: "R" (Riverine) or "C" (Coastal).
        overture_release: Overture Maps release version override.
        include_jrc: Whether to resolve JRC historical layer.
        include_dem: Whether to resolve DEM terrain layer.
        include_live: Whether to include live layers (Sentinel-1 SAR, HRRR precip).
        dem_collection: STAC collection for DEM (cop-dem-glo-30 or 3dep-seamless).
        output_path: Optional path to save results (.parquet or .csv).

    Returns:
        DefaultAnalysisResult with buildings GeoDataFrame and certificate.
    """
    deltares_query = DeltaresQuery(
        return_period=return_period,
        dem=dem,
        resolution=resolution,
        scenario=scenario,
    )

    # 1. Resolve all layers
    layer_results = resolve_layers(
        bbox,
        deltares_query=deltares_query,
        dem_collection=dem_collection,
        include_jrc=include_jrc,
        include_dem=include_dem,
        include_sentinel1=include_live,
        include_hrrr=include_live,
    )

    # 2. Fetch buildings
    kwargs = {}
    if overture_release:
        kwargs["release"] = overture_release
    buildings_gdf = fetch_overture_buildings(bbox, **kwargs)

    if buildings_gdf.empty:
        logger.warning("No buildings found in bounding box for default analysis")
        evidence = [r.to_evidence() for r in layer_results]
        cert = EvidenceCertificate(
            layers=evidence, n_buildings=0, total_loss_usd=0.0,
            mode="scenario_loss",
        )
        return DefaultAnalysisResult(buildings=buildings_gdf, certificate=cert)

    # 3. Check if depth layer is available
    depth_layer = next(
        (r for r in layer_results if r.role == LayerRole.SCENARIO_HAZARD),
        None,
    )

    if depth_layer is None or depth_layer.data is None:
        # No depth data -- return buildings with certificate showing ESCALATE
        evidence = [r.to_evidence() for r in layer_results]
        cert = EvidenceCertificate(
            layers=evidence,
            n_buildings=len(buildings_gdf),
            total_loss_usd=0.0,
            mode="scenario_loss",
        )
        return DefaultAnalysisResult(buildings=buildings_gdf, certificate=cert)

    # 4. Run HAZUS via sphere
    result_gdf = _run_sphere_on_depth_array(
        buildings_gdf, depth_layer.data, depth_layer.transform, flood_type,
    )

    # 5. Compute total loss
    loss_col = None
    for c in result_gdf.columns:
        if "loss" in c.lower() and "bldg" in c.lower():
            loss_col = c
            break
    total_loss = float(result_gdf[loss_col].sum(skipna=True)) if loss_col else 0.0

    # 6. Build certificate
    evidence = [r.to_evidence() for r in layer_results]
    cert = EvidenceCertificate(
        layers=evidence,
        n_buildings=len(result_gdf),
        total_loss_usd=total_loss,
        mode="scenario_loss",
    )

    logger.info(
        "Default analysis complete: %s", cert.technical_summary(),
    )

    # 7. Save output
    if output_path:
        output = Path(output_path)
        if output.suffix == ".parquet":
            result_gdf.to_parquet(output, compression="zstd")
        else:
            result_gdf.to_csv(output, index=False)
        logger.info("Default analysis results saved to %s", output_path)

    return DefaultAnalysisResult(buildings=result_gdf, certificate=cert)
