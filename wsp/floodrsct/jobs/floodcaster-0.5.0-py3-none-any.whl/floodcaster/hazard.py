"""Gauge and forecast-derived flood hazard metrics.

Pure functions -- no I/O, no S3, no SQL.

Complements hydrology.py (DEM-derived features) with metrics derived from
gauge observations and forecasts: crest margin, NWS severity, rate of rise,
depth above ground, freeboard, discharge percentile, encounter probability.

Tier 1 metrics (Manning's equation, rating curves, Log-Pearson III) are
computed upstream by USGS/NWS/FEMA -- Floodcaster ingests those as certified
inputs. HAZUS depth-damage is a table lookup in sphere-flood, consumed via
floodcaster.engine. The functions here are Tier 2: formulas Floodcaster's
scoring engine actually evaluates.

Each function carries the formula in its docstring for audit traceability.

References:
    NWS AHPS flood categories: https://water.weather.gov/ahps/
    Weibull plotting position: Bulletin 17C, USGS
    Encounter probability: FEMA P-259
"""

from __future__ import annotations

import enum
import math
from dataclasses import dataclass
from typing import Optional

import numpy as np


# ---------------------------------------------------------------------------
# Temporal basis enum
# ---------------------------------------------------------------------------

class TemporalBasis(enum.Enum):
    """Distinguishes observed vs. forecast hazard readings.

    Every hazard reading should carry a temporal_basis so downstream consumers
    know whether a crest value is 6 hours old or 48 hours out.
    """
    OBSERVED = "observed"
    NOWCAST = "nowcast"
    FORECAST = "forecast"


# ---------------------------------------------------------------------------
# NWS severity categories
# ---------------------------------------------------------------------------

class NWSSeverity(enum.Enum):
    """NWS AHPS flood severity categories, ordered by increasing severity."""
    NO_FLOODING = "no_flooding"
    ACTION = "action"
    MINOR = "minor"
    MODERATE = "moderate"
    MAJOR = "major"


@dataclass(frozen=True)
class GageThresholds:
    """NWS AHPS flood-stage thresholds for a single gage (ft).

    Source: AHPS XML/API per gage. Each gage has its own four thresholds.
    Set a threshold to None if the gage does not define that level.
    """
    action: Optional[float] = None
    minor: Optional[float] = None
    moderate: Optional[float] = None
    major: Optional[float] = None


# ---------------------------------------------------------------------------
# Metric functions
# ---------------------------------------------------------------------------

def crest_margin(
    h_crest_forecast: float,
    h_flood_stage: float,
) -> float:
    """Forecast crest exceedance above the gage's flood stage.

    Formula:
        dH = H_crest_forecast - H_flood_stage    [ft]

    Positive values indicate the forecast exceeds flood stage.
    This is the primary signal for whether a gage will flood.

    Args:
        h_crest_forecast: Forecast crest stage (ft above datum).
        h_flood_stage: NWS flood stage for this gage (ft above datum).

    Returns:
        Crest margin in feet. Positive = exceedance.
    """
    return h_crest_forecast - h_flood_stage


def nws_severity(
    h_forecast: float,
    thresholds: GageThresholds,
) -> NWSSeverity:
    """Classify forecast stage into NWS AHPS severity category.

    Formula:
        severity = max{ c in {Action, Minor, Moderate, Major} : H >= threshold_c }

    Each gage carries its own four thresholds from AHPS. The function bins
    the forecast crest into the highest exceeded category.

    Thresholds set to None are skipped — if a gage defines minor but not
    moderate or major, a stage exceeding minor returns MINOR regardless
    of how high the stage is. This matches AHPS behavior where not all
    gages have all four thresholds defined.

    Args:
        h_forecast: Forecast or observed stage (ft above datum).
        thresholds: Per-gage AHPS thresholds.

    Returns:
        Highest NWS severity category that the stage exceeds.
    """
    if thresholds.major is not None and h_forecast >= thresholds.major:
        return NWSSeverity.MAJOR
    if thresholds.moderate is not None and h_forecast >= thresholds.moderate:
        return NWSSeverity.MODERATE
    if thresholds.minor is not None and h_forecast >= thresholds.minor:
        return NWSSeverity.MINOR
    if thresholds.action is not None and h_forecast >= thresholds.action:
        return NWSSeverity.ACTION
    return NWSSeverity.NO_FLOODING


def rate_of_rise(
    h_t: float,
    h_prev: float,
    dt_hours: float,
) -> float:
    """Rate of stage change over a time interval.

    Formula:
        dH/dt = (H_t - H_{t-dt}) / dt    [ft/hr]

    A steep positive dH/dt compresses lead time for resident action.
    For a 24-72 hr horizon, this is arguably the single most
    decision-relevant derived quantity.

    Args:
        h_t: Stage at current time (ft).
        h_prev: Stage at previous time (ft).
        dt_hours: Time interval in hours (must be > 0).

    Returns:
        Rate of rise in ft/hr. Positive = rising.

    Raises:
        ValueError: If dt_hours <= 0.
    """
    if dt_hours <= 0:
        raise ValueError(f"dt_hours must be positive, got {dt_hours}")
    return (h_t - h_prev) / dt_hours


def rate_of_rise_series(
    stages: np.ndarray,
    dt_hours: float,
) -> np.ndarray:
    """Rate of rise for an evenly-spaced stage timeseries.

    Formula:
        dH/dt_i = (H_i - H_{i-1}) / dt    for i = 1..n-1

    First element is NaN (no prior observation).

    Args:
        stages: 1D array of stage readings (ft), evenly spaced.
        dt_hours: Time step between consecutive readings in hours.

    Returns:
        Array of same length as stages, with dH/dt in ft/hr.
    """
    if dt_hours <= 0:
        raise ValueError(f"dt_hours must be positive, got {dt_hours}")
    if len(stages) == 0:
        return np.array([], dtype=np.float64)
    result = np.empty_like(stages, dtype=np.float64)
    result[0] = np.nan
    result[1:] = np.diff(stages) / dt_hours
    return result


def depth_above_ground(
    wse: float,
    z_ground: float,
) -> float:
    """Estimated flood depth at a point.

    Formula:
        d = WSE - z_ground    [ft]

    Only valid where terrain elevation is available. Negative values
    indicate the water surface is below ground level (no flooding).

    Args:
        wse: Water surface elevation (ft, same datum as z_ground).
        z_ground: Ground elevation (ft above datum).

    Returns:
        Depth in feet. Positive = inundation.
    """
    return wse - z_ground


def freeboard(
    lowest_floor_elevation: float,
    bfe: float,
) -> float:
    """Freeboard above the base flood elevation.

    Formula:
        F = LFE - BFE    [ft]

    Negative freeboard = structure floor is below the 1% annual-chance
    flood level. A key vulnerability indicator for NFIP rating.

    Args:
        lowest_floor_elevation: Lowest floor elevation of the structure (ft).
        bfe: FEMA base flood elevation for the location (ft).

    Returns:
        Freeboard in feet. Negative = below BFE.
    """
    return lowest_floor_elevation - bfe


def discharge_exceedance(
    rank: int,
    n_observations: int,
) -> float:
    """Empirical exceedance probability via Weibull plotting position.

    Formula:
        p = m / (n + 1)

    where m is the rank (1 = largest) and n is the total number of
    annual peak observations. Returns exceedance probability: rank 1
    (the largest observation) yields the smallest p (most extreme),
    rank n (the smallest) yields the largest p (most common).

    To convert to non-exceedance percentile: ``1 - p``.

    Args:
        rank: Rank of the observation (1 = largest, n = smallest).
        n_observations: Total number of observations in the record.

    Returns:
        Exceedance probability in (0, 1). Smaller = more extreme.

    Raises:
        ValueError: If rank < 1 or rank > n_observations or n_observations < 1.
    """
    if n_observations < 1:
        raise ValueError(f"n_observations must be >= 1, got {n_observations}")
    if rank < 1 or rank > n_observations:
        raise ValueError(
            f"rank must be in [1, {n_observations}], got {rank}"
        )
    return rank / (n_observations + 1)


def encounter_probability(
    return_period: float,
    n_years: float,
) -> float:
    """Probability of at least one event over an n-year horizon.

    Formula:
        R = 1 - (1 - 1/T)^n

    where T is the return period in years and n is the planning horizon.
    Useful for translating AEP into decision-relevant messaging
    (e.g., "26% chance over a 30-year mortgage").

    Uses ``-expm1(n * log1p(-1/T))`` for numerical stability when T
    is large (avoids catastrophic cancellation in ``1 - (1-eps)^n``).

    Args:
        return_period: Return period T in years (must be finite and > 0).
        n_years: Planning horizon in years (must be finite and >= 0).

    Returns:
        Encounter probability in [0, 1].

    Raises:
        ValueError: If inputs are non-finite, return_period <= 0, or n_years < 0.
    """
    if not math.isfinite(return_period) or return_period <= 0:
        raise ValueError(
            f"return_period must be finite and positive, got {return_period}"
        )
    if not math.isfinite(n_years) or n_years < 0:
        raise ValueError(
            f"n_years must be finite and non-negative, got {n_years}"
        )
    if return_period <= 1.0:
        # Sub-annual return period: 1/T > 1, so (1-1/T) is negative.
        # log1p would hit math domain error. Use direct formula instead
        # (no precision issue since 1/T is not small).
        return 1.0 - (1.0 - 1.0 / return_period) ** n_years
    # -expm1(x) = 1 - exp(x), stable for small 1/T
    return -math.expm1(n_years * math.log1p(-1.0 / return_period))
