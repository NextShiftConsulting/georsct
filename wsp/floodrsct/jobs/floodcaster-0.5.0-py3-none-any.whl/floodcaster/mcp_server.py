"""Floodcaster MCP server — flood hazard metrics as agent-callable tools.

Exposes floodcaster.hazard pure functions via the Model Context Protocol
(streamable HTTP transport, spec 2025-11-25). Agents can discover and call
crest_margin, nws_severity, rate_of_rise, encounter_probability, etc.

Run standalone:
    python -m floodcaster.mcp_server                  # streamable-http on :8000
    python -m floodcaster.mcp_server --port 9000      # custom port
    python -m floodcaster.mcp_server --transport stdio # for local piped usage

Deploy on Lambda:
    The ``lambda_handler`` is a Mangum-wrapped ASGI handler. Point your
    Lambda Function URL at ``floodcaster.mcp_server.lambda_handler``.

Or import ``mcp_app`` and mount in an existing ASGI app.
"""

from __future__ import annotations

import argparse
import os
import sys
from typing import Optional

from mcp.server.fastmcp import FastMCP
from mcp.server.transport_security import TransportSecuritySettings

from floodcaster.hazard import (
    GageThresholds,
    NWSSeverity,
    crest_margin,
    depth_above_ground,
    discharge_exceedance,
    encounter_probability,
    freeboard,
    nws_severity,
    rate_of_rise,
)

# On Lambda, the Function URL hostname isn't localhost. AWS IAM auth is
# the security perimeter, so we disable the SDK's DNS rebinding check.
_on_lambda = "AWS_LAMBDA_FUNCTION_NAME" in os.environ

_transport_security = TransportSecuritySettings(
    enable_dns_rebinding_protection=not _on_lambda,
) if _on_lambda else None

mcp = FastMCP(
    "Floodcaster",
    instructions=(
        "Flood hazard metrics server. Provides Tier 2 gauge/forecast-derived "
        "metrics: crest margin, NWS severity classification, rate of rise, "
        "depth above ground, freeboard, discharge exceedance probability, "
        "and encounter probability. All functions are pure (no I/O). "
        "Units are feet and hours unless noted."
    ),
    stateless_http=True,
    json_response=True,
    transport_security=_transport_security,
)


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

@mcp.tool()
def calc_crest_margin(
    h_crest_forecast: float,
    h_flood_stage: float,
) -> dict:
    """Forecast crest exceedance above flood stage.

    Formula: dH = H_crest_forecast - H_flood_stage  [ft]

    Positive = forecast exceeds flood stage.
    This is the primary signal for whether a gage will flood.

    Args:
        h_crest_forecast: Forecast crest stage (ft above datum).
        h_flood_stage: NWS flood stage for this gage (ft above datum).

    Returns:
        crest_margin_ft: Margin in feet. Positive = exceedance.
    """
    margin = crest_margin(h_crest_forecast, h_flood_stage)
    return {
        "crest_margin_ft": margin,
        "exceeds_flood_stage": margin > 0,
    }


@mcp.tool()
def classify_nws_severity(
    h_forecast: float,
    action: Optional[float] = None,
    minor: Optional[float] = None,
    moderate: Optional[float] = None,
    major: Optional[float] = None,
) -> dict:
    """Classify forecast stage into NWS AHPS severity category.

    Bins the forecast into the highest exceeded category from
    {no_flooding, action, minor, moderate, major}.

    Thresholds set to None are skipped -- if a gage defines minor but
    not moderate or major, a stage exceeding minor returns MINOR
    regardless of how high the stage is.

    Args:
        h_forecast: Forecast or observed stage (ft above datum).
        action: Action stage threshold (ft), or None if not defined.
        minor: Minor flood stage threshold (ft), or None.
        moderate: Moderate flood stage threshold (ft), or None.
        major: Major flood stage threshold (ft), or None.

    Returns:
        severity: NWS category name.
        severity_rank: Numeric rank (0=no_flooding .. 4=major).
    """
    thresholds = GageThresholds(
        action=action, minor=minor, moderate=moderate, major=major,
    )
    severity = nws_severity(h_forecast, thresholds)
    rank_map = {
        NWSSeverity.NO_FLOODING: 0,
        NWSSeverity.ACTION: 1,
        NWSSeverity.MINOR: 2,
        NWSSeverity.MODERATE: 3,
        NWSSeverity.MAJOR: 4,
    }
    return {
        "severity": severity.value,
        "severity_rank": rank_map[severity],
    }


@mcp.tool()
def calc_rate_of_rise(
    h_t: float,
    h_prev: float,
    dt_hours: float,
) -> dict:
    """Rate of stage change over a time interval.

    Formula: dH/dt = (H_t - H_prev) / dt  [ft/hr]

    A steep positive dH/dt compresses lead time for action.

    Args:
        h_t: Stage at current time (ft).
        h_prev: Stage at previous time (ft).
        dt_hours: Time interval in hours (must be > 0).

    Returns:
        rate_ft_per_hr: Rate of rise (positive = rising).
        rising: Whether stage is increasing.
    """
    rate = rate_of_rise(h_t, h_prev, dt_hours)
    return {
        "rate_ft_per_hr": round(rate, 4),
        "rising": rate > 0,
    }


@mcp.tool()
def calc_depth_above_ground(
    wse: float,
    z_ground: float,
) -> dict:
    """Estimated flood depth at a point.

    Formula: d = WSE - z_ground  [ft]

    Args:
        wse: Water surface elevation (ft, same datum as z_ground).
        z_ground: Ground elevation (ft above datum).

    Returns:
        depth_ft: Depth in feet. Positive = inundation.
        flooded: Whether the point is inundated.
    """
    d = depth_above_ground(wse, z_ground)
    return {
        "depth_ft": round(d, 2),
        "flooded": d > 0,
    }


@mcp.tool()
def calc_freeboard(
    lowest_floor_elevation: float,
    bfe: float,
) -> dict:
    """Freeboard above the FEMA base flood elevation.

    Formula: F = LFE - BFE  [ft]

    Negative = structure floor is below the 1% annual-chance flood level.

    Args:
        lowest_floor_elevation: Lowest floor elevation of structure (ft).
        bfe: FEMA base flood elevation (ft).

    Returns:
        freeboard_ft: Freeboard in feet. Negative = below BFE.
        below_bfe: Whether the structure is below BFE.
    """
    f = freeboard(lowest_floor_elevation, bfe)
    return {
        "freeboard_ft": round(f, 2),
        "below_bfe": f < 0,
    }


@mcp.tool()
def calc_discharge_exceedance(
    rank: int,
    n_observations: int,
) -> dict:
    """Empirical exceedance probability via Weibull plotting position.

    Formula: p = m / (n + 1)

    where m = rank (1 = largest), n = total annual peak observations.
    Returns exceedance probability: rank 1 yields smallest p (most extreme).

    Args:
        rank: Rank of observation (1 = largest, n = smallest).
        n_observations: Total number of observations in record.

    Returns:
        exceedance_probability: Probability in (0, 1). Smaller = more extreme.
        return_period_years: Approximate return period (1/p).
    """
    p = discharge_exceedance(rank, n_observations)
    return {
        "exceedance_probability": round(p, 6),
        "return_period_years": round(1.0 / p, 1),
    }


@mcp.tool()
def calc_encounter_probability(
    return_period: float,
    n_years: float,
) -> dict:
    """Probability of at least one flood event over an n-year horizon.

    Formula: R = 1 - (1 - 1/T)^n

    Useful for translating AEP into decision-relevant messaging
    (e.g., "26% chance over a 30-year mortgage").

    Args:
        return_period: Return period T in years (must be > 0, finite).
        n_years: Planning horizon in years (must be >= 0, finite).

    Returns:
        encounter_probability: Probability in [0, 1].
        encounter_pct: Same as percentage string for display.
    """
    p = encounter_probability(return_period, n_years)
    return {
        "encounter_probability": round(p, 6),
        "encounter_pct": f"{p * 100:.1f}%",
    }


@mcp.tool()
def run_scenario_loss(
    west: float,
    south: float,
    east: float,
    north: float,
    return_period: int = 100,
    flood_type: str = "C",
    dem: str = "NASADEM",
    resolution: str = "90m",
    scenario: str = "current",
) -> dict:
    """Run Mode 1 -- Scenario Loss using Deltares default depth.

    No user-supplied raster needed. Fetches authoritative flood depth
    from Planetary Computer, queries Overture Maps buildings, runs
    HAZUS depth-damage, and returns a loss estimate with an evidence
    certificate.

    The certificate carries a verdict (TRUST/REVIEW/ESCALATE) based
    on which data layers were available.

    Args:
        west: Bounding box west longitude.
        south: Bounding box south latitude.
        east: Bounding box east longitude.
        north: Bounding box north latitude.
        return_period: Flood return period in years (2, 5, 10, 25, 50, 100, 250).
        flood_type: C (Coastal) or R (Riverine). Default: C.
        dem: Deltares DEM source (NASADEM, MERITDEM, LIDAR). Default: NASADEM.
        resolution: Deltares resolution (90m, 1km, 5km). Default: 90m.
        scenario: Sea level scenario (current, 2050_rcp85). Default: current.

    Returns:
        certificate: Evidence certificate with verdict and layer status.
        technical_summary: One-line technical summary.
        public_summary: Plain-language summary for public communication.
        n_buildings: Number of buildings analyzed.
    """
    from floodcaster.analysis import run_default_analysis
    from floodcaster.sources import BBox

    bbox = BBox(west, south, east, north)
    result = run_default_analysis(
        bbox=bbox,
        return_period=return_period,
        flood_type=flood_type,
        dem=dem,
        resolution=resolution,
        scenario=scenario,
    )
    return result.to_dict()


# ---------------------------------------------------------------------------
# Resources
# ---------------------------------------------------------------------------

@mcp.resource("floodcaster://info/metrics")
def list_metrics() -> str:
    """Catalog of available flood hazard metrics with formulas."""
    return (
        "# Floodcaster Hazard Metrics\n\n"
        "## Tier 2 (Floodcaster-computed)\n"
        "1. **crest_margin**: dH = H_crest - H_flood_stage [ft]\n"
        "2. **nws_severity**: max{c : H >= threshold_c}, c in {action,minor,moderate,major}\n"
        "3. **rate_of_rise**: dH/dt = (H_t - H_{t-1}) / dt [ft/hr]\n"
        "4. **depth_above_ground**: d = WSE - z_ground [ft]\n"
        "5. **freeboard**: F = LFE - BFE [ft]\n"
        "6. **discharge_exceedance**: p = m/(n+1) (Weibull)\n"
        "7. **encounter_probability**: R = 1 - (1-1/T)^n\n\n"
        "## Tier 1 (agency-computed, ingested as inputs)\n"
        "- Manning's equation (USGS)\n"
        "- Rating curves (USGS)\n"
        "- Log-Pearson Type III (USGS Bulletin 17C)\n"
        "- HAZUS depth-damage curves (FEMA/sphere-flood)\n\n"
        "All units: feet, hours. Datum: gage-specific (NAVD88 typical)."
    )


@mcp.resource("floodcaster://info/modes")
def list_modes() -> str:
    """Available Floodcaster operating modes."""
    return (
        "# Floodcaster Operating Modes\n\n"
        "## Mode 1: Scenario Loss (default)\n"
        "Uses Deltares Global Flood Maps from Planetary Computer.\n"
        "Input: bbox + return period + scenario year.\n"
        "Output: per-building loss estimate + evidence certificate.\n\n"
        "## Mode 2: Historical Reality Check\n"
        "Uses JRC Global Surface Water occurrence.\n"
        "Shows whether an area has historically been wet.\n\n"
        "## Mode 3: Live Event Confirmation (--live flag)\n"
        "Uses Sentinel-1 SAR flood detection from Planetary Computer.\n"
        "Detects active surface water via VV backscatter thresholding.\n"
        "Certificate role: LIVE_CONFIRMATION.\n\n"
        "## Mode 4: Pre-Flood Triage (--live flag)\n"
        "Uses HRRR 72-hour precipitation forecast from AWS Open Data.\n"
        "Flags significant rainfall as active flood driver.\n"
        "Certificate role: RAINFALL_DRIVER.\n\n"
        "## Raster Mode (legacy)\n"
        "User supplies a flood depth GeoTIFF.\n"
        "Input: bbox + raster path.\n"
        "Output: per-building loss estimate (no certificate).\n"
    )


# ---------------------------------------------------------------------------
# ASGI app (for Mangum / Lambda / external mounting)
# ---------------------------------------------------------------------------

mcp_app = mcp.streamable_http_app()

# Lambda handler — Mangum wraps the ASGI app for API Gateway / Function URL.
# Import is deferred so the module works without mangum installed (local dev).
_lambda_handler = None


def lambda_handler(event, context):
    """AWS Lambda entry point. Uses Mangum to bridge ASGI <-> Lambda event."""
    global _lambda_handler
    if _lambda_handler is None:
        from mangum import Mangum
        _lambda_handler = Mangum(mcp_app, lifespan="auto")
    return _lambda_handler(event, context)


# ---------------------------------------------------------------------------
# CLI entrypoint
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Floodcaster MCP Server")
    parser.add_argument(
        "--transport", choices=["streamable-http", "stdio"],
        default="streamable-http",
        help="MCP transport (default: streamable-http)",
    )
    parser.add_argument(
        "--port", type=int, default=8000,
        help="HTTP port (streamable-http only, default: 8000)",
    )
    parser.add_argument(
        "--host", default="127.0.0.1",
        help="Bind address (default: 127.0.0.1)",
    )
    args = parser.parse_args()

    if args.transport == "streamable-http":
        mcp.settings.port = args.port
        mcp.settings.host = args.host
    mcp.run(transport=args.transport)


if __name__ == "__main__":
    main()
