"""Evidence certificate: layer-level provenance for every flood estimate.

Each loss estimate carries an EvidenceCertificate recording which data
layers were available, their quality, and a derived verdict (ADR-031 aligned).

The certificate answers: "Should I act on this estimate?"

Verdict logic (from ADR-031):
    TRUST    -- all critical layers available, estimate is actionable
    REVIEW   -- estimate is plausible but missing supporting evidence
    ESCALATE -- critical layer missing, estimate is unreliable
    SUPPRESS -- noise / irrelevant (e.g. no flooding detected)
"""

import enum
import logging
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


class LayerRole(enum.Enum):
    """Decision role each dataset plays in a flood estimate."""

    SCENARIO_HAZARD = "scenario_hazard"
    TERRAIN_CORRECTION = "terrain_correction"
    HISTORICAL_PLAUSIBILITY = "historical_plausibility"
    LIVE_CONFIRMATION = "live_confirmation"
    RAINFALL_DRIVER = "rainfall_driver"
    EXPOSURE = "exposure"
    VULNERABILITY = "vulnerability"


class LayerStatus(enum.Enum):
    """Status of a data layer for a specific estimate."""

    AVAILABLE = "available"
    MISSING = "missing"
    HIGH = "high"
    LOW = "low"
    DETECTED = "detected"
    UNAVAILABLE = "unavailable"
    ACTIVE = "active"
    STALE = "stale"
    ASSUMED = "assumed"


class Verdict(enum.Enum):
    """Certificate verdict, aligned with ADR-031 operator verdicts.

    TRUST:    All critical layers present. Act on the estimate.
    REVIEW:   Estimate exists but supporting evidence is thin.
    ESCALATE: Critical layer missing. Do not act without review.
    SUPPRESS: No flooding signal. Do not escalate.
    """

    TRUST = "trust"
    REVIEW = "review"
    ESCALATE = "escalate"
    SUPPRESS = "suppress"


# Statuses considered "positive" (layer is usable)
_POSITIVE_STATUSES = {
    LayerStatus.AVAILABLE,
    LayerStatus.HIGH,
    LayerStatus.DETECTED,
    LayerStatus.ACTIVE,
    LayerStatus.ASSUMED,
}

# Critical roles: if missing, verdict cannot be TRUST
_CRITICAL_ROLES = {LayerRole.SCENARIO_HAZARD, LayerRole.EXPOSURE}

# Supporting roles: if missing, verdict is REVIEW (not ESCALATE)
_SUPPORTING_ROLES = {
    LayerRole.TERRAIN_CORRECTION,
    LayerRole.HISTORICAL_PLAUSIBILITY,
    LayerRole.LIVE_CONFIRMATION,
    LayerRole.RAINFALL_DRIVER,
}


@dataclass(frozen=True)
class LayerEvidence:
    """Evidence record for one data layer.

    Args:
        role: Decision role this layer fills.
        source: Dataset name (e.g. "deltares-floods", "overture", "jrc-gsw").
        status: Current status of this layer for the estimate.
        detail: Human-readable detail (e.g. "RP=100yr, DEM=NASADEM").
    """

    role: LayerRole
    source: str
    status: LayerStatus
    detail: str = ""

    def to_dict(self) -> dict:
        d = {
            "role": self.role.value,
            "source": self.source,
            "status": self.status.value,
        }
        if self.detail:
            d["detail"] = self.detail
        return d


def compute_verdict(layers: list[LayerEvidence]) -> tuple[Verdict, str]:
    """Derive verdict from layer evidence.

    Logic:
        1. If any critical role has a negative status -> ESCALATE
        2. If any supporting role has a negative status -> REVIEW
        3. If all layers positive -> TRUST
        4. If no layers at all -> ESCALATE

    Args:
        layers: List of layer evidence records.

    Returns:
        Tuple of (verdict, human-readable reason string).
    """
    if not layers:
        return Verdict.ESCALATE, "No layer evidence available"

    # Index layers by role
    by_role: dict[LayerRole, LayerEvidence] = {}
    for layer in layers:
        by_role[layer.role] = layer

    missing_critical: list[str] = []
    missing_supporting: list[str] = []

    # Check critical roles
    for role in _CRITICAL_ROLES:
        evidence = by_role.get(role)
        if evidence is None or evidence.status not in _POSITIVE_STATUSES:
            missing_critical.append(role.value)

    if missing_critical:
        reason = f"Critical layer(s) missing or unavailable: {', '.join(missing_critical)}"
        return Verdict.ESCALATE, reason

    # Check supporting roles: negative status triggers REVIEW.
    # If no supporting roles are present at all, also trigger REVIEW.
    supporting_present = [
        layer for layer in layers if layer.role in _SUPPORTING_ROLES
    ]
    for evidence in supporting_present:
        if evidence.status not in _POSITIVE_STATUSES:
            missing_supporting.append(evidence.role.value)

    if missing_supporting:
        reason = (
            f"Supporting layer(s) weak or unavailable: "
            f"{', '.join(missing_supporting)}"
        )
        return Verdict.REVIEW, reason

    if not supporting_present:
        return Verdict.REVIEW, "No supporting layers provided"

    return Verdict.TRUST, "All critical and supporting layers present"


@dataclass
class EvidenceCertificate:
    """Evidence certificate attached to every flood estimate.

    Constructed with layer evidence and estimate summary. The verdict
    and reason are computed automatically from the layers.

    Args:
        layers: List of layer evidence records.
        n_buildings: Number of buildings in the estimate.
        total_loss_usd: Total estimated loss in USD.
        mode: Operating mode that produced this estimate.
    """

    layers: list[LayerEvidence]
    n_buildings: int = 0
    total_loss_usd: float = 0.0
    mode: str = "scenario_loss"
    verdict: Verdict = field(init=False)
    reason: str = field(init=False)

    def __post_init__(self):
        self.verdict, self.reason = compute_verdict(self.layers)
        logger.info(
            "Certificate: verdict=%s, n_buildings=%d, loss=$%.0f, reason=%s",
            self.verdict.value, self.n_buildings, self.total_loss_usd, self.reason,
        )

    def to_dict(self) -> dict:
        """Serialize to JSON-compatible dict."""
        return {
            "verdict": self.verdict.value,
            "reason": self.reason,
            "mode": self.mode,
            "n_buildings": self.n_buildings,
            "total_loss_usd": self.total_loss_usd,
            "layers": [layer.to_dict() for layer in self.layers],
        }

    def technical_summary(self) -> str:
        """One-line technical summary for logs and API responses."""
        return (
            f"{self.n_buildings} buildings, "
            f"${self.total_loss_usd:,.0f} estimated loss, "
            f"verdict={self.verdict.value}: {self.reason}"
        )

    def public_summary(self) -> str:
        """Plain-language summary suitable for public communication.

        Generates a message appropriate for emergency managers to share
        with the public. Conservative: understates rather than overstates.
        """
        if self.verdict == Verdict.SUPPRESS:
            return "No significant flooding is indicated for this area."

        if self.n_buildings == 0:
            return "No buildings were identified in the analysis area."

        # Build message parts
        parts = []

        if self.total_loss_usd > 0:
            if self.total_loss_usd >= 1_000_000:
                loss_str = f"${self.total_loss_usd / 1_000_000:.1f}M"
            else:
                loss_str = f"${self.total_loss_usd:,.0f}"
            parts.append(
                f"An estimated {self.n_buildings:,} buildings may be affected, "
                f"with potential damage of {loss_str}."
            )
        else:
            parts.append(
                f"{self.n_buildings:,} buildings were analyzed. "
                "No significant damage is estimated under this scenario."
            )

        if self.verdict == Verdict.ESCALATE:
            parts.append(
                "This estimate has limited supporting data and should be "
                "reviewed by a specialist before use in public messaging."
            )
        elif self.verdict == Verdict.REVIEW:
            parts.append(
                "This estimate is based on modeled data. "
                "Residents should monitor official emergency guidance."
            )
        else:
            parts.append(
                "This estimate is supported by multiple data sources."
            )

        return " ".join(parts)
