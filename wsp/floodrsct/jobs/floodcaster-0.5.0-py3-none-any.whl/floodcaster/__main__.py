"""Allow ``python -m floodcaster.mcp_server`` to launch the MCP server."""

from floodcaster.mcp_server import main

main()
