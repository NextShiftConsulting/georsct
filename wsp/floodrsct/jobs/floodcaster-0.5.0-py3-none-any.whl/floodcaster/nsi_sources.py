"""NSI 2.0 data acquisition: query USACE National Structure Inventory API."""

import logging
import threading
import time

import geopandas as gpd
import pandas as pd
import requests
from shapely.geometry import Point

from floodcaster.sources import BBox

logger = logging.getLogger(__name__)

NSI_API_BASE = "https://nsi.sec.usace.army.mil/nsiapi/structures"
NSI_MIN_INTERVAL = 2.0  # minimum seconds between requests (protect public API)


class _RateLimiter:
    """Thread-safe rate limiter for USACE NSI API.

    Enforces a minimum interval between HTTP requests so multi-user or
    multi-thread access cannot hammer the public endpoint.
    """

    def __init__(self, min_interval: float = NSI_MIN_INTERVAL):
        self._min_interval = min_interval
        self._last_request: float = 0.0
        self._lock = threading.Lock()

    def wait(self) -> None:
        """Block until the minimum interval has elapsed since the last request."""
        with self._lock:
            now = time.monotonic()
            elapsed = now - self._last_request
            if elapsed < self._min_interval:
                delay = self._min_interval - elapsed
                logger.debug("NSI rate limiter: waiting %.1fs", delay)
                time.sleep(delay)
            self._last_request = time.monotonic()


_nsi_limiter = _RateLimiter()

# NSI fields required for HAZUS depth-damage analysis
NSI_KEEP_COLS = [
    "fd_id", "x", "y", "occtype", "sqft", "found_type",
    "num_story", "found_ht", "val_struct", "val_cont", "med_yr_blt",
    "st_damcat", "cbfips",
]

# NSI occtype uses HAZUS codes natively (RES1, COM1, IND2, etc.).
# No mapping needed — unlike Overture, which requires subtype translation.


def _parse_nsi_features(features: list[dict]) -> gpd.GeoDataFrame:
    """Parse NSI GeoJSON features into a GeoDataFrame.

    Args:
        features: List of GeoJSON Feature dicts from the NSI API.

    Returns:
        GeoDataFrame with Point geometry in EPSG:4326.
    """
    if not features:
        return gpd.GeoDataFrame()

    rows = []
    for feat in features:
        props = feat.get("properties", {})
        geom = feat.get("geometry", {})
        coords = geom.get("coordinates", [None, None])

        row = {k: props.get(k) for k in NSI_KEEP_COLS}
        # Prefer geometry coordinates; fall back to x/y properties
        if coords[0] is not None:
            row["_lon"], row["_lat"] = coords[0], coords[1]
        else:
            row["_lon"] = props.get("x")
            row["_lat"] = props.get("y")
        rows.append(row)

    df = pd.DataFrame(rows)
    geometry = [
        Point(lon, lat) if pd.notna(lon) and pd.notna(lat) else None
        for lon, lat in zip(df["_lon"], df["_lat"])
    ]
    gdf = gpd.GeoDataFrame(
        df.drop(columns=["_lon", "_lat"]), geometry=geometry, crs="EPSG:4326",
    )
    return gdf


def _map_nsi_to_sphere(gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    """Map NSI column names to sphere FastBuildings field aliases.

    Args:
        gdf: GeoDataFrame with raw NSI columns.

    Returns:
        GeoDataFrame with sphere-compatible column names added.
    """
    out = gdf.copy()
    out["id"] = out["fd_id"]
    out["occupancy_type"] = out["occtype"]
    out["first_floor_height"] = pd.to_numeric(out["found_ht"], errors="coerce").fillna(0.0)
    out["foundation_type"] = pd.to_numeric(out["found_type"], errors="coerce").fillna(7).astype(int)
    out["number_stories"] = pd.to_numeric(out["num_story"], errors="coerce").fillna(1).astype(int).clip(lower=1)
    out["area"] = pd.to_numeric(out["sqft"], errors="coerce").clip(lower=100)
    out["building_cost"] = pd.to_numeric(out["val_struct"], errors="coerce").fillna(0.0)
    out["content_cost"] = pd.to_numeric(out["val_cont"], errors="coerce").fillna(0.0)
    out["longitude"] = out.geometry.x
    out["latitude"] = out.geometry.y
    return out


def fetch_nsi_by_fips(
    fips_codes: list[str],
    deduplicate: bool = True,
) -> gpd.GeoDataFrame:
    """Fetch NSI 2.0 structures for one or more county FIPS codes.

    Args:
        fips_codes: List of 5-digit county FIPS codes.
        deduplicate: Drop duplicate fd_id values (cross-county boundaries).

    Returns:
        GeoDataFrame with NSI structures mapped to sphere-compatible columns.
    """
    frames: list[gpd.GeoDataFrame] = []

    for i, fips in enumerate(fips_codes):
        _nsi_limiter.wait()
        logger.info("Fetching NSI structures for FIPS %s (%d/%d)", fips, i + 1, len(fips_codes))
        resp = requests.get(NSI_API_BASE, params={"fips": fips}, timeout=300)

        if resp.status_code == 404:
            logger.warning("No structures for FIPS %s (404)", fips)
            continue
        resp.raise_for_status()

        features = resp.json().get("features", [])
        if not features:
            logger.warning("Empty feature collection for FIPS %s", fips)
            continue

        logger.info("FIPS %s: %d structures", fips, len(features))
        frames.append(_parse_nsi_features(features))

    if not frames:
        logger.warning("No structures fetched for FIPS codes: %s", fips_codes)
        return gpd.GeoDataFrame()

    combined = gpd.GeoDataFrame(
        pd.concat(frames, ignore_index=True), crs="EPSG:4326",
    )

    if deduplicate and "fd_id" in combined.columns:
        n_before = len(combined)
        combined = combined.drop_duplicates(subset=["fd_id"], keep="first")
        n_dupes = n_before - len(combined)
        if n_dupes:
            logger.info("Dropped %d cross-county duplicates", n_dupes)

    logger.info("Total NSI structures: %d across %d counties", len(combined), len(fips_codes))
    return _map_nsi_to_sphere(combined)


def fetch_nsi_by_bbox(bbox: BBox) -> gpd.GeoDataFrame:
    """Fetch NSI 2.0 structures within a bounding box.

    Uses the NSI API bbox parameter (lon_min,lat_min,lon_max,lat_max).

    Args:
        bbox: Geographic bounding box (EPSG:4326).

    Returns:
        GeoDataFrame with NSI structures mapped to sphere-compatible columns.
    """
    bbox_str = f"{bbox.xmin},{bbox.ymin},{bbox.xmax},{bbox.ymax}"
    _nsi_limiter.wait()
    logger.info("Fetching NSI structures for bbox=%s", bbox_str)

    resp = requests.get(
        NSI_API_BASE, params={"bbox": bbox_str}, timeout=300,
    )
    if resp.status_code == 404:
        logger.warning("No structures in bbox (404)")
        return gpd.GeoDataFrame()
    resp.raise_for_status()

    features = resp.json().get("features", [])
    if not features:
        logger.warning("Empty feature collection for bbox")
        return gpd.GeoDataFrame()

    logger.info("Fetched %d NSI structures in bbox", len(features))
    gdf = _parse_nsi_features(features)
    return _map_nsi_to_sphere(gdf)
