"""Data acquisition layer: query building inventories via DuckDB + S3."""

import logging
from dataclasses import dataclass

import duckdb
import geopandas as gpd
import numpy as np
import pandas as pd
from shapely.geometry import Point

logger = logging.getLogger(__name__)

OVERTURE_RELEASE = "2026-05-20.0"
OVERTURE_BUILDINGS_PATH = (
    f"s3://overturemaps-us-west-2/release/{OVERTURE_RELEASE}"
    "/theme=buildings/type=building/*"
)

# Overture subtype → HAZUS occupancy code mapping
SUBTYPE_TO_OCCUPANCY = {
    "residential": "RES1",
    "commercial": "COM1",
    "industrial": "IND2",
    "agricultural": "AGR1",
    "education": "EDU1",
    "entertainment": "COM8",
    "government": "GOV1",
    "medical": "COM6",
    "military": "GOV2",
    "outbuilding": "RES1",
    "religious": "REL1",
    "service": "COM3",
    "transportation": "COM7",
}

DEFAULT_OCCUPANCY = "RES1"


@dataclass
class BBox:
    """Bounding box: west, south, east, north."""

    xmin: float
    ymin: float
    xmax: float
    ymax: float

    def to_tuple(self) -> tuple[float, float, float, float]:
        return (self.xmin, self.ymin, self.xmax, self.ymax)


def _init_duckdb() -> duckdb.DuckDBPyConnection:
    """Create a DuckDB connection with spatial and S3 extensions."""
    con = duckdb.connect()
    con.sql("INSTALL httpfs; LOAD httpfs;")
    con.sql("INSTALL spatial; LOAD spatial;")
    con.sql("CREATE SECRET (TYPE S3, KEY_ID '', SECRET '', REGION 'us-west-2')")
    return con


def fetch_overture_buildings(
    bbox: BBox,
    release: str = OVERTURE_RELEASE,
) -> gpd.GeoDataFrame:
    """Fetch building footprints from Overture Maps via S3 parquet.

    Args:
        bbox: Geographic bounding box to filter buildings.
        release: Overture Maps release version.

    Returns:
        GeoDataFrame with columns mapped to sphere field aliases.
    """
    path = (
        f"s3://overturemaps-us-west-2/release/{release}"
        "/theme=buildings/type=building/*"
    )

    con = _init_duckdb()
    logger.info(
        "Querying Overture buildings: bbox=(%.2f, %.2f, %.2f, %.2f)",
        *bbox.to_tuple(),
    )

    df = con.sql(f"""
        SELECT
            id,
            subtype,
            class,
            height,
            num_floors,
            ST_X(ST_Centroid(geometry)) AS longitude,
            ST_Y(ST_Centroid(geometry)) AS latitude,
            ST_Area(geometry) * 111320 * 111320
                * COS(RADIANS(ST_Y(ST_Centroid(geometry)))) AS sqft
        FROM read_parquet('{path}', filename=true, hive_partitioning=1)
        WHERE bbox.xmin > {bbox.xmin} AND bbox.xmax < {bbox.xmax}
          AND bbox.ymin > {bbox.ymin} AND bbox.ymax < {bbox.ymax}
    """).df()

    con.close()
    logger.info("Fetched %d buildings from Overture", len(df))

    # Map Overture fields → sphere-compatible columns
    df["occupancy_type"] = (
        df["subtype"]
        .map(SUBTYPE_TO_OCCUPANCY)
        .fillna(DEFAULT_OCCUPANCY)
    )
    df["number_stories"] = df["num_floors"].fillna(1).astype(int).clip(lower=1)
    df["first_floor_height"] = np.where(df["height"].notna(), 1.0, 0.0)
    df["foundation_type"] = 7  # Default: Slab (code 7)
    df["area"] = df["sqft"].clip(lower=100)

    # Estimate replacement costs from area (rough $/sqft estimate)
    cost_per_sqft = 150.0
    df["building_cost"] = df["area"] * cost_per_sqft
    df["content_cost"] = df["building_cost"] * 0.5

    geometry = [Point(lon, lat) for lon, lat in zip(df["longitude"], df["latitude"])]
    gdf = gpd.GeoDataFrame(df, geometry=geometry, crs="EPSG:4326")

    return gdf


def fetch_overture_count(bbox: BBox, release: str = OVERTURE_RELEASE) -> int:
    """Count buildings in a bounding box without downloading all data."""
    path = (
        f"s3://overturemaps-us-west-2/release/{release}"
        "/theme=buildings/type=building/*"
    )
    con = _init_duckdb()
    result = con.sql(f"""
        SELECT count(*) AS cnt
        FROM read_parquet('{path}', filename=true, hive_partitioning=1)
        WHERE bbox.xmin > {bbox.xmin} AND bbox.xmax < {bbox.xmax}
          AND bbox.ymin > {bbox.ymin} AND bbox.ymax < {bbox.ymax}
    """).fetchone()
    con.close()
    return result[0]
