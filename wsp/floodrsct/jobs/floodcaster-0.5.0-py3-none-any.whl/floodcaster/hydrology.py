"""DEM-derived hydrology features for flood analysis.

Extracts terrain and hydrologic indicators from elevation rasters:
  - HAND (Height Above Nearest Drainage)
  - Stream Power Index (SPI)
  - Geomorphic Flood Index (GFI)
  - Flow accumulation
  - Topographic Wetness Index (TWI)

These are general-purpose flood exposure features. They require only a DEM
raster and optionally a flow direction / accumulation raster.

Design inspired by WhiteboxTools, TauDEM, and GFA-Geomorphic-Flood-Area
(clean-room implementation — no GPL code reused).

Usage:
    from floodcaster.hydrology import compute_hand, compute_spi, compute_gfi

    hand = compute_hand(dem_path, drainage_path)
    spi = compute_spi(dem_path, flow_acc_path)
    gfi = compute_gfi(dem_path, flow_acc_path)
"""

import logging
from pathlib import Path

import numpy as np
import rasterio
from rasterio.transform import rowcol

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Raster I/O helpers
# ---------------------------------------------------------------------------

def _read_raster(path: str | Path) -> tuple[np.ndarray, dict]:
    """Read a single-band raster. Returns (array, profile)."""
    with rasterio.open(path) as src:
        arr = src.read(1).astype(np.float64)
        profile = dict(src.profile)
        nodata = src.nodata
    if nodata is not None:
        arr[arr == nodata] = np.nan
    return arr, profile


def _write_raster(
    arr: np.ndarray, profile: dict, path: str | Path,
) -> None:
    """Write a single-band float64 raster."""
    out_profile = {**profile, "dtype": "float64", "count": 1, "nodata": np.nan}
    with rasterio.open(path, "w", **out_profile) as dst:
        dst.write(arr, 1)
    logger.info("Wrote raster: %s (%d x %d)", path, arr.shape[0], arr.shape[1])


def _slope_from_dem(dem: np.ndarray, cellsize: float) -> np.ndarray:
    """Compute slope in radians using 3x3 finite difference (Horn's method)."""
    padded = np.pad(dem, 1, mode="edge")
    dz_dx = (
        (padded[:-2, 2:] + 2 * padded[1:-1, 2:] + padded[2:, 2:])
        - (padded[:-2, :-2] + 2 * padded[1:-1, :-2] + padded[2:, :-2])
    ) / (8.0 * cellsize)
    dz_dy = (
        (padded[2:, :-2] + 2 * padded[2:, 1:-1] + padded[2:, 2:])
        - (padded[:-2, :-2] + 2 * padded[:-2, 1:-1] + padded[:-2, 2:])
    ) / (8.0 * cellsize)
    return np.arctan(np.sqrt(dz_dx**2 + dz_dy**2))


def _cellsize_meters(profile: dict) -> float:
    """Estimate cell size in meters from the raster profile."""
    transform = profile["transform"]
    res_x = abs(transform.a)
    crs = profile.get("crs")
    if crs and crs.is_geographic:
        # Approximate meters at mid-latitude
        mid_lat = transform.f + transform.e * profile["height"] / 2
        m_per_deg = 111_320 * np.cos(np.radians(mid_lat))
        return res_x * m_per_deg
    return res_x


# ---------------------------------------------------------------------------
# D8 flow direction + accumulation (minimal built-in implementation)
# ---------------------------------------------------------------------------

# D8 neighbor offsets: (row_delta, col_delta) for 8 directions
_D8_DR = np.array([-1, -1, 0, 1, 1, 1, 0, -1], dtype=np.intp)
_D8_DC = np.array([0, 1, 1, 1, 0, -1, -1, -1], dtype=np.intp)
_D8_DIST = np.array([1, np.sqrt(2), 1, np.sqrt(2), 1, np.sqrt(2), 1, np.sqrt(2)])


def compute_d8_flow_direction(dem_path: str | Path) -> np.ndarray:
    """Compute D8 flow direction from a DEM.

    Returns an integer array where values 0-7 indicate the steepest
    downslope neighbor direction. -1 indicates a pit/flat.
    """
    dem, _ = _read_raster(dem_path)
    rows, cols = dem.shape
    fdir = np.full((rows, cols), -1, dtype=np.int8)

    for r in range(1, rows - 1):
        for c in range(1, cols - 1):
            if np.isnan(dem[r, c]):
                continue
            max_drop = 0.0
            best = -1
            for d in range(8):
                nr, nc = r + _D8_DR[d], c + _D8_DC[d]
                if np.isnan(dem[nr, nc]):
                    continue
                drop = (dem[r, c] - dem[nr, nc]) / _D8_DIST[d]
                if drop > max_drop:
                    max_drop = drop
                    best = d
            fdir[r, c] = best

    logger.info("D8 flow direction computed: %d pits/flats", (fdir == -1).sum())
    return fdir


def compute_flow_accumulation(
    dem_path: str | Path,
    fdir: np.ndarray | None = None,
) -> np.ndarray:
    """Compute D8 flow accumulation (upstream cell count).

    Args:
        dem_path: Path to DEM raster (used if fdir not provided).
        fdir: Pre-computed D8 flow direction array (optional).

    Returns:
        Float array of upstream cell counts (including self).
    """
    dem, _ = _read_raster(dem_path)
    if fdir is None:
        fdir = compute_d8_flow_direction(dem_path)

    rows, cols = dem.shape
    acc = np.ones((rows, cols), dtype=np.float64)
    acc[np.isnan(dem)] = 0

    # Count incoming flows per cell
    in_degree = np.zeros((rows, cols), dtype=np.int32)
    for r in range(1, rows - 1):
        for c in range(1, cols - 1):
            d = fdir[r, c]
            if d < 0:
                continue
            nr, nc = r + _D8_DR[d], c + _D8_DC[d]
            if 0 <= nr < rows and 0 <= nc < cols:
                in_degree[nr, nc] += 1

    # Topological sort (Kahn's algorithm)
    from collections import deque
    queue = deque()
    for r in range(rows):
        for c in range(cols):
            if in_degree[r, c] == 0 and not np.isnan(dem[r, c]):
                queue.append((r, c))

    while queue:
        r, c = queue.popleft()
        d = fdir[r, c]
        if d < 0:
            continue
        nr, nc = r + _D8_DR[d], c + _D8_DC[d]
        if 0 <= nr < rows and 0 <= nc < cols:
            acc[nr, nc] += acc[r, c]
            in_degree[nr, nc] -= 1
            if in_degree[nr, nc] == 0:
                queue.append((nr, nc))

    logger.info(
        "Flow accumulation computed: max upstream cells = %d", int(np.nanmax(acc))
    )
    return acc


# ---------------------------------------------------------------------------
# HAND (Height Above Nearest Drainage)
# ---------------------------------------------------------------------------

def compute_hand(
    dem_path: str | Path,
    drainage_mask: np.ndarray | None = None,
    flow_acc: np.ndarray | None = None,
    stream_threshold: int = 1000,
    output_path: str | Path | None = None,
) -> np.ndarray:
    """Compute HAND — height of each cell above the nearest drainage cell.

    Drainage cells are identified either by an explicit mask or by
    thresholding flow accumulation (cells with acc >= stream_threshold).

    The algorithm traces each cell's D8 flow path downstream until it
    reaches a drainage cell, then computes the elevation difference.

    Args:
        dem_path: Path to DEM raster.
        drainage_mask: Boolean array marking drainage/stream cells.
        flow_acc: Pre-computed flow accumulation (used with stream_threshold).
        stream_threshold: Upstream cell count to classify as drainage.
        output_path: Optional path to write HAND raster.

    Returns:
        Float array of height above nearest drainage (meters).
    """
    dem, profile = _read_raster(dem_path)
    fdir = compute_d8_flow_direction(dem_path)

    if drainage_mask is None:
        if flow_acc is None:
            flow_acc = compute_flow_accumulation(dem_path, fdir)
        drainage_mask = flow_acc >= stream_threshold
        logger.info(
            "Stream network: %d cells (threshold=%d)",
            drainage_mask.sum(), stream_threshold,
        )

    rows, cols = dem.shape
    hand = np.full((rows, cols), np.nan, dtype=np.float64)

    # Drainage cells have HAND = 0
    hand[drainage_mask] = 0.0

    # Trace each non-drainage cell downstream to find its drainage outlet
    for r in range(rows):
        for c in range(cols):
            if np.isnan(dem[r, c]) or drainage_mask[r, c]:
                continue
            # Walk downstream
            cr, cc = r, c
            max_steps = rows * cols
            for _ in range(max_steps):
                d = fdir[cr, cc]
                if d < 0:
                    break
                nr, nc = cr + _D8_DR[d], cc + _D8_DC[d]
                if not (0 <= nr < rows and 0 <= nc < cols):
                    break
                if drainage_mask[nr, nc]:
                    hand[r, c] = max(0.0, dem[r, c] - dem[nr, nc])
                    break
                cr, cc = nr, nc

    valid = np.isfinite(hand)
    logger.info(
        "HAND computed: %.1f%% resolved, median=%.1f m, max=%.1f m",
        valid.mean() * 100,
        np.nanmedian(hand) if valid.any() else 0,
        np.nanmax(hand) if valid.any() else 0,
    )

    if output_path:
        _write_raster(hand, profile, output_path)
    return hand


# ---------------------------------------------------------------------------
# Stream Power Index (SPI)
# ---------------------------------------------------------------------------

def compute_spi(
    dem_path: str | Path,
    flow_acc: np.ndarray | None = None,
    output_path: str | Path | None = None,
) -> np.ndarray:
    """Compute Stream Power Index = ln(acc * tan(slope)).

    SPI combines upstream contributing area with local slope to estimate
    erosive power of flowing water. Higher values = more flood energy.

    Args:
        dem_path: Path to DEM raster.
        flow_acc: Pre-computed flow accumulation (optional).
        output_path: Optional path to write SPI raster.

    Returns:
        Float array of SPI values.
    """
    dem, profile = _read_raster(dem_path)
    cellsize = _cellsize_meters(profile)

    if flow_acc is None:
        flow_acc = compute_flow_accumulation(dem_path)

    slope = _slope_from_dem(dem, cellsize)

    # SPI = ln(A * tan(slope)), with guards for zero/negative
    specific_area = flow_acc * cellsize * cellsize  # contributing area in m^2
    tan_slope = np.tan(slope)
    tan_slope = np.clip(tan_slope, 1e-6, None)  # avoid log(0)

    spi = np.log(specific_area * tan_slope)
    spi[np.isnan(dem)] = np.nan

    logger.info(
        "SPI computed: median=%.2f, range=[%.2f, %.2f]",
        np.nanmedian(spi), np.nanmin(spi), np.nanmax(spi),
    )

    if output_path:
        _write_raster(spi, profile, output_path)
    return spi


# ---------------------------------------------------------------------------
# Topographic Wetness Index (TWI)
# ---------------------------------------------------------------------------

def compute_twi(
    dem_path: str | Path,
    flow_acc: np.ndarray | None = None,
    output_path: str | Path | None = None,
) -> np.ndarray:
    """Compute TWI = ln(a / tan(slope)), where a = specific catchment area.

    Args:
        dem_path: Path to DEM raster.
        flow_acc: Pre-computed flow accumulation (optional).
        output_path: Optional path to write TWI raster.

    Returns:
        Float array of TWI values.
    """
    dem, profile = _read_raster(dem_path)
    cellsize = _cellsize_meters(profile)

    if flow_acc is None:
        flow_acc = compute_flow_accumulation(dem_path)

    slope = _slope_from_dem(dem, cellsize)
    specific_area = flow_acc * cellsize  # area per unit contour length
    tan_slope = np.tan(slope)
    tan_slope = np.clip(tan_slope, 1e-6, None)

    twi = np.log(specific_area / tan_slope)
    twi[np.isnan(dem)] = np.nan

    logger.info(
        "TWI computed: median=%.2f, range=[%.2f, %.2f]",
        np.nanmedian(twi), np.nanmin(twi), np.nanmax(twi),
    )

    if output_path:
        _write_raster(twi, profile, output_path)
    return twi


# ---------------------------------------------------------------------------
# Geomorphic Flood Index (GFI)
# ---------------------------------------------------------------------------

def compute_gfi(
    dem_path: str | Path,
    flow_acc: np.ndarray | None = None,
    stream_threshold: int = 1000,
    output_path: str | Path | None = None,
) -> np.ndarray:
    """Compute Geomorphic Flood Index = ln(hr / HAND).

    GFI estimates flood susceptibility from DEM alone (no hydro model).
    hr = water depth proxy based on contributing area of the nearest
    stream cell. Higher GFI = more flood-prone.

    Reference: Manfreda et al. (2011), "Detection of Flood-Prone Areas
    Using Digital Elevation Models."

    Args:
        dem_path: Path to DEM raster.
        flow_acc: Pre-computed flow accumulation (optional).
        stream_threshold: Upstream cell count for stream classification.
        output_path: Optional path to write GFI raster.

    Returns:
        Float array of GFI values (higher = more flood-prone).
    """
    dem, profile = _read_raster(dem_path)

    if flow_acc is None:
        flow_acc = compute_flow_accumulation(dem_path)

    # Stream network from threshold
    drainage_mask = flow_acc >= stream_threshold
    hand = compute_hand(dem_path, drainage_mask=drainage_mask, flow_acc=flow_acc)

    # hr proxy: contributing area of nearest drainage raised to exponent
    # Following Manfreda et al., hr ~ A_river^0.3
    cellsize = _cellsize_meters(profile)
    fdir = compute_d8_flow_direction(dem_path)

    rows, cols = dem.shape
    hr = np.full((rows, cols), np.nan, dtype=np.float64)

    for r in range(rows):
        for c in range(cols):
            if np.isnan(dem[r, c]):
                continue
            if drainage_mask[r, c]:
                hr[r, c] = (flow_acc[r, c] * cellsize * cellsize) ** 0.3
                continue
            # Trace downstream to nearest drainage
            cr, cc = r, c
            for _ in range(rows * cols):
                d = fdir[cr, cc]
                if d < 0:
                    break
                nr, nc = cr + _D8_DR[d], cc + _D8_DC[d]
                if not (0 <= nr < rows and 0 <= nc < cols):
                    break
                if drainage_mask[nr, nc]:
                    hr[r, c] = (flow_acc[nr, nc] * cellsize * cellsize) ** 0.3
                    break
                cr, cc = nr, nc

    # GFI = ln(hr / HAND), guarding against HAND=0 and hr=NaN
    safe_hand = np.clip(hand, 0.1, None)
    gfi = np.log(hr / safe_hand)
    gfi[np.isnan(dem)] = np.nan
    gfi[np.isnan(hr)] = np.nan

    logger.info(
        "GFI computed: median=%.2f, range=[%.2f, %.2f]",
        np.nanmedian(gfi), np.nanmin(gfi[np.isfinite(gfi)]),
        np.nanmax(gfi[np.isfinite(gfi)]),
    )

    if output_path:
        _write_raster(gfi, profile, output_path)
    return gfi


# ---------------------------------------------------------------------------
# ZCTA-level aggregation of raster features
# ---------------------------------------------------------------------------

def zonal_hydro_stats(
    raster_path: str | Path,
    zones_gdf: "gpd.GeoDataFrame",
    zone_id_col: str = "zcta",
    prefix: str = "",
) -> "pd.DataFrame":
    """Compute zonal statistics of a hydrology raster over polygon zones.

    Returns mean, median, P10, P90, min, max per zone.

    Args:
        raster_path: Path to raster (HAND, SPI, TWI, GFI, etc.).
        zones_gdf: Polygon GeoDataFrame (e.g. ZCTA boundaries).
        zone_id_col: Column identifying each zone.
        prefix: Column name prefix (e.g. "hand_" -> "hand_mean").

    Returns:
        DataFrame indexed by zone_id with 6 statistic columns.
    """
    import geopandas as gpd
    import pandas as pd

    with rasterio.open(raster_path) as src:
        raster_data = src.read(1).astype(np.float64)
        nodata = src.nodata
        if nodata is not None:
            raster_data[raster_data == nodata] = np.nan
        transform = src.transform
        raster_crs = src.crs

    # Reproject zones to raster CRS
    zones = zones_gdf.to_crs(raster_crs)

    records = []
    for _, row in zones.iterrows():
        zone_id = row[zone_id_col]
        geom = row.geometry
        if geom is None or geom.is_empty:
            continue

        # Get bounding box pixel coordinates
        minx, miny, maxx, maxy = geom.bounds
        row_min, col_min = rowcol(transform, minx, maxy)
        row_max, col_max = rowcol(transform, maxx, miny)

        # Clamp to raster bounds
        row_min = max(0, min(row_min, raster_data.shape[0] - 1))
        row_max = max(0, min(row_max, raster_data.shape[0] - 1))
        col_min = max(0, min(col_min, raster_data.shape[1] - 1))
        col_max = max(0, min(col_max, raster_data.shape[1] - 1))

        if row_min > row_max or col_min > col_max:
            continue

        # Extract window
        window = raster_data[row_min:row_max + 1, col_min:col_max + 1]
        vals = window[np.isfinite(window)]

        if len(vals) == 0:
            records.append({zone_id_col: zone_id})
            continue

        records.append({
            zone_id_col: zone_id,
            f"{prefix}mean": float(np.mean(vals)),
            f"{prefix}median": float(np.median(vals)),
            f"{prefix}p10": float(np.percentile(vals, 10)),
            f"{prefix}p90": float(np.percentile(vals, 90)),
            f"{prefix}min": float(np.min(vals)),
            f"{prefix}max": float(np.max(vals)),
        })

    result = pd.DataFrame(records)
    if not result.empty:
        result = result.set_index(zone_id_col)
    logger.info(
        "Zonal hydro stats: %d zones, prefix='%s'", len(result), prefix,
    )
    return result
