"""Floodcaster: certificate-backed flood intelligence engine.

Public API
----------
Analysis (primary entry points):
    run_flood_analysis      -- user-supplied raster + HAZUS depth-damage
    run_nsi_flood_analysis  -- NSI 2.0 buildings + HAZUS depth-damage
    run_default_analysis    -- Deltares default depth + HAZUS + certificate
    compute_ead             -- Expected Annual Damage across return periods
    DefaultAnalysisResult   -- Result container for default analysis

Certificate:
    EvidenceCertificate     -- evidence certificate with verdict
    LayerEvidence           -- per-layer evidence record
    LayerRole               -- dataset decision roles
    LayerStatus             -- layer availability statuses
    Verdict                 -- TRUST / REVIEW / ESCALATE / SUPPRESS
    compute_verdict         -- derive verdict from layer evidence

Layers:
    resolve_layers          -- resolve all available layers for a bbox
    LayerResult             -- resolved layer with data

STAC (Planetary Computer):
    DeltaresQuery           -- Deltares search parameters
    get_deltares_depth      -- fetch Deltares flood depth COG
    get_jrc_water_occurrence -- fetch JRC surface water occurrence
    get_sentinel1_flood_mask -- detect surface water from Sentinel-1 SAR
    get_dem_elevation       -- fetch DEM elevation COG

Disagreement:
    compare_depths          -- compare multiple depth sources
    depth_disagreement_certificate -- generate disagreement certificate

Data sources:
    fetch_overture_buildings -- query Overture Maps building footprints
    fetch_nsi_by_fips       -- query NSI 2.0 by county FIPS codes
    fetch_nsi_by_bbox       -- query NSI 2.0 by bounding box
    BBox                    -- bounding box dataclass

Aggregation:
    aggregate_by_zcta           -- spatial join buildings to ZCTA polygons
    aggregate_by_zcta_extended  -- extended aggregation with depth percentiles

Batch (ZCTA centroid extraction):
    deltares_centroid_depth       -- Deltares depth at centroid locations
    hydrology_centroid_stats      -- DEM hydrology at centroid locations
    sentinel1_centroid_inundation -- SAR inundation at centroid locations

Hydrology (DEM-derived features):
    compute_hand            -- Height Above Nearest Drainage
    compute_spi             -- Stream Power Index
    compute_twi             -- Topographic Wetness Index
    compute_gfi             -- Geomorphic Flood Index
    compute_flow_accumulation -- D8 flow accumulation
    zonal_hydro_stats       -- zonal stats of hydro rasters over polygons

Hazard (gauge/forecast-derived metrics):
    crest_margin, nws_severity, rate_of_rise, rate_of_rise_series,
    depth_above_ground, freeboard, discharge_exceedance,
    encounter_probability, TemporalBasis, NWSSeverity, GageThresholds

Engine (sphere re-exports for direct access):
    from floodcaster.engine import FastBuildings, HazusFloodAnalysis, ...
"""

__version__ = "0.5.0"

# Analysis
from floodcaster.aggregation import aggregate_by_zcta, aggregate_by_zcta_extended

# Batch
from floodcaster.batch import (
    deltares_centroid_depth,
    hydrology_centroid_stats,
    sentinel1_centroid_inundation,
)
from floodcaster.analysis import (
    DefaultAnalysisResult,
    compute_ead,
    run_default_analysis,
    run_flood_analysis,
    run_nsi_flood_analysis,
)

# Certificate
from floodcaster.certificate import (
    EvidenceCertificate,
    LayerEvidence,
    LayerRole,
    LayerStatus,
    Verdict,
    compute_verdict,
)

# Disagreement
from floodcaster.disagreement import compare_depths, depth_disagreement_certificate

# Hazard
from floodcaster.hazard import (
    GageThresholds,
    NWSSeverity,
    TemporalBasis,
    crest_margin,
    depth_above_ground,
    discharge_exceedance,
    encounter_probability,
    freeboard,
    nws_severity,
    rate_of_rise,
    rate_of_rise_series,
)

# Hydrology
from floodcaster.hydrology import (
    compute_flow_accumulation,
    compute_gfi,
    compute_hand,
    compute_spi,
    compute_twi,
    zonal_hydro_stats,
)

# Layers
from floodcaster.layers import LayerResult, resolve_layers

# Sources
from floodcaster.nsi_sources import fetch_nsi_by_bbox, fetch_nsi_by_fips
from floodcaster.sources import BBox, fetch_overture_buildings

# STAC
from floodcaster.stac import (
    DeltaresQuery,
    get_deltares_depth,
    get_dem_elevation,
    get_jrc_water_occurrence,
    get_sentinel1_flood_mask,
    jrc_centroid_occurrence,
)

__all__ = [
    # Analysis
    "run_flood_analysis",
    "run_nsi_flood_analysis",
    "run_default_analysis",
    "DefaultAnalysisResult",
    "compute_ead",
    # Certificate
    "EvidenceCertificate",
    "LayerEvidence",
    "LayerRole",
    "LayerStatus",
    "Verdict",
    "compute_verdict",
    # Disagreement
    "compare_depths",
    "depth_disagreement_certificate",
    # Layers
    "resolve_layers",
    "LayerResult",
    # STAC
    "DeltaresQuery",
    "get_deltares_depth",
    "get_jrc_water_occurrence",
    "get_dem_elevation",
    "get_sentinel1_flood_mask",
    "jrc_centroid_occurrence",
    # Sources
    "BBox",
    "fetch_overture_buildings",
    "fetch_nsi_by_fips",
    "fetch_nsi_by_bbox",
    # Aggregation
    "aggregate_by_zcta",
    "aggregate_by_zcta_extended",
    # Hazard
    "crest_margin",
    "nws_severity",
    "rate_of_rise",
    "rate_of_rise_series",
    "depth_above_ground",
    "freeboard",
    "discharge_exceedance",
    "encounter_probability",
    "TemporalBasis",
    "NWSSeverity",
    "GageThresholds",
    # Batch
    "deltares_centroid_depth",
    "hydrology_centroid_stats",
    "sentinel1_centroid_inundation",
    # Hydrology
    "compute_hand",
    "compute_spi",
    "compute_twi",
    "compute_gfi",
    "compute_flow_accumulation",
    "zonal_hydro_stats",
]
