"""Depth disagreement diagnostic: compare multiple depth sources.

When Deltares, DEM-bathtub, SAR, and JRC all provide depth-related
information, this module compares them and flags disagreements.

Usage:
    from floodcaster.disagreement import compare_depths

    result = compare_depths({
        "deltares": deltares_depth_ft,
        "bathtub": bathtub_depth_ft,
    })
    print(result.level)  # DisagreementLevel.LOW / MODERATE / HIGH
"""

import enum
import logging
from dataclasses import dataclass

import numpy as np

logger = logging.getLogger(__name__)

# Thresholds for disagreement classification
# Based on median absolute difference between sources
_MODERATE_THRESHOLD_FT = 1.0  # >1 ft median difference = moderate
_HIGH_THRESHOLD_FT = 3.0  # >3 ft median difference = high


class DisagreementLevel(enum.Enum):
    """Level of disagreement between depth sources."""

    LOW = "low"
    MODERATE = "moderate"
    HIGH = "high"


@dataclass(frozen=True)
class DepthComparison:
    """Summary statistics for one depth source."""

    source: str
    median_depth_ft: float
    max_depth_ft: float
    pct_inundated: float

    def to_dict(self) -> dict:
        return {
            "source": self.source,
            "median_depth_ft": round(self.median_depth_ft, 2),
            "max_depth_ft": round(self.max_depth_ft, 2),
            "pct_inundated": round(self.pct_inundated, 1),
        }


@dataclass
class DisagreementResult:
    """Result of comparing multiple depth sources."""

    comparisons: list[DepthComparison]
    level: DisagreementLevel
    max_median_diff_ft: float

    def to_dict(self) -> dict:
        return {
            "level": self.level.value,
            "max_median_diff_ft": round(self.max_median_diff_ft, 2),
            "comparisons": [c.to_dict() for c in self.comparisons],
        }


def _summarize_depth(arr: np.ndarray) -> tuple[float, float, float]:
    """Compute median, max, pct_inundated for a depth array."""
    valid = arr[np.isfinite(arr)]
    if len(valid) == 0:
        return 0.0, 0.0, 0.0
    positive = valid[valid > 0]
    median = float(np.median(positive)) if len(positive) > 0 else 0.0
    max_d = float(np.max(valid))
    pct = float(len(positive) / len(valid) * 100)
    return median, max_d, pct


def compare_depths(
    sources: dict[str, np.ndarray],
) -> DisagreementResult:
    """Compare multiple depth source arrays and classify disagreement."""
    comparisons: list[DepthComparison] = []
    medians: list[float] = []

    for name, arr in sources.items():
        median, max_d, pct = _summarize_depth(arr)
        comparisons.append(DepthComparison(name, median, max_d, pct))
        medians.append(median)

    # Compute max pairwise median difference
    max_diff = 0.0
    for i in range(len(medians)):
        for j in range(i + 1, len(medians)):
            diff = abs(medians[i] - medians[j])
            max_diff = max(max_diff, diff)

    if max_diff >= _HIGH_THRESHOLD_FT:
        level = DisagreementLevel.HIGH
    elif max_diff >= _MODERATE_THRESHOLD_FT:
        level = DisagreementLevel.MODERATE
    else:
        level = DisagreementLevel.LOW

    logger.info(
        "Depth disagreement: %s (max median diff=%.2f ft, %d sources)",
        level.value, max_diff, len(sources),
    )
    return DisagreementResult(comparisons, level, max_diff)


def depth_disagreement_certificate(result: DisagreementResult) -> dict:
    """Generate a disagreement certificate with action recommendation."""
    if result.level == DisagreementLevel.HIGH:
        action = "Review: depth sources diverge significantly. Do not use for public evacuation messaging without specialist review."
    elif result.level == DisagreementLevel.MODERATE:
        action = "Acceptable for planning. Note that depth sources show moderate disagreement. Use conservative (higher) estimate for safety margin."
    else:
        action = "Acceptable for planning. Depth sources are consistent."

    return {
        "hazard_disagreement": result.level.value,
        "max_median_diff_ft": round(result.max_median_diff_ft, 2),
        "action": action,
        "comparisons": [c.to_dict() for c in result.comparisons],
    }
