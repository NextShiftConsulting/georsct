"""Role-based layer registry: resolve which data layers are available for a bbox.

Each dataset has one decision role (scenario_hazard, terrain_correction, etc.).
The registry tries to fetch each layer and returns a LayerResult with status
and data (if available). The results feed into EvidenceCertificate.

Usage:
    from floodcaster.layers import resolve_layers
    from floodcaster.sources import BBox

    results = resolve_layers(BBox(-90.1, 29.9, -89.9, 30.1))
    for r in results:
        print(r.role, r.status)
"""

import logging
from dataclasses import dataclass

import numpy as np

from floodcaster.certificate import LayerEvidence, LayerRole, LayerStatus
from floodcaster.stac import (
    DeltaresQuery,
    get_deltares_depth,
    get_dem_elevation,
    get_jrc_water_occurrence,
    get_sentinel1_flood_mask,
)
from floodcaster.sources import BBox

logger = logging.getLogger(__name__)

# JRC thresholds: what fraction of pixels must have >30% occurrence
# to qualify as "HIGH" historical plausibility
JRC_OCCURRENCE_THRESHOLD = 30.0  # percent occurrence to count as "wet"
JRC_FRACTION_THRESHOLD = 0.10  # 10% of pixels must be wet -> HIGH

# Sentinel-1: minimum water fraction to qualify as DETECTED
S1_WATER_FRACTION_THRESHOLD = 0.01  # 1% of pixels must be water


@dataclass
class LayerResult:
    """Result of resolving one data layer.

    Args:
        role: Decision role this layer fills.
        source: Dataset name.
        status: Resolution status.
        data: Numpy array of layer data (None if missing).
        transform: Rasterio Affine transform (None if missing).
        detail: Human-readable detail string.
    """

    role: LayerRole
    source: str
    status: LayerStatus
    data: np.ndarray | None = None
    transform: object | None = None
    detail: str = ""

    def to_evidence(self) -> LayerEvidence:
        """Convert to a LayerEvidence record (drops the data array)."""
        return LayerEvidence(
            role=self.role,
            source=self.source,
            status=self.status,
            detail=self.detail,
        )


def resolve_deltares(
    bbox: BBox,
    query: DeltaresQuery | None = None,
) -> LayerResult:
    """Resolve the Deltares scenario hazard layer."""
    if query is None:
        query = DeltaresQuery()
    try:
        depth_ft, transform = get_deltares_depth(bbox, query)
        detail = (
            f"RP={query.return_period}yr, DEM={query.dem}, "
            f"res={query.resolution}, scenario={query.scenario}"
        )
        return LayerResult(
            role=LayerRole.SCENARIO_HAZARD,
            source="deltares-floods",
            status=LayerStatus.AVAILABLE,
            data=depth_ft,
            transform=transform,
            detail=detail,
        )
    except RuntimeError as e:
        logger.warning("Deltares layer unavailable: %s", e)
        return LayerResult(
            role=LayerRole.SCENARIO_HAZARD,
            source="deltares-floods",
            status=LayerStatus.MISSING,
            detail=str(e),
        )


def resolve_jrc(bbox: BBox) -> LayerResult:
    """Resolve the JRC historical plausibility layer.

    Classifies as HIGH if >10% of pixels have >30% water occurrence,
    LOW otherwise.
    """
    try:
        occurrence, transform = get_jrc_water_occurrence(bbox)
        wet_pixels = np.sum(occurrence > JRC_OCCURRENCE_THRESHOLD)
        total_valid = np.sum(np.isfinite(occurrence))
        fraction_wet = wet_pixels / max(total_valid, 1)
        status = LayerStatus.HIGH if fraction_wet > JRC_FRACTION_THRESHOLD else LayerStatus.LOW
        detail = f"{fraction_wet * 100:.1f}% of pixels historically wet (>30% occurrence)"
        return LayerResult(
            role=LayerRole.HISTORICAL_PLAUSIBILITY,
            source="jrc-gsw",
            status=status,
            data=occurrence,
            transform=transform,
            detail=detail,
        )
    except RuntimeError as e:
        logger.warning("JRC layer unavailable: %s", e)
        return LayerResult(
            role=LayerRole.HISTORICAL_PLAUSIBILITY,
            source="jrc-gsw",
            status=LayerStatus.MISSING,
            detail=str(e),
        )


def resolve_dem(
    bbox: BBox,
    collection: str = "cop-dem-glo-30",
) -> LayerResult:
    """Resolve the DEM terrain correction layer."""
    try:
        elevation, transform = get_dem_elevation(bbox, collection)
        detail = f"collection={collection}, median={float(np.nanmedian(elevation)):.1f}m"
        return LayerResult(
            role=LayerRole.TERRAIN_CORRECTION,
            source=collection,
            status=LayerStatus.AVAILABLE,
            data=elevation,
            transform=transform,
            detail=detail,
        )
    except RuntimeError as e:
        logger.warning("DEM layer unavailable: %s", e)
        return LayerResult(
            role=LayerRole.TERRAIN_CORRECTION,
            source=collection,
            status=LayerStatus.MISSING,
            detail=str(e),
        )


def resolve_sentinel1(bbox: BBox) -> LayerResult:
    """Resolve the Sentinel-1 SAR live confirmation layer."""
    try:
        mask, acq_dt, detail = get_sentinel1_flood_mask(bbox)
        valid = np.sum(np.isfinite(mask.astype(float)))
        water_frac = float(np.sum(mask)) / max(valid, 1)
        if water_frac > S1_WATER_FRACTION_THRESHOLD:
            status = LayerStatus.DETECTED
        else:
            status = LayerStatus.UNAVAILABLE
            detail += " (below detection threshold)"
        return LayerResult(
            role=LayerRole.LIVE_CONFIRMATION,
            source="sentinel-1-rtc",
            status=status,
            data=mask,
            detail=detail,
        )
    except RuntimeError as e:
        logger.warning("Sentinel-1 layer unavailable: %s", e)
        return LayerResult(
            role=LayerRole.LIVE_CONFIRMATION,
            source="sentinel-1-rtc",
            status=LayerStatus.MISSING,
            detail=str(e),
        )


def resolve_hrrr(bbox: BBox) -> LayerResult:
    """Resolve the HRRR precipitation driver layer."""
    try:
        from floodcaster.hrrr import get_hrrr_precipitation

        result = get_hrrr_precipitation(bbox)
        if result["is_stale"]:
            status = LayerStatus.STALE
        else:
            status = LayerStatus.ACTIVE
        return LayerResult(
            role=LayerRole.RAINFALL_DRIVER,
            source="hrrr",
            status=status,
            data=result["precip_mm"],
            detail=result["detail"],
        )
    except RuntimeError as e:
        logger.warning("HRRR layer unavailable: %s", e)
        return LayerResult(
            role=LayerRole.RAINFALL_DRIVER,
            source="hrrr",
            status=LayerStatus.MISSING,
            detail=str(e),
        )


def resolve_layers(
    bbox: BBox,
    deltares_query: DeltaresQuery | None = None,
    dem_collection: str = "cop-dem-glo-30",
    include_jrc: bool = True,
    include_dem: bool = True,
    include_sentinel1: bool = False,
    include_hrrr: bool = False,
) -> list[LayerResult]:
    """Resolve all available layers for a bbox.

    Always includes exposure (Overture) and vulnerability (HAZUS) as
    non-STAC layers. Optionally resolves Deltares, JRC, DEM, Sentinel-1,
    and HRRR layers.
    """
    results: list[LayerResult] = []

    # STAC-backed layers
    results.append(resolve_deltares(bbox, deltares_query))

    if include_jrc:
        results.append(resolve_jrc(bbox))

    if include_dem:
        results.append(resolve_dem(bbox, dem_collection))

    if include_sentinel1:
        results.append(resolve_sentinel1(bbox))

    if include_hrrr:
        results.append(resolve_hrrr(bbox))

    # Non-STAC layers (always present in floodcaster)
    results.append(LayerResult(
        role=LayerRole.EXPOSURE,
        source="overture",
        status=LayerStatus.AVAILABLE,
        detail="Overture Maps building footprints",
    ))
    results.append(LayerResult(
        role=LayerRole.VULNERABILITY,
        source="hazus",
        status=LayerStatus.ASSUMED,
        detail="FEMA HAZUS depth-damage curves via sphere",
    ))

    logger.info(
        "Layer resolution: %d layers, statuses: %s",
        len(results),
        {r.role.value: r.status.value for r in results},
    )
    return results
