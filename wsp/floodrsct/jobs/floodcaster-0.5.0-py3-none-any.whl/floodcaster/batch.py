"""ZCTA-level batch feature extraction from Planetary Computer.

Public functions follow the jrc_centroid_occurrence pattern: one STAC call
for the overall centroid bounding box, per-centroid buffer sampling.

Usage:
    from floodcaster.batch import deltares_centroid_depth
    df = deltares_centroid_depth(centroids, return_periods=[10, 50, 100])
"""

import logging
import os
import tempfile
from datetime import datetime, timezone

import numpy as np
import pandas as pd
import rasterio as _rio
from rasterio.transform import from_bounds, rowcol

from floodcaster.hydrology import (
    compute_flow_accumulation,
    compute_gfi,
    compute_hand,
    compute_spi,
    compute_twi,
)
from floodcaster.sources import BBox
from floodcaster.stac import (
    DeltaresQuery,
    get_deltares_depth,
    get_dem_elevation,
    get_sentinel1_flood_mask,
    search_collection,
)

logger = logging.getLogger(__name__)


def _sample_buffer(
    arr: np.ndarray,
    transform,
    lon: float,
    lat: float,
    buffer_deg: float,
) -> np.ndarray:
    """Extract a buffer patch around (lon, lat) from a raster array.

    Returns the 1D array of finite values within the buffer, or empty array.
    """
    r_center, c_center = rowcol(transform, lon, lat)
    r_buf, c_buf = rowcol(transform, lon - buffer_deg, lat + buffer_deg)
    r_buf2, c_buf2 = rowcol(transform, lon + buffer_deg, lat - buffer_deg)
    r_min = max(0, min(r_buf, r_buf2))
    r_max = min(arr.shape[0], max(r_buf, r_buf2) + 1)
    c_min = max(0, min(c_buf, c_buf2))
    c_max = min(arr.shape[1], max(c_buf, c_buf2) + 1)
    if r_min >= r_max or c_min >= c_max:
        return np.array([])
    patch = arr[r_min:r_max, c_min:c_max].ravel()
    return patch[np.isfinite(patch)]


def deltares_centroid_depth(
    centroids: pd.DataFrame,
    id_col: str = "zcta_id",
    lat_col: str = "lat",
    lon_col: str = "lon",
    buffer_deg: float = 0.01,
    return_periods: list[int] | None = None,
) -> pd.DataFrame:
    """Sample Deltares modeled flood depth at centroid locations.

    Args:
        centroids: DataFrame with id, lat, lon columns.
        id_col: Name of the ID column.
        lat_col: Name of the latitude column.
        lon_col: Name of the longitude column.
        buffer_deg: Buffer radius in degrees (~1 km at equator).
        return_periods: List of return periods in years. Default [10, 50, 100].

    Returns:
        DataFrame with columns: [id_col, deltares_depth_ft_rp{N},
        deltares_max_depth_ft_rp{N}, deltares_inundation_pct_rp{N}] per RP.
    """
    if return_periods is None:
        return_periods = [10, 50, 100]

    if centroids.empty:
        cols = {id_col: pd.Series(dtype="object")}
        for rp in return_periods:
            cols[f"deltares_depth_ft_rp{rp}"] = pd.Series(dtype="float64")
            cols[f"deltares_max_depth_ft_rp{rp}"] = pd.Series(dtype="float64")
            cols[f"deltares_inundation_pct_rp{rp}"] = pd.Series(dtype="float64")
        return pd.DataFrame(cols)

    lats = centroids[lat_col].values
    lons = centroids[lon_col].values
    bbox = BBox(
        xmin=float(lons.min()) - buffer_deg,
        ymin=float(lats.min()) - buffer_deg,
        xmax=float(lons.max()) + buffer_deg,
        ymax=float(lats.max()) + buffer_deg,
    )

    rp_data: dict[int, tuple[np.ndarray, object] | None] = {}
    for rp in return_periods:
        try:
            query = DeltaresQuery(return_period=rp)
            arr, transform = get_deltares_depth(bbox, query=query)
            rp_data[rp] = (arr, transform)
            logger.info("deltares_centroid_depth: RP=%d fetched (%s)", rp, arr.shape)
        except RuntimeError:
            logger.warning("deltares_centroid_depth: no data for RP=%d", rp)
            rp_data[rp] = None

    records = []
    for _, row in centroids.iterrows():
        rec = {id_col: row[id_col]}
        for rp in return_periods:
            data = rp_data[rp]
            if data is None:
                rec[f"deltares_depth_ft_rp{rp}"] = np.nan
                rec[f"deltares_max_depth_ft_rp{rp}"] = np.nan
                rec[f"deltares_inundation_pct_rp{rp}"] = np.nan
                continue
            arr, transform = data
            vals = _sample_buffer(arr, transform, row[lon_col], row[lat_col], buffer_deg)
            if len(vals) == 0:
                rec[f"deltares_depth_ft_rp{rp}"] = np.nan
                rec[f"deltares_max_depth_ft_rp{rp}"] = np.nan
                rec[f"deltares_inundation_pct_rp{rp}"] = np.nan
            else:
                rec[f"deltares_depth_ft_rp{rp}"] = float(np.mean(vals))
                rec[f"deltares_max_depth_ft_rp{rp}"] = float(np.max(vals))
                rec[f"deltares_inundation_pct_rp{rp}"] = float(
                    np.sum(vals > 0) / len(vals) * 100
                )
        records.append(rec)

    result = pd.DataFrame(records)
    logger.info("deltares_centroid_depth: %d centroids, %d RPs", len(result), len(return_periods))
    return result


def hydrology_centroid_stats(
    centroids: pd.DataFrame,
    id_col: str = "zcta_id",
    lat_col: str = "lat",
    lon_col: str = "lon",
    buffer_deg: float = 0.01,
) -> pd.DataFrame:
    """Compute DEM-derived hydrology stats at centroid locations.

    Fetches Copernicus DEM from Planetary Computer, computes HAND, TWI,
    SPI, and GFI, then samples each metric in a buffer around centroids.

    Args:
        centroids: DataFrame with id, lat, lon columns.
        id_col: Name of the ID column.
        lat_col: Name of the latitude column.
        lon_col: Name of the longitude column.
        buffer_deg: Buffer radius in degrees (~1 km at equator).

    Returns:
        DataFrame with columns: [id_col, hand_mean_m, twi_mean, gfi_mean, spi_mean].
    """
    if centroids.empty:
        return pd.DataFrame({
            id_col: pd.Series(dtype="object"),
            "hand_mean_m": pd.Series(dtype="float64"),
            "twi_mean": pd.Series(dtype="float64"),
            "gfi_mean": pd.Series(dtype="float64"),
            "spi_mean": pd.Series(dtype="float64"),
        })

    lats = centroids[lat_col].values
    lons = centroids[lon_col].values
    bbox = BBox(
        xmin=float(lons.min()) - buffer_deg,
        ymin=float(lats.min()) - buffer_deg,
        xmax=float(lons.max()) + buffer_deg,
        ymax=float(lats.max()) + buffer_deg,
    )

    try:
        dem_arr, transform = get_dem_elevation(bbox)
    except RuntimeError:
        logger.warning("hydrology_centroid_stats: no DEM data")
        return pd.DataFrame({
            id_col: centroids[id_col].values,
            "hand_mean_m": np.nan, "twi_mean": np.nan,
            "gfi_mean": np.nan, "spi_mean": np.nan,
        })

    # Write DEM to temp file for hydrology functions (file-path API)
    with tempfile.NamedTemporaryFile(suffix=".tif", delete=False) as tmp:
        tmp_path = tmp.name
    profile = {
        "driver": "GTiff", "dtype": "float64", "count": 1,
        "height": dem_arr.shape[0], "width": dem_arr.shape[1],
        "crs": "EPSG:4326", "transform": transform,
        "nodata": np.nan,
    }
    with _rio.open(tmp_path, "w", **profile) as dst:
        dst.write(dem_arr.astype(np.float64), 1)

    try:
        flow_acc = compute_flow_accumulation(tmp_path)
        hand_arr = compute_hand(tmp_path, flow_acc=flow_acc)
        spi_arr = compute_spi(tmp_path, flow_acc=flow_acc)
        twi_arr = compute_twi(tmp_path, flow_acc=flow_acc)
        gfi_arr = compute_gfi(tmp_path, flow_acc=flow_acc)
    except Exception as exc:
        logger.warning("hydrology_centroid_stats: compute failed: %s", exc)
        return pd.DataFrame({
            id_col: centroids[id_col].values,
            "hand_mean_m": np.nan, "twi_mean": np.nan,
            "gfi_mean": np.nan, "spi_mean": np.nan,
        })
    finally:
        os.unlink(tmp_path)

    metrics = {"hand": hand_arr, "twi": twi_arr, "gfi": gfi_arr, "spi": spi_arr}
    col_names = {
        "hand": "hand_mean_m", "twi": "twi_mean",
        "gfi": "gfi_mean", "spi": "spi_mean",
    }

    records = []
    for _, row in centroids.iterrows():
        rec = {id_col: row[id_col]}
        for key, arr in metrics.items():
            vals = _sample_buffer(arr, transform, row[lon_col], row[lat_col], buffer_deg)
            rec[col_names[key]] = float(np.mean(vals)) if len(vals) > 0 else np.nan
        records.append(rec)

    result = pd.DataFrame(records)
    logger.info("hydrology_centroid_stats: %d centroids", len(result))
    return result


def sentinel1_centroid_inundation(
    centroids: pd.DataFrame,
    id_col: str = "zcta_id",
    lat_col: str = "lat",
    lon_col: str = "lon",
    buffer_deg: float = 0.01,
    event_start: str | None = None,
    event_end: str | None = None,
) -> pd.DataFrame:
    """Detect Sentinel-1 SAR inundation at centroid locations.

    Searches for Sentinel-1 overpasses within [event_start, event_end].
    If found, computes binary flood mask and samples per centroid.

    Args:
        centroids: DataFrame with id, lat, lon columns.
        id_col: Name of the ID column.
        lat_col: Name of the latitude column.
        lon_col: Name of the longitude column.
        buffer_deg: Buffer radius in degrees (~1 km at equator).
        event_start: Start of event window (YYYY-MM-DD).
        event_end: End of event window (YYYY-MM-DD).

    Returns:
        DataFrame with columns: [id_col, sar_water_pct, sar_acquisition_dt,
        sar_acquisition_lag_days].
    """
    nan_result = pd.DataFrame({
        id_col: centroids[id_col].values if not centroids.empty else pd.Series(dtype="object"),
        "sar_water_pct": np.nan,
        "sar_acquisition_dt": pd.NaT,
        "sar_acquisition_lag_days": np.nan,
    })

    if centroids.empty:
        return nan_result

    lats = centroids[lat_col].values
    lons = centroids[lon_col].values
    bbox = BBox(
        xmin=float(lons.min()) - buffer_deg,
        ymin=float(lats.min()) - buffer_deg,
        xmax=float(lons.max()) + buffer_deg,
        ymax=float(lats.max()) + buffer_deg,
    )

    try:
        mask, acq_dt, detail = get_sentinel1_flood_mask(bbox)
    except RuntimeError:
        logger.warning("sentinel1_centroid_inundation: no S1 data in window")
        return nan_result

    # Filter by event window if provided
    if event_start and acq_dt:
        start_dt = datetime.strptime(event_start, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        end_dt = None
        if event_end:
            end_dt = datetime.strptime(event_end, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        acq_aware = acq_dt if acq_dt.tzinfo else acq_dt.replace(tzinfo=timezone.utc)
        if acq_aware < start_dt or (end_dt and acq_aware > end_dt):
            logger.info(
                "sentinel1_centroid_inundation: S1 acquisition %s outside event window", acq_dt
            )
            return nan_result

    # Compute acquisition lag
    lag_days = np.nan
    if event_start and acq_dt:
        start_dt = datetime.strptime(event_start, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        acq_aware = acq_dt if acq_dt.tzinfo else acq_dt.replace(tzinfo=timezone.utc)
        lag_days = abs((acq_aware - start_dt).total_seconds()) / 86400.0

    # Infer transform from bbox and mask shape
    transform = from_bounds(
        bbox.xmin, bbox.ymin, bbox.xmax, bbox.ymax,
        mask.shape[1], mask.shape[0],
    )

    records = []
    for _, row in centroids.iterrows():
        vals = _sample_buffer(
            mask.astype(np.float64), transform,
            row[lon_col], row[lat_col], buffer_deg,
        )
        if len(vals) == 0:
            water_pct = np.nan
        else:
            water_pct = float(np.mean(vals) * 100)
        records.append({
            id_col: row[id_col],
            "sar_water_pct": water_pct,
            "sar_acquisition_dt": acq_dt,
            "sar_acquisition_lag_days": lag_days,
        })

    result = pd.DataFrame(records)
    logger.info(
        "sentinel1_centroid_inundation: %d centroids, acq=%s, lag=%.1f days",
        len(result), acq_dt, lag_days if not np.isnan(lag_days) else -1,
    )
    return result
