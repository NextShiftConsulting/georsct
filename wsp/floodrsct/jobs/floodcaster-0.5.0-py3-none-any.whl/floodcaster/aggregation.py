"""ZCTA-level aggregation of per-building flood analysis results."""

import logging

import geopandas as gpd
import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


def _find_col(gdf: gpd.GeoDataFrame, *keywords: str) -> str | None:
    """Find a column whose lowercase name contains all keywords."""
    for c in gdf.columns:
        cl = c.lower()
        if all(k in cl for k in keywords):
            return c
    return None


def _resolve_loss_col(gdf: gpd.GeoDataFrame, loss_col: str | None) -> str | None:
    """Resolve the building-loss column name (sphere's default: BldgLossUSD)."""
    if loss_col and loss_col in gdf.columns:
        return loss_col
    return (
        _find_col(gdf, "loss", "bldg")
        or _find_col(gdf, "building_loss")
        or _find_col(gdf, "bldglossusd")
    )


def _resolve_depth_col(gdf: gpd.GeoDataFrame, depth_col: str | None) -> str | None:
    """Resolve the flood-depth column name (sphere's default: FloodDepth)."""
    if depth_col and depth_col in gdf.columns:
        return depth_col
    return (
        _find_col(gdf, "flood", "depth")
        or _find_col(gdf, "flooddepth")
        or _find_col(gdf, "depth")
    )


def aggregate_by_zcta(
    buildings_gdf: gpd.GeoDataFrame,
    zcta_gdf: gpd.GeoDataFrame,
    zcta_id_col: str = "zcta",
    loss_col: str | None = None,
    depth_col: str | None = None,
    area_col: str = "area",
) -> pd.DataFrame:
    """Spatial-join buildings to ZCTA polygons and compute group statistics.

    Produces the 6 FAST ZCTA features defined in DOE_FAST_validation.md:
      fast_n_structures, fast_total_loss_usd, fast_max_loss_usd,
      fast_mean_loss_per_sqft, fast_pct_damaged, fast_median_depth_ft.

    Args:
        buildings_gdf: Per-building results from run_nsi_flood_analysis()
            (must have Point geometry and loss/depth columns).
        zcta_gdf: ZCTA polygons with an ID column.
        zcta_id_col: Column name in zcta_gdf identifying each ZCTA.
        loss_col: Building loss column name (auto-detected if None).
        depth_col: Flood depth column name (auto-detected if None).
        area_col: Building area (sqft) column name.

    Returns:
        DataFrame indexed by zcta with 6 FAST feature columns.
    """
    loss_col = _resolve_loss_col(buildings_gdf, loss_col)
    depth_col = _resolve_depth_col(buildings_gdf, depth_col)

    if loss_col is None:
        raise ValueError(
            "Cannot find building-loss column. "
            f"Available columns: {list(buildings_gdf.columns)}"
        )

    # Spatial join: point-in-polygon assigns each building to a ZCTA
    buildings_crs = buildings_gdf.to_crs(zcta_gdf.crs)
    joined = gpd.sjoin(buildings_crs, zcta_gdf[[zcta_id_col, "geometry"]], how="inner", predicate="within")

    if joined.empty:
        logger.warning("No buildings fell within any ZCTA polygon")
        return _empty_result(zcta_gdf, zcta_id_col)

    logger.info(
        "Spatial join: %d of %d buildings matched to %d ZCTAs",
        len(joined), len(buildings_gdf), joined[zcta_id_col].nunique(),
    )

    # Pre-compute per-building derived values
    loss = pd.to_numeric(joined[loss_col], errors="coerce").fillna(0.0)
    area = pd.to_numeric(joined[area_col], errors="coerce").clip(lower=1.0) if area_col in joined.columns else 1.0

    groups = joined.groupby(zcta_id_col)

    result = pd.DataFrame({
        "fast_n_structures": groups.size(),
        "fast_total_loss_usd": loss.groupby(joined[zcta_id_col]).sum(),
        "fast_max_loss_usd": loss.groupby(joined[zcta_id_col]).max(),
        "fast_mean_loss_per_sqft": (loss / area).groupby(joined[zcta_id_col]).mean(),
        "fast_pct_damaged": (loss > 0).groupby(joined[zcta_id_col]).mean(),
    })

    if depth_col and depth_col in joined.columns:
        depth = pd.to_numeric(joined[depth_col], errors="coerce")
        result["fast_median_depth_ft"] = depth.groupby(joined[zcta_id_col]).median()
    else:
        logger.warning("No depth column found -- fast_median_depth_ft will be NaN")
        result["fast_median_depth_ft"] = np.nan

    result.index.name = zcta_id_col
    logger.info(
        "Aggregated %d buildings into %d ZCTAs, total loss $%.0f",
        len(joined), len(result), result["fast_total_loss_usd"].sum(),
    )
    return result


def aggregate_by_zcta_extended(
    buildings_gdf: gpd.GeoDataFrame,
    zcta_gdf: gpd.GeoDataFrame,
    zcta_id_col: str = "zcta",
    loss_col: str | None = None,
    depth_col: str | None = None,
    area_col: str = "area",
) -> pd.DataFrame:
    """Extended ZCTA aggregation with percentile depth stats.

    Returns the 6 core FAST features plus 5 additional depth distribution
    features: P10, P25, P75, P90, and std. These capture the tails of the
    flood depth distribution within each ZCTA, which matter more than the
    median for risk assessment.

    Inspired by Zonal Exact Extract / Zonify QGIS plugins.

    Args:
        buildings_gdf: Per-building results with loss/depth columns.
        zcta_gdf: ZCTA polygons with an ID column.
        zcta_id_col: Column name identifying each ZCTA.
        loss_col: Building loss column name (auto-detected if None).
        depth_col: Flood depth column name (auto-detected if None).
        area_col: Building area (sqft) column name.

    Returns:
        DataFrame indexed by zcta with 11 feature columns.
    """
    # Start with the core 6 features
    result = aggregate_by_zcta(
        buildings_gdf, zcta_gdf, zcta_id_col, loss_col, depth_col, area_col,
    )

    if result.empty:
        for col in _EXTENDED_DEPTH_COLS:
            result[col] = np.nan
        return result

    # Resolve depth column for percentile computation
    depth_col = _resolve_depth_col(buildings_gdf, depth_col)
    if depth_col is None or depth_col not in buildings_gdf.columns:
        for col in _EXTENDED_DEPTH_COLS:
            result[col] = np.nan
        return result

    # Spatial join to get per-building depths with ZCTA assignments
    buildings_crs = buildings_gdf.to_crs(zcta_gdf.crs)
    joined = gpd.sjoin(
        buildings_crs, zcta_gdf[[zcta_id_col, "geometry"]],
        how="inner", predicate="within",
    )
    depth = pd.to_numeric(joined[depth_col], errors="coerce")
    groups = depth.groupby(joined[zcta_id_col])

    result["fast_depth_p10_ft"] = groups.quantile(0.10)
    result["fast_depth_p25_ft"] = groups.quantile(0.25)
    result["fast_depth_p75_ft"] = groups.quantile(0.75)
    result["fast_depth_p90_ft"] = groups.quantile(0.90)
    result["fast_depth_std_ft"] = groups.std()

    logger.info(
        "Extended aggregation: %d ZCTAs with depth percentiles", len(result),
    )
    return result


_EXTENDED_DEPTH_COLS = [
    "fast_depth_p10_ft", "fast_depth_p25_ft",
    "fast_depth_p75_ft", "fast_depth_p90_ft", "fast_depth_std_ft",
]


def _empty_result(zcta_gdf: gpd.GeoDataFrame, zcta_id_col: str) -> pd.DataFrame:
    """Return an empty DataFrame with the expected schema."""
    return pd.DataFrame(
        index=pd.Index([], name=zcta_id_col),
        columns=[
            "fast_n_structures", "fast_total_loss_usd", "fast_max_loss_usd",
            "fast_mean_loss_per_sqft", "fast_pct_damaged", "fast_median_depth_ft",
        ],
        dtype=float,
    )
