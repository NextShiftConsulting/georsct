"""HRRR precipitation forecasts from NOAA AWS Open Data.

Downloads High-Resolution Rapid Refresh (HRRR) grib2 files from
s3://noaa-hrrr-bdp-pds/ and extracts quantitative precipitation
forecasts (QPF) for a bounding box.

Usage:
    from floodcaster.hrrr import get_hrrr_precipitation
    from floodcaster.sources import BBox

    bbox = BBox(-90.1, 29.9, -89.9, 30.1)
    result = get_hrrr_precipitation(bbox)
"""

import logging
from datetime import datetime, timedelta, timezone

from floodcaster.sources import BBox

logger = logging.getLogger(__name__)

HRRR_BUCKET = "noaa-hrrr-bdp-pds"
HRRR_6HR_THRESHOLD_MM = 50.0
HRRR_STALE_HOURS = 6


def _find_latest_run(s3) -> datetime:
    """Find the most recent HRRR run by checking S3 keys.

    Walks backwards from the current UTC hour to find the latest
    available HRRR model run on S3.

    Args:
        s3: boto3 S3 client.

    Returns:
        datetime of the latest available run (UTC).

    Raises:
        RuntimeError: If no recent HRRR run found.
    """
    now = datetime.now(timezone.utc)
    base = now.replace(minute=0, second=0, microsecond=0)
    # HRRR runs every hour; check last 24 hours
    for hours_back in range(24):
        candidate = base - timedelta(hours=hours_back)
        prefix = (
            f"hrrr.{candidate.strftime('%Y%m%d')}/conus/"
            f"hrrr.t{candidate.strftime('%H')}z.wrfsfc"
        )
        resp = s3.list_objects_v2(
            Bucket=HRRR_BUCKET, Prefix=prefix, MaxKeys=1,
        )
        if resp.get("KeyCount", 0) > 0:
            logger.info("Found HRRR run: %s", candidate.isoformat())
            return candidate

    raise RuntimeError("No HRRR run found in last 24 hours")


def _fetch_hrrr_grib(
    bbox: BBox,
    run_dt: datetime | None = None,
    max_forecast_hour: int = 18,
) -> dict:
    """Fetch HRRR grib2 precipitation data from S3.

    Downloads HRRR surface forecast files, extracts total precipitation
    (APCP) for the bounding box, and computes summary statistics.

    Args:
        bbox: Geographic bounding box (xmin, ymin, xmax, ymax).
        run_dt: Model run datetime (UTC). If None, finds latest run.
        max_forecast_hour: Maximum forecast hour to retrieve.

    Returns:
        Dict with keys: precip_mm, run_dt, forecast_hour, max_6hr_mm,
        total_mm.

    Raises:
        RuntimeError: If xarray/cfgrib not installed or no data found.
    """
    try:
        import xarray as xr  # noqa: F401
    except ImportError as exc:
        raise RuntimeError(
            "xarray and cfgrib required for HRRR grib2 parsing. "
            "Install with: pip install xarray cfgrib"
        ) from exc

    import tempfile

    import boto3
    import numpy as np
    from swarm_auth import get_aws_credentials

    aws_creds = get_aws_credentials()
    s3 = boto3.client("s3", **aws_creds)

    if run_dt is None:
        run_dt = _find_latest_run(s3)

    date_str = run_dt.strftime("%Y%m%d")
    hour_str = run_dt.strftime("%H")

    precip_total = None
    for fhr in range(1, max_forecast_hour + 1):
        key = (
            f"hrrr.{date_str}/conus/"
            f"hrrr.t{hour_str}z.wrfsfcf{fhr:02d}.grib2"
        )
        with tempfile.NamedTemporaryFile(suffix=".grib2") as tmp:
            s3.download_file(HRRR_BUCKET, key, tmp.name)
            ds = xr.open_dataset(
                tmp.name, engine="cfgrib",
                filter_by_keys={"stepType": "accum", "shortName": "tp"},
            )
            precip = ds["tp"].sel(
                latitude=slice(bbox.ymax, bbox.ymin),
                longitude=slice(
                    bbox.xmin % 360, bbox.xmax % 360,
                ),
            ).values
            if precip_total is None:
                precip_total = precip.copy()
            else:
                precip_total = np.maximum(precip_total, precip)

    if precip_total is None:
        raise RuntimeError(
            f"No HRRR precipitation data for run {run_dt.isoformat()}"
        )

    max_6hr = float(np.nanmax(precip_total))
    total = float(np.nansum(precip_total))

    return {
        "precip_mm": precip_total,
        "run_dt": run_dt,
        "forecast_hour": max_forecast_hour,
        "max_6hr_mm": max_6hr,
        "total_mm": total,
    }


def get_hrrr_precipitation(
    bbox: BBox,
    run_dt: datetime | None = None,
    max_forecast_hour: int = 18,
) -> dict:
    """Fetch HRRR precipitation forecast and enrich with metadata.

    Public entry point that wraps _fetch_hrrr_grib with staleness
    detection and a human-readable detail string.

    Args:
        bbox: Geographic bounding box (xmin, ymin, xmax, ymax).
        run_dt: Model run datetime (UTC). If None, finds latest.
        max_forecast_hour: Maximum forecast hour to retrieve.

    Returns:
        Dict with keys: precip_mm, run_dt, forecast_hour, max_6hr_mm,
        total_mm, detail, is_stale.

    Raises:
        RuntimeError: If HRRR data cannot be fetched.
    """
    result = _fetch_hrrr_grib(bbox, run_dt=run_dt,
                              max_forecast_hour=max_forecast_hour)

    now = datetime.now(timezone.utc)
    age_hours = (now - result["run_dt"]).total_seconds() / 3600
    is_stale = age_hours > HRRR_STALE_HOURS

    fhr = result["forecast_hour"]
    max_6hr = result["max_6hr_mm"]
    total = result["total_mm"]
    detail = (
        f"HRRR {fhr}hr QPF: max 6hr={max_6hr}mm, "
        f"total={total}mm, run {result['run_dt']}"
    )

    result["is_stale"] = is_stale
    result["detail"] = detail

    if is_stale:
        logger.warning("HRRR data is stale (%.1f hours old)", age_hours)

    return result
